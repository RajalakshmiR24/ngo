const express = require("express");
const { saveTransaction, getAllTransactionDetails, pushCampaignDetailsIntoTransactionForm, getTransactionResponse, getTransResponse, getTransactionByCampaignId, saveGeneralTransaction, saveCampaignTransactionData, getTransactionResponseParams } = require("../Controller/transactioncontroller");
const transactionRouter = express.Router();


//campaign
transactionRouter.post("/savecamptransaction", saveCampaignTransactionData);


//general
transactionRouter.post("/savetransaction", saveGeneralTransaction);
transactionRouter.get("/all", getAllTransactionDetails);

// transactionRouter.post("/transactionpercampaign", getTransactionByCampaignId)
transactionRouter.post("/trans", getTransactionResponse)


transactionRouter.post("/getresponse", getTransactionResponse)
transactionRouter.post("/getparams",getTransactionResponseParams)


module.exports = { transactionRouter }