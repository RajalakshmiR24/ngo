const mongoose = require("mongoose");

const transactionSchema = new mongoose.Schema({
    name: {
        type: String,
    },
    email: {
        type: String
    },
    amount: {
        type: String,
    },
    mobilenumber: {
        type: String,
    },

    transactionid: {
        type: String
    },
    campaign: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Campaign' }],
    user: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
    email: { type: String },
    campaign_id: { type: String },
    pg_response: Object,
    // hash: String,
    pgStatus: {
        type: String,
        default: "Not-initiated",
        enum: ["Not-initiated", "Initiated", "success", "failure"]
    }

}, {
    timestamps: true
})



const Transaction = mongoose.model("Transaction", transactionSchema);

module.exports = { Transaction }