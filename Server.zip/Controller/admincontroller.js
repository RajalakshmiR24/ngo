const { Admin } = require("../Model/admin");
const { Campaign } = require("../Model/campaign.js");
const { FundRequestModel } = require("../Model/fund.js");
const { Transaction } = require("../Model/transaction");
const { User, ImageModel } = require("../Model/user");
const bcrypt = require("bcrypt")
const { userRefreshToken } = require("./usercontroller");
const crypto = require("crypto");
const jwt = require("jsonwebtoken");
const { BillModel } = require("../Model/bills.js");


//admin 
const registerAdmin = async (req, res) => {

    const { name, email, password, mobilenumber } = req.body;

    // console.log(req.body, "register");

    if (!email || !password || !mobilenumber || !name) {
        return res.status(200).json({ code: 400, message: "Email,name, mobilenumber and password required" })
    }

    try {
        const countAdmin = await Admin.countDocuments();
        if (countAdmin === 1) {
            return res.status(200).json({ code: 400, message: "Cannot create another admin" })
        }
        const existedAdminEmail = await Admin.findOne({ email: email });
        const existedMobileNumber = await Admin.findOne({ mobile_number: mobilenumber })

        // console.log(existedAdminEmail);
        if (existedAdminEmail) {
            return res.status(200).json({ code: 400, message: "Email already registered" })
        }

        if (existedMobileNumber) {
            return res.status(200).json({ code: 400, message: "Mobilenumber exists" })
        }
        const admin = await Admin.create({ fullname: name, email: email, password: password, mobile_number: mobilenumber });

        const createdAdmin = await Admin.findById(admin._id).select("-password -refreshToken -mobile_number -_id");
        // console.log(createdAdmin);

        if (!createdAdmin) {
            return res.status(200).json({ code: 500, message: "Something went wrong" })
        }

        res.status(200).json({ code: 200, message: "Admin created successfully" })

    } catch (error) {
        return res.status(200).json({ code: 500, message: error.message })
    }
}

const generateAccessAndRefreshTokens = async (hash, req, res) => {
    // console.log(hash);
    try {
        const admin = await Admin.findOne({ email_hash: hash });
        const payload = {
            email_hash: admin.email_hash,
            role: "admin",
            date: admin.createdAt
        }
        // console.log(payload);
        try {
            const accessToken = jwt.sign(payload, process.env.ACCESS_TOKEN_SECRET_KEY, {
                expiresIn: process.env.ACCESS_TOKEN_EXPIRY,
            });

            const refreshToken = jwt.sign(payload, process.env.REFRESH_TOKEN_SECRET_KEY, {
                expiresIn: process.env.REFRESH_TOKEN_EXPIRY,
            });

            admin.refreshToken = refreshToken;

            await admin.save({ validateBeforeSave: false });
            return { accessToken, refreshToken };
        } catch (error) {
            throw new Error("Token generation failed");
        }

    } catch (error) {
        return res.status(200).json({ code: 500, ErrorMessage: error.message })

    }
}

const adminLogin = async (req, res) => {
    const { email, password } = req.body;
    // console.log(req.body);

    // console.log(userSchema);
    if (!email || !password) {
        return res.status(200).json({ code: 400, message: "Email and password required" })
    }


    try {
        const admin = await Admin.findOne({ email: email })

        // console.log(admin);
        if (!admin) {
            return res.status(200).json({ code: 400, message: "admin not found" })
        }

        const isPasswordValid = await bcrypt.compare(password, admin.password);

        // console.log(isPasswordValid);
        if (!isPasswordValid) {
            return res.status(200).json({ code: 400, message: "Incorrect password" })
        }

        const { refreshToken, accessToken } = await generateAccessAndRefreshTokens(admin.email_hash);
        // console.log(refreshToken);

        const loggedAdmin = await Admin.findOne({ email: email }).select("-password -refreshToken -campaigndetails");
        // console.log(loggedAdmin, "loggg");

        const options = {
            httpOnly: true,
            secure: true,
        }

        return res.status(200).json(
            {
                code: 200,
                accessToken,
                hash: loggedAdmin.email_hash,
                message: "Admin Logged in successfully"
            })


    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}

const updateAdminDetailsByEmailHash = async (req, res) => {
    const { hash, info } = req.body;
    // const id = req.params.id;

    const filter = { email_hash: hash }
    const updatedInfo = { $set: { info } };
    try {
        const admin = await Admin.updateOne(filter, updatedInfo, { new: true });

        // console.log(result.matchedCount);
        if (admin.matchedCount > 0) {
            res.status(200).json({
                code: 200,
                message: "Data updated successfully",
                matchedCount: result.matchedCount,
                modifiedCount: result.modifiedCount
            });
        } else {
            res.status(404).json({ code: 404, message: "No documents matched the filter" });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ code: 500, errorMessage: error.message });
    }
}

const findAdminByEmailHash = async (req, res) => {
    const { hash } = req.body;
    // const id = req.params.id;

    try {
        const admin = await Admin.findOne({ email_hash: hash }).populate('Campaign').exec();
        if (!admin) {
            return res.status(200).json({ code: 400, message: "No admin found" });
        }
        return res.status(200).json({ code: 200, data: admin });

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }
}

const findAdminByEmail = async (req, res) => {
    const { email } = req.body;

    try {
        const admin = await Admin.findOne({ email: email });
        if (!admin) {
            return res.status(200).json({ code: 400, message: "No admin found" });
        }
        return res.status(200).json({ code: 200, data: admin });

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }

}
const deleteAdminByEmail = async (req, res) => {
    const { hash } = req.body;
    // const id = req.params.id;
    try {
        const admin = await Admin.deleteOne({ email_hash: hash });
        if (!admin) {
            return res.status(200).json({ code: 400, message: "No admin found" });
        }
        return res.status(200).json({ code: 200, message: "Admin deleted successfully" });

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }
}

const adminLogout = async (req, res) => {

    if (!req.headers("authorization")) {
        res.status(200).json({ code: 400, message: "Admin not logged in" })
    }
    // Clear the cookie

    res.headers("");

    res.status(200).json({ code: 200, message: "Admin logged out successfully" })
}

const makeAdmin = async (req, res) => {
    try {
        const { email } = req.body;
        const user = await User.findOne({ email_hash: email });
        if (!user) {
            return res.status(200).json({ code: 400, message: "No user found" })
        }
        const campaignDatas = await Campaign.find({ user_email: { $exists: true } })
        if (campaignDatas) {
            const campaings = await Campaign.updateMany({ user_email: email },
                {
                    $unset: { user_email: "" },
                    $set: { admin_email: email },
                },
                { new: true }
            );
            if (!campaignDatas) {
                return res.status(200).json({ code: 400, message: "Error updating campaign datas" })
            }
        }
        user.role = "ADMIN";
        user.save();
        return res.status(200).json({ code: 200, message: "Admin created successfully" })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}

const makeUser = async (req, res) => {
    try {
        const { email } = req.body;
        const user = await User.findOne({ email_hash: email });
        if (!user) {
            return res.status(200).json({ code: 400, message: "No admin found" })
        }
        const campaignDatas = await Campaign.find({ admin_email: { $exists: true } })
        if (campaignDatas) {
            const campaings = await Campaign.updateMany({ admin_email: email },
                {
                    $set: { user_email: email },
                    $unset: { admin_email: "" },
                },
                { new: true }
            );
            if (!campaignDatas) {
                return res.status(200).json({ code: 400, message: "Error updating campaign datas" })
            }
        }
        user.role = "USER";
        user.save();
        return res.status(200).json({ code: 200, message: "User changed successfully" })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}

const createHashEmail = (inputEmail) => {
    if (!inputEmail) {
        return res.status(400).send({ error: 'Email is required' });
    }

    const hash = crypto.createHash('sha256');
    hash.update(inputEmail);
    const hashedInputEmail = hash.digest('hex');

    return hashedInputEmail;
};


//dashboard
//chart api



const getCampaignDetailsPerUserByEmailHash = async (req, res) => {
    const { hash } = req.body;
    try {
        const campaigns = await User.find(
            { email_hash: hash },
            { campaigndetails: 1, _id: 0, email_hash: 1 }
        ).lean();

        if (!campaigns.length) {
            return res.status(200).json({ code: 400, message: "No campaigns found" });
        }

        const filteredCampaigns = campaigns.map(user => {
            return user.campaigndetails.map(campaign => ({
                campaign_id: campaign.campaign_id,
                email_hash: user.email_hash, // Include email_hash in the response
                campaign_title: campaign.campaign_title,
                campaign_type: campaign.campaign_type,
                campaign_description: campaign.campaign_description,
                campaign_address: campaign.campaign_address,
                start_date: campaign.start_date,
                end_date: campaign.end_date,
                status: campaign.status
            }));
        }).flat(); // Flatten the array to avoid nested arrays

        return res.status(200).json({ code: 200, data: filteredCampaigns });
    } catch (error) {
        console.error("Error fetching campaign details:", error); // Log the error
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }
};






const getCampaignCountByMonth = async (req, res) => {


}

const getCampaignCountByYear = async (req, res) => {

}
const getLiveCampaings = async (req, res) => {

}
const getCancelledCampaings = async (req, res) => {

}
const getCompletedCampaings = async (req, res) => {

}
const getUpcomingCampaings = async (req, res) => {

}
const getApprovedCampaings = async (req, res) => {

}
const getNotApprovedCampaings = async (req, res) => {

}






const expensesPerCampaign = async (req, res) => {

}

const cancelRegisteredCampaignWithReasonByUser = async (req, res) => {


}
const getCampaignDetailsByCampaignId = async (req, res) => {
    const { campId } = req.body;

    try {
        const campaignDetail = await User.aggregate([
            {
                $match: {
                    "campaigndetails.campaign_id": campId // Match by campaign_id
                }
            },
            {
                $unwind: "$campaigndetails" // Flatten the campaigndetails array
            },
            {
                $match: {
                    "campaigndetails.campaign_id": campId // Match again after unwinding
                }
            },
            {
                $project: {
                    _id: 0, // Exclude the user's _id from the result
                    email_hash: 1,
                    campaign: {
                        campaign_id: "$campaigndetails.campaign_id",
                        campaign_title: "$campaigndetails.campaign_title",
                        campaign_type: "$campaigndetails.campaign_type",
                        campaign_description: "$campaigndetails.campaign_description",
                        start_date: "$campaigndetails.start_date",
                        end_date: "$campaigndetails.end_date",
                        campaign_address: "$campaigndetails.campaign_address",
                        budget: "$campaigndetails.budget",
                        status: "$campaigndetails.status"
                    }
                }
            }
        ]);

        // Check if any campaign details were found
        if (campaignDetail.length === 0) {
            return res.status(200).json({ code: 400, message: "No campaigns found for this ID" });
        }

        return res.status(200).json({ code: 200, data: campaignDetail });
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message });
    }
};

//registeredUsers

async function findAllUsers(req, res) {
    try {
        const users = await User.find({}).select("-refreshToken -password -_id")
            .populate({
                path: 'campaigns',
                select: '-_id -user_email'
            })
            .populate({
                path: 'bills',
                select: '-_id'
            })
            .exec();
        ;
        // console.log(users);
        return res.status(200).json({ code: 200, data: users })
    } catch (error) {
        // console.error("Error finding users:", error);
        return res.status(200).json({ code: 400, message: "No users found" })
    }
}

const findUserByEmailHash = async (req, res) => {
    const { hash } = req.body;
    // const id = req.params.id;

    try {
        const user = await User.findOne({ email_hash: hash }).select("-refreshToken -_id -email_hash");
        if (!user) {
            return res.status(200).json({ code: 400, message: "No user found" });
        }
        return res.status(200).json({ code: 200, data: user });

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }
}


const getTransactionDetailsPerCampaignType = async (req, res) => {
    const { campaigntype } = req.body;
    try {
        const transaction = await Transaction.aggregate([
            {
                $match: {
                    campaigndetails: {
                        $elemMatch: { "campaign_type": campaigntype } // Match documents with an address in the specified city
                    }
                }
            }
        ]);
        if (transaction.length > 0) {
            return res.status(200).json({ code: 200, data: transaction })
        }
        return res.status(200).json({ code: 400, message: "no transactions found" })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }

}

const getTransactionDetailsPerDay = async (req, res) => {


}

const insertCampaignDataByEmailHash = async (req, res) => {
    // const { fullName, companyRole } = req.body;
    // console.log(req.body);
    const bannerImage = req.file ? req.file.path : null;
    // const user = new User();
    // console.log(bannerImage);
    // try {
    //   await user.save();
    //   res.send("Data successfully inserted");
    // } catch (error) {
    //   res.status(500).send("There was an error inserting the data");
    // }
    const { hash, info } = req.body;
    if (!info) {

        return res.status(200).json({ code: 400, message: "No data received" })
    }
    try {
        const result = await Admin.updateOne({ email_hash: hash }, { $push: { campaigndetails: info } }, { new: true })
        if (result.modifiedCount > 0) {
            return res.status(200).json({ code: 200, message: "Object added into array successfully" })
        }
        else {
            return res.status(200).json({ code: 400, message: "Unsuccessfull" })
        }
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }
}


const getTransactionDetailsPerMonth = async (req, res) => {

}
const getTransactionDetailsPerYear = async (req, res) => {

}


const getRegisteredUserClaimingAmount = async (req, res) => {

}

const getRegisteredUserClaimAmountBillDetails = async (req, res) => {

}
const approveRegisteredUserClaimingAmount = async (req, res) => {

}
const getRegisteredUserExpenseAmount = async (req, res) => {

}

const getCancelRequest = () => {

}
//general user management

const getUserFundRequest = async (req, res) => {
    try {
        const userfundRequest = await FundRequestModel.find({}, { _id: 0 });

        if (!userfundRequest) {
            return res.status(200).json({ data: [], code: 201 });
        }
        return res.status(200).json({ data: userfundRequest, code: 200 });
    } catch (error) {
        return res.status(200).json({ msg: "something went wrong", code: 500 });
    }
}

const getTransactionDataPerCampaigns = async (req, res) => {


}

//verify request

const getUserDetailsToVerify = async (req, res) => {

    try {
        const users = await User.find({ status: "NOT_ACTIVE" }, { _id: 0, role: 0, password: 0, campaigns: 0, refreshToken: 0 });
        if (!users) {
            return res.status(200).json({ code: 400, message: "No users found" })
        }
        return res.status(200).json({ code: 200, data: users })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }


}

const getCampaignRequestToVerify = async (req, res) => {
    try {
        const campaigns = await Campaign.find({ status: "NOT_APPROVED" }, { _id: 0, user_email: 0, bills: 0 });

        if (!campaigns) {
            return res.status(200).json({ code: 400, message: "No request to verify" })
        }
        return res.status(200).json({ code: 200, data: campaigns })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message });

    }

}
//reject request
const rejectOrApproveUserRegistration = async (req, res) => {

    try {
        const { email, status } = req.body;
        if (!email) {
            return res.status(200).json({ code: 400, message: "Email required" })
        }

        // const findUser = await User.findOne({ email_hash: email, status: "ACTIVE" || "REJECTED" })
        // if (findUser) {
        //     return res.status(200).json({ code: 400, message: "User is already active or rejected" })
        // }
        const user = await User.updateOne({ email_hash: email }, { $set: { status: status } })
        if (!user) {
            return res.status(200).json({ code: 400, message: "No user to reject" })
        }
        return res.status(200).json({ code: 200, message: `${status} successfully` })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }


}


// const approveOrRejectCampaignRequest = async (req, res) => {
//     const { campaign_id, status } = req.body;
//     try {
//         if (!campaign_id) {
//             return res.status(200).json({ code: 400, message: "Campaign ID is missing" })
//         }
//         if (!status) {
//             return res.status(200).json({ code: 400, message: "status required" })
//         }

//         const result = await Campaign.updateOne(
//             { campaign_id },
//             { $set: { status: status } }
//         );
//         if (result.modifiedCount > 0) {
//             return res.status(200).json({ code: 200, message: "updated Successfully" });
//         }

//         return res.status(200).json({ code: 400, message: "status update unsuccessfull" });

//     } catch (error) {
//         return res.status(200).json({ code: 500, errorMessage: error.message });

//     }

// }
const approveOrRejectCampaignRequest = async (req, res) => {
    const { campaign_id, status } = req.body;
    console.log(req.body);

    try {
        if (!campaign_id) {
            return res.status(200).json({ code: 400, message: "Campaign ID is missing" });
        }
        if (!status) {
            return res.status(200).json({ code: 400, message: "Status is required" });
        }

        const result = await Campaign.updateOne(
            { campaign_id: campaign_id },
            { $set: { status: status } }
        );
        console.log(result);


        if (result.modifiedCount > 0) {

            return res.status(200).json({ code: 200, message: "Updated successfully" });
        }



        return res.status(200).json({ code: 400, message: "Status update unsuccessful" });

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message });
    }
};



const getCampaignRequestedRegisteredUserDetails = async (req, res) => {

}



const insertBillDetailsIntoCampaign = async (req, res) => {

    const { hash, camp_id, info } = req.body;
    if (!info) {

        return res.status(200).json({ code: 400, message: "No data received" })
    }
    try {
        const result = await User.updateOne(
            { "campaigndetails.campaign_id": camp_id },
            { $push: { "campaigndetails.$.bills": info } }, { new: true }
        );
        if (result.modifiedCount > 0) {
            return res.status(200).json({ code: 200, message: "bills are added successfully" });
        }
        else {
            return res.status(200).json({ code: 400, message: "Unsuccessfull" })
        }
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }

}





//Queries

const getAllQueries = async (req, res) => {

}

//RegisteredUser Queries
const getAllRegisteredUserQueries = async (req, res) => {

}
const getRegisteredUserQueriesByEmailHash = async (req, res) => {

}
const getRegisteredUserQueriesByCampaign = async (req, res) => {

}
const getRegisteredUserQueriesByCampaignType = async (req, res) => {

}
const getRegisteredUserQueriesByLocation = async (req, res) => {

}



//GeneralUser Queries
const getAllGeneralUserQueries = async (req, res) => {

}
const getGeneralUserQueriesByCampaign = async (req, res) => {

}
const getGeneralUserQueriesByCampaignType = async (req, res) => {

}
const getGeneralUserQueriesByLocation = async (req, res) => {

}

//image
const uploadImage = async (req, res) => {
    const { base64Image, campId, email_hash } = req.body;
    // console.log(req.body);
    const buffer = Buffer.from(base64Image, 'base64');
    const image = await ImageModel.create({
        data: buffer,
        email_hash: email_hash,
        campaign_id: campId,
        contentType: 'image/png'
    });

    await image.save();
    res.send('Image uploaded successfully');
};

const fetchImage = async (req, res) => {
    const { campId, email_hash } = req.body;
    // console.log(req.body);
    try {
        const images = await ImageModel.find({ campaign_id: campId, email_hash: email_hash });
        if (!images || images.length === 0) {
            return res.status(404).json({ code: 400, message: "Images not found" });
        }

        const imageData = images.map(image => ({
            id: image._id,
            contentType: image.contentType,
            data: image.data.toString('base64')
        }));

        return res.status(200).json({ code: 200, data: imageData });
    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }
};



module.exports = {
    registerAdmin, makeAdmin, makeUser, uploadImage, fetchImage, getCampaignDetailsByCampaignId,
    adminLogout, insertCampaignDataByEmailHash,
    insertBillDetailsIntoCampaign,
    getCampaignDetailsPerUserByEmailHash, approveOrRejectCampaignRequest, getUserDetailsToVerify,
    getTransactionDetailsPerCampaignType, getCampaignRequestToVerify,
    rejectOrApproveUserRegistration, findAdminByEmail,
    getUserFundRequest,
    findUserByEmailHash, deleteAdminByEmail, generateAccessAndRefreshTokens, adminLogin,
    findAllUsers, updateAdminDetailsByEmailHash, findAdminByEmailHash
}