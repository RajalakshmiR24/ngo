const express = require("express");
const { saveQueries } = require("../Controller/querycontroller");
const { uploadImage, fetchImage } = require("../Controller/admincontroller");

const router = express.Router();


router.post("/savequeries", saveQueries);


router.post("/bannerimage", uploadImage);
router.post("/fetchbannerimage", fetchImage);

module.exports = { router };
