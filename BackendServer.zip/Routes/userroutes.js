const express = require("express");
const { userLogin, userData, registerUser, getUsersCount, insertCampaignDataByEmailHash, userLogout } = require("../Controller/usercontroller");
const { verifyToken } = require("../Middlewares/auth");
const multer = require("multer");
const { saveTransaction, getAllTransactionDetails } = require("../Controller/transactioncontroller");
const { insertBillDetailsIntoCampaign, uploadImage, fetchImage } = require("../Controller/admincontroller");
const userRouter = express.Router();

userRouter.post("/register", registerUser);
userRouter.post("/login", userLogin)
userRouter.get('/data', verifyToken, userData)
userRouter.get("/count", verifyToken, getUsersCount);
userRouter.post("/logout", verifyToken, userLogout);



userRouter.post('/campaigndata', insertCampaignDataByEmailHash);


//transaction
userRouter.post("/savetr", saveTransaction);
userRouter.get("/gettr", getAllTransactionDetails);




userRouter.post("/savebills", insertBillDetailsIntoCampaign);


userRouter.post("/image", uploadImage);
userRouter.post("/fetchimage", fetchImage);


module.exports = userRouter;