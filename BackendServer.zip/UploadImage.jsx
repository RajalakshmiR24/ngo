import React, { useState } from 'react';
import axios from 'axios';

const UploadImage = () => {
    const [file, setFile] = useState(null);
    const [imageSrcs, setImageSrcs] = useState([]); 
    const [error, setError] = useState('');

    const handleFileChange = (e) => {
        setFile(e.target.files[0]);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const reader = new FileReader();
        reader.onloadend = async () => {
            const base64Image = reader.result.split(',')[1];
            await axios.post('http://localhost:5000/general/bannerimage', { campId: "7837385f-32e4-42f9-89ce-6f91347532b9",email_hash:"02ee7bdc4ccf5c94808a0118eb531822f13e7e38e3810ab29ebefb2c2feb8e58", base64Image });
            alert('Image uploaded successfully');
        };
        reader.readAsDataURL(file);
    };

    const fetchImages = async () => {
        try {
            const response = await axios.post(
                `http://localhost:5000/general/fetchbannerimage`,
                { campId: "7837385f-32e4-42f9-89ce-6f91347532b9",
                    email_hash:"02ee7bdc4ccf5c94808a0118eb531822f13e7e38e3810ab29ebefb2c2feb8e58"
                 } 
            );

            if (response.data.code === 200) {
                const images = response.data.data.map(image => 
                    `data:${image.contentType};base64,${image.data}` 
                );
                setImageSrcs(images); 
            }
        } catch (err) {
            console.error('Error fetching images:', err);
            setError('Failed to fetch images');
        }
    };

    return (
        <div>
            <h1>Upload Image</h1>
            <form onSubmit={handleSubmit}>
                <input type="file" onChange={handleFileChange} accept="image/*" />
                <button type="submit">Upload</button>
            </form>
            <button onClick={fetchImages}>Download</button>

            <div>
                {error && <p>{error}</p>}
                {imageSrcs.map((src, index) => (
                    <img key={index} src={src} alt={`Fetched ${index}`} />
                ))}
            </div>
        </div>
    );
};

export default UploadImage;
