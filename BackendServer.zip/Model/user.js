const mongoose = require("mongoose")

const bcrypt = require("bcrypt")
const jwt = require("jsonwebtoken")
const crypto = require("crypto");
const { campaignSchema } = require("./campaign");

const userSchema = new mongoose.Schema({
    fullname: {
        type: String,
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    current_address: {
        type: String
    },
    id_proof: [Object],
    password: {
        type: String,
        required: true,
    },
    mobile_number: {
        type: String,
        unique: true
    },
    account_created_date: {
        type: Date,
        default: Date.now,
    },
    campaigndetails: [campaignSchema],
    email_hash: {
        type: String
    },

    bank_account_details: [Object],

    // role: {
    //     type: String,
    //     enum: ['USER', 'ADMIN', 'VOLUNTEER'],
    //     default: "USER"
    // },
    refreshToken: {
        type: String
    },

    createdAt: {
        type: Date,
        default: Date.now
    },
    status: {
        type: String,
        enum: ["ACTIVE", "NOT_ACTIVE", "REJECTED"],
        default: "NOT_ACTIVE"
    }

},
    {
        timestamps: true
    })


userSchema.pre("save", async function (next) {
    if (!this.isModified("password")) {
        return next()
    }
    let saltRounds = 10;
    this.password = await bcrypt.hash(this.password, saltRounds);

    try {
        const hash = crypto.createHash('sha256');
        hash.update(this.email);
        const hashedData = hash.digest('hex');
        this.email_hash = hashedData;
        next();
    } catch (error) {
        console.log("error in saving emailhash", error);
    }
})

userSchema.methods.isPasswordCorrect = async function (password) {
    return await bcrypt.compare(password, this.password);
}

userSchema.methods.generateAccessToken = function () {
    const payload = {
        email_hash: admin.email_hash,
        role: "user",
        date: admin.createdAt
    }

    return jwt.sign(payload, process.env.ACCESS_TOKEN_SECRET_KEY, { expiresIn: process.env.ACCESS_TOKEN_EXPIRY })
}

userSchema.methods.generateRefreshToken = function () {
    const payload = {
        email_hash: admin.email_hash,
        role: "user",
        date: admin.createdAt
    }

    return jwt.sign(payload, process.env.REFRESH_TOKEN_SECRET_KEY, { expiresIn: process.env.REFRESH_TOKEN_EXPIRY })

}

userSchema.statics.countTotalUsers = function () {
    return this.countDocuments({});
}

userSchema.statics.getAllUserCampaignDetails = async function () {
    try {
        const campaignDetails = await User.find({}, ["campaigndetails", "-_id"]);
        return campaignDetails;
    } catch (error) {
        console.log("problem in fetching campaigndetails", error);

    }

}

userSchema.statics.getTotalCampaignCount = async function () {
    const campaigns = await User.find({}, ["campaigndetails", "-_id"]);
    const totalCampaignCount = campaigns.reduce((total, item) => {
        if (Array.isArray(item.campaigndetails)) {
            return total + item.campaigndetails.length; 
        }
        return total;
    }, 0);

    return totalCampaignCount


}

userSchema.methods.getUserCampaignCount = async function () {
    const campaigns = await User.find({}, ["campaigndetails", "-_id"]);
    // Assuming campaignDetails is an array, flatten it and count
    const totalCampaignCount = campaigns.reduce((total, item) => {
        // Assuming campaignDetails is an array in each user document
        if (Array.isArray(item.campaignDetails)) {
            return total + item.campaignDetails.length; // Count campaigns in each user document
        }
        return total; // If not an array, just return the total
    }, 0);
    return totalCampaignCount;

}


const imageSchema = new mongoose.Schema({
    data: Buffer,
    campaign_id: { type: String },
    email_hash: { type: String },
    contentType: { type: String }
});

const ImageModel = mongoose.model('Image', imageSchema);


const User = mongoose.model("user", userSchema);

module.exports = { User, ImageModel, imageSchema }










