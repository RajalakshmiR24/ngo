const mongoose = require("mongoose")

const bcrypt = require("bcrypt")
const jwt = require("jsonwebtoken")
const crypto = require("crypto");
const { v4: uuidv4 } = require('uuid');


const adminSchema = new mongoose.Schema({
    fullname: {
        type: String
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true,
    },

    mobile_number: {
        type: String,
        unique: true
    },

    campaigndetails: [{
        campaign_id: { type: String, default: uuidv4, unique: true },
        campaign_title: { type: String, required: true },
        campaign_type: { type: String },
        campaign_description: { type: String },
        start_date: { type: Date },
        end_date: { type: Date },
        campaign_address: { type: String },
        budget: { type: String, default: "0" },
        bills: [
            {
                bill_id: { type: String, default: uuidv4, unique: true },
                files: { type: String, required: true },
                status: {
                    type: String,
                    enum: ['PENDING', 'APPROVED', 'VERIFIED'],
                    default: 'PENDING'
                },
                uploadedAt: { type: Date, default: Date.now }
            }
        ],
        status: { type: String, enum: ['LIVE', 'COMPLETED', 'CANCELLED', 'UPCOMING', "APPROVED"], default: 'APPROVED' },
        reason_for_cancellation: { type: String, default: "NA" }
    }],
    email_hash: {
        type: String
    },
    // role: {
    //     type: String,
    //     enum: ['USER', 'ADMIN', 'VOLUNTEER'],
    //     default: "USER"
    // },
    refreshToken: {
        type: String
    },

},
    {
        timestamps: true
    })


adminSchema.pre("save", async function (next) {
    if (!this.isModified("password")) {
        return next()
    }
    let saltRounds = 12;
    this.password = await bcrypt.hash(this.password, saltRounds);

    try {
        const hash = crypto.createHash('sha256');
        hash.update(this.email);
        const hashedData = hash.digest('hex');
        this.email_hash = hashedData;
        next();
    } catch (error) {
        console.log("error in saving emailhash", error);
    }

})

adminSchema.methods.isPasswordCorrect = async function (password) {
    return await bcrypt.compare(password, this.password);
}

// adminSchema.methods.generateAccessToken = function () {
//     const payload = {
//         email_hash: this.email_hash,
//         date: this.createdAt
//     }

//     return jwt.sign(payload, process.env.ACCESS_TOKEN_SECRET_KEY, { expiresIn: process.env.ACCESS_TOKEN_EXPIRY })
// }

// adminSchema.methods.generateRefreshToken = function () {
//     const payload = {
//         email_hash: this.email_hash,
//         date: this.createdAt
//     }

//     return jwt.sign(payload, process.env.REFRESH_TOKEN_SECRET_KEY, { expiresIn: process.env.REFRESH_TOKEN_EXPIRY })

// }

adminSchema.methods.getEmailHash = function () {
    return this.email_hash;

}
adminSchema.statics.getAllAdminCampaignDetails = async function () {
    try {
        const campaignDetails = await Admin.find({}, ["campaigndetails", "-_id"]);
        return campaignDetails;
    } catch (error) {
        console.log("problem in fetching campaigndetails", error);

    }

}



const Admin = mongoose.model("admin", adminSchema);

module.exports = { Admin }










