const mongoose = require("mongoose");
const { v4: uuidv4 } = require('uuid');


const transactionSchema = new mongoose.Schema({
    name: {
        type: String,
    },
    email: {
        type: String
    },
    amount: {
        type: String,
    },
    mobilenumber: {
        type: String,
    },

    transactionid: {
        type: String
    },
    campaigndetails: [{
        campaign_id: { type: String, default: uuidv4, unique: true },
        campaign_title: { type: String, required: true },
        campaign_type: { type: String },
        campaign_description: { type: String },
        start_date: { type: Date },
        end_date: { type: Date },
        campaign_address: { type: String },
        budget: { type: String, default: "0" },
        bills: [
            {
                bill_id: { type: String, default: uuidv4, unique: true },
                files: { type: String, required: true },
                status: {
                    type: String,
                    enum: ['PENDING', 'APPROVED', 'VERIFIED'],
                    default: 'PENDING'
                },
                uploadedAt: { type: Date, default: Date.now }
            }
        ],
        status: { type: String, enum: ['LIVE', 'COMPLETED', 'CANCELLED', 'UPCOMING', "APPROVED"], default: 'APPROVED' },
        reason_for_cancellation: { type: String, default: "NA" }
    }],
    pg_response: [Object],

}, {
    timestamps: true
})



const Transaction = mongoose.model("transaction", transactionSchema);

module.exports = { Transaction }