import React, { useState } from 'react';
import axiosInstance from '../../../Utils/axiosInstance';
import { useNavigate } from 'react-router-dom';
import Form from '../../Common/Form/Form';
import Input from '../../Common/Form/Input';
import { validateForm } from '../../../Utils/Validation';
import './Style.css'

const AdminSignIn = () => {
    const [info, setInfo] = useState({});
    const [errorMessage, setErrorMessage] = useState('');
    const [formErrors, setFormErrors] = useState({});
    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setInfo((prevState) => ({
            ...prevState,
            [name]: value,
        }));
        setErrorMessage('');
        setFormErrors((prev) => ({ ...prev, [name]: undefined }));
    };

    const handleSubmit = (e) => {
        e.preventDefault(); // Prevent default form submission behavior
    
        console.log(info); // Log the info object
        const errors = validateForm(info);
        console.log(errors); // Log the errors object
    
        if (Object.keys(errors).length > 0) {
            setFormErrors(errors);
            return;
        }
    
        axiosInstance.post('/admin/login', info)
            .then((res) => {
                if (res.data.code === 200) {
                    setInfo({});
                    localStorage.setItem("token", res.data.accessToken);
                    localStorage.setItem("hash", res.data.hash);

                    navigate("/admin");
                }
            })
            .catch((error) => {
                console.error('Login error:', error); // Log the entire error
                if (error.response) {
                    // The request was made, but the server responded with a status code
                    console.error('Response data:', error.response.data);
                    setErrorMessage(error.response.data.message || 'An error occurred.');
                } else {
                    // Something happened in setting up the request
                    setErrorMessage('An error occurred. Please try again.');
                }
            });
            
    };
    
    return (
        <div className="app-container">
            <h1>Admin Login</h1>
            <Form onSubmit={handleSubmit}>
                <div className="form-group">
                    <Input 
                        type="text" 
                        name="email" 
                        placeholder="Email" 
                        value={info.email || ""} 
                        onChange={handleChange} 
                    />
                    {formErrors.email && <p className="error-message">{formErrors.email}</p>}
                </div>
                <div className="form-group">
                    <Input 
                        type="password" 
                        name="password" 
                        placeholder="Password" 
                        value={info.password || ""} 
                        onChange={handleChange} 
                    />
                    {formErrors.password && <p className="error-message">{formErrors.password}</p>}
                </div>
                <button type="submit">Login</button>
                {errorMessage && <p className="error-message">{errorMessage}</p>}
            </Form>
        </div>
    );
};

export default AdminSignIn;
