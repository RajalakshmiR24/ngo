import React, { useEffect, useState } from 'react';
import './Barchart.css';
import { Line } from 'react-chartjs-2';
import axiosInstance from '../../../../../../Utils/axiosInstance';
import { Chart as ChartJS, LineElement, PointElement, LinearScale, CategoryScale, Title, Tooltip, Legend } from 'chart.js';

ChartJS.register(LineElement, PointElement, LinearScale, CategoryScale, Title, Tooltip, Legend);

const LineChart = () => {
    const [chartData, setChartData] = useState({
        labels: [],
        datasets: [
            {
                label: 'Total Contributions',
                data: [],
                borderColor: 'lightgreen',
                backgroundColor: 'rgba(144, 238, 144, 0.2)',
                fill: true,
            },
            {
                label: 'Total Expenses',
                data: [],
                borderColor: 'lightcoral',
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                fill: true,
            },
        ],
    });

    const options = {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'Total Contributions and Expenses Over Time',
            },
        },
    };

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axiosInstance.get('/admin/totalcontributionsandexpenses'); // Adjust your API endpoint
                const result = response.data;

                // Assuming the result contains months, contributions, and expenses
                const labels = result.map(item => item.month); // Adjust based on your API response
                const contributions = result.map(item => item.contributions); // Adjust based on your API response
                const expenses = result.map(item => item.expenses); // Adjust based on your API response

                setChartData({
                    labels: labels,
                    datasets: [
                        {
                            label: 'Total Contributions',
                            data: contributions,
                            borderColor: 'lightgreen',
                            backgroundColor: 'rgba(144, 238, 144, 0.2)',
                            fill: true,
                        },
                        {
                            label: 'Total Expenses',
                            data: expenses,
                            borderColor: 'lightcoral',
                            backgroundColor: 'rgba(255, 99, 132, 0.2)',
                            fill: true,
                        },
                    ],
                });

                alert('Data fetched successfully!'); // Confirmation message
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        fetchData();
    }, []);

    return (
        <div style={{ height: "40vh", width: "800px" }} className='line_chart'>
            <h2>Total Contributions and Expenses</h2>
            <Line data={chartData} options={options} />
        </div>
    );
};

export default LineChart;
