import React, { useEffect, useState } from 'react';
import axiosInstance from '../../../../Utils/axiosInstance';

const RequestUsersAndFunds = () => {
  const [users, setUsers] = useState([]);
  const [fundRequests, setFundRequests] = useState([]);
  const [camp, setCamp] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('users');

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const userResponse = await axiosInstance.get('/admin/verifyuserdetails');
        const fundResponse = await axiosInstance.get('/admin/fund-requests');
        const campResponse = await axiosInstance.get('/admin/campaignstatustoverify');

        if (userResponse.data?.data) setUsers(userResponse.data.data);
        if (fundResponse.data?.data) setFundRequests(fundResponse.data.data);
        if (campResponse.data?.data) setCamp(campResponse.data.data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const updateUserStatus = async (emailHash, status) => {
    try {
      await axiosInstance.post(`/admin/updateUser/${emailHash}`, { status });
      // Refresh user data after update
      fetchData();
    } catch (err) {
      setError(err.message);
    }
  };

  const handleUserAction = (emailHash, action) => {
    if (action === 'verify') updateUserStatus(emailHash, 'verified');
    if (action === 'reject') updateUserStatus(emailHash, 'rejected');
    // Add a view action if needed
  };

  const verifyCamp = async (emailHash) => {
    // Implement campaign verification
    await updateCampaignStatus(emailHash, 'verified');
  };

  const rejectCamp = async (emailHash) => {
    await updateCampaignStatus(emailHash, 'rejected');
  };

  const updateCampaignStatus = async (emailHash, status) => {
    try {
      await axiosInstance.post(`/admin/updateCampaign/${emailHash}`, { status });
      fetchData();
    } catch (err) {
      setError(err.message);
    }
  };

  const verifyFundRequest = async (fundId) => {
    await updateFundRequestStatus(fundId, 'verified');
  };

  const rejectFundRequest = async (fundId) => {
    await updateFundRequestStatus(fundId, 'rejected');
  };

  const updateFundRequestStatus = async (fundId, status) => {
    try {
      await axiosInstance.post(`/admin/updateFundRequest/${fundId}`, { status });
      // Refresh fund request data after update
      fetchData();
    } catch (err) {
      setError(err.message);
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div>
      <h2>Management Dashboard</h2>
      <div>
        <button onClick={() => setActiveTab('users')}>Users</button>
        <button onClick={() => setActiveTab('funds')}>Funds</button>
        <button onClick={() => setActiveTab('camp')}>Campaigns</button>
      </div>

      {activeTab === 'users' && (
        <>
          <h2>Users to Verify</h2>
          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {users.length > 0 ? (
                users.map(user => (
                  <tr key={user.email_hash}>
                    <td>{user.fullname}</td>
                    <td>{user.email}</td>
                    <td>{user.status}</td>
                    <td>
                      <button onClick={() => handleUserAction(user.email_hash, 'verify')}>Verify</button>
                      <button onClick={() => handleUserAction(user.email_hash, 'reject')}>Reject</button>
                      {/* Assuming a view function is needed */}
                      <button onClick={() => handleUserAction(user.email_hash, 'view')}>View</button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr><td colSpan="4">No user data found</td></tr>
              )}
            </tbody>
          </table>
        </>
      )}

      {activeTab === 'camp' && (
        <>
          <h2>Campaigns to Verify</h2>
          <table className="table">
            <thead>
              <tr>
                <th>Campaign Name</th>
                <th>Campaign Type</th>
                <th>Campaign Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {camp.length > 0 ? (
                camp.map(campaign => (
                  <tr key={campaign.email_hash}>
                    <td>{campaign.campaign_title}</td>
                    <td>{campaign.campaign_type}</td>
                    <td>{campaign.status}</td>
                    <td>
                      <button onClick={() => verifyCamp(campaign.email_hash)}>Verify</button>
                      <button onClick={() => rejectCamp(campaign.email_hash)}>Reject</button>
                      <button onClick={() => handleCamp(campaign.email_hash)}>View</button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr><td colSpan="4">No campaign data found</td></tr>
              )}
            </tbody>
          </table>
        </>
      )}

      {activeTab === 'funds' && (
        <>
          <h2>Fund Requests to Verify</h2>
          <table className="table">
            <thead>
              <tr>
                <th>Campaign Name</th>
                <th>Description</th>
                <th>Amount</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {fundRequests.length > 0 ? (
                fundRequests.map(fund => (
                  <tr key={fund.fund_id}>
                    <td>{fund.campaignName}</td>
                    <td>{fund.Description}</td>
                    <td>{fund.amount}</td>
                    <td>
                      <button onClick={() => verifyFundRequest(fund.fund_id)}>Verify</button>
                      <button onClick={() => rejectFundRequest(fund.fund_id)}>Reject</button>
                      <button onClick={() => viewFundRequest(fund)}>View</button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr><td colSpan="4">No funds available</td></tr>
              )}
            </tbody>
          </table>
        </>
      )}
    </div>
  );
};

export default RequestUsersAndFunds;
