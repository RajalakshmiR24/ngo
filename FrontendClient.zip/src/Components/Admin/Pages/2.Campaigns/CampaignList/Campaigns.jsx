import React, { useContext, useEffect, useState } from 'react';
import { CampaignContext } from '../../../../../Context/CampaignContext';
import axiosInstance from '../../../../../Utils/axiosInstance';
import './Campaigns.css';
import { resolvePath } from 'react-router-dom';

const Campaigns = () => {
  const {
    adminCampaigns,
    userCampaigns,
    loading,
    setAdminCampaigns,
    setUserCampaigns,
    setLoading,
    handleToggleCampaignType,
    activeCampaignType,
  } = useContext(CampaignContext);

  const [statusFilter, setStatusFilter] = useState('all');
  const [isCampaignFormModalOpen, setCampaignFormModalOpen] = useState(false);
  const [campaign, setCampaign] = useState({
    campaign_title: '',
    campaign_type: '',
    campaign_description: '',
    start_date: '',
    end_date: '',
    campaign_address: '',
    budget: '',
    reason_for_cancellation: 'NA'
  });
  // const [userDetails, setUserDetails] = useState([]);

  const openCampaignFormModal = () => setCampaignFormModalOpen(true);
  const closeCampaignFormModal = () => {
    setCampaignFormModalOpen(false);
    setCampaign({
      campaign_title: '',
      campaign_type: '',
      campaign_description: '',
      start_date: '',
      end_date: '',
      campaign_address: '',
      budget: '',
      reason_for_cancellation: 'NA'
    });
  };

  useEffect(() => {
    const fetchCampaigns = async () => {
      setLoading(true);
      try {
        const endpoint = activeCampaignType === 'user'
          ? '/admin/allusers'
          : '/admin/admincampaigndetails';

        const response = await axiosInstance.get(endpoint);

        // setUserDetails([...response.data.data])

        const allCampaigns = response.data.data.flatMap(item => item.campaigndetails);

        if (activeCampaignType === 'user') {
          setUserCampaigns(allCampaigns);
          setAdminCampaigns([]);
        } else {
          setAdminCampaigns(allCampaigns);
          setUserCampaigns([]);
        }
      } catch (error) {
        console.error('Error fetching campaign data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchCampaigns();
  }, [activeCampaignType, setLoading, setUserCampaigns, setAdminCampaigns]);

  const getCampaignStatus = (startDate, endDate) => {
    const now = new Date();
    const start = new Date(startDate);
    const end = new Date(endDate);

    if (now < start) return 'Upcoming';
    if (now >= start && now <= end) return 'Live';
    return 'Completed';
  };

  const filteredCampaigns = (campaigns) => {
    if (statusFilter === 'all') return campaigns;
    return campaigns.filter(campaign => getCampaignStatus(campaign.start_date, campaign.end_date).toLowerCase() === statusFilter);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCampaign(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // const hash = localStorage.getItem('email_hash'); 
    const hash = '81af6824ad53b1cae3f0c55a024093b68de6edc79ff886f6bc477caa421e4021'


    if (!hash) {
      console.error("Hash not found in local storage");
      return;
    }

    try {
      const response = await axiosInstance.post('/admin/campaigndata', {
        hash,
        info: campaign,
      });
      if (response.data.code === 200) {
        setAdminCampaigns(prev => [...prev, { ...campaign, _id: Date.now() }]); // Update local state with a temporary ID
        closeCampaignFormModal(); // Close the modal after successful submission
      } else {
        console.error("Submission unsuccessful:", response.data.message);
      }
    } catch (error) {
      console.error("Error submitting campaign data:", error);
    }
  };


  return (
    <div className="camp">
      <h1>Campaigns</h1>
      <button onClick={() => handleToggleCampaignType('admin')}>Admin Campaign</button>
      <button onClick={() => handleToggleCampaignType('user')}>User Campaign</button>

      {activeCampaignType === 'admin' && (
        <>
          <button onClick={openCampaignFormModal}>Create Admin Campaign</button>

          {/* Modal for Campaign Form */}
          {isCampaignFormModalOpen && (
            <div className="modal">
              <div className="modal-content">
                <form onSubmit={handleSubmit}>
                  <h2>Create Campaign</h2>

                  <input type="text" name="campaign_title" value={campaign.campaign_title} onChange={handleChange} placeholder="Campaign Title" />
                  <input type="text" name="campaign_type" value={campaign.campaign_type} onChange={handleChange} placeholder="Campaign Type" />
                  <textarea name="campaign_description" value={campaign.campaign_description} onChange={handleChange} placeholder="Description" />
                  <input type="date" name="start_date" value={campaign.start_date} onChange={handleChange} />
                  <input type="date" name="end_date" value={campaign.end_date} onChange={handleChange} />
                  <input type="text" name="campaign_address" value={campaign.campaign_address} onChange={handleChange} placeholder="Address" />
                  <input type="number" name="budget" value={campaign.budget} onChange={handleChange} placeholder="Estimated Budget" />

                  <button type="submit">Submit Campaign</button>
                  <button type="button" onClick={closeCampaignFormModal}>Close</button>
                </form>
              </div>
            </div>
          )}

          <section>
            <h2>Admin Campaign Overview</h2>
            <div>
              <button onClick={() => setStatusFilter('upcoming')}>Upcoming</button>
              <button onClick={() => setStatusFilter('live')}>Live</button>
              <button onClick={() => setStatusFilter('completed')}>Completed</button>
              <button onClick={() => setStatusFilter('all')}>All</button>
            </div>
            {loading ? (
              <p>Loading...</p>
            ) : (
              <table>
                <thead>
                  <tr>
                    <th>Campaign Name</th>
                    <th>Type</th>
                    <th>Budget</th>
                    <th>Location</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredCampaigns(adminCampaigns).map((campaign) => (
                    <tr key={campaign._id}>
                      <td>{campaign.campaign_title}</td>
                      <td>{campaign.campaign_type}</td>
                      <td>{campaign.budget || 'N/A'}</td>
                      <td>{campaign.campaign_address || 'N/A'}</td>
                      <td>
                        <button onClick={() => fetchDetails(campaign._id)}>View</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </section>
        </>
      )}

      {activeCampaignType === 'user' && (
        <section>
          <h2>User Campaign Overview</h2>
          <div>
            <button onClick={() => setStatusFilter('upcoming')}>Upcoming</button>
            <button onClick={() => setStatusFilter('live')}>Live</button>
            <button onClick={() => setStatusFilter('completed')}>Completed</button>
            <button onClick={() => setStatusFilter('all')}>All</button>
          </div>
          {loading ? (
            <p>Loading...</p>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Campaign Name</th>
                  <th>Type</th>
                  <th>Budget</th>
                  <th>Location</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredCampaigns(userCampaigns).map((campaign) => (
                  <tr key={campaign._id}>
                    <td>{campaign.campaign_title}</td>
                    <td>{campaign.campaign_type}</td>
                    <td>{campaign.budget || 'N/A'}</td>
                    <td>{campaign.campaign_address || 'N/A'}</td>
                    <td>
                      <button onClick={() => fetchDetails(campaign._id)}>View</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      )}
    </div>
  );
};

export default Campaigns;
