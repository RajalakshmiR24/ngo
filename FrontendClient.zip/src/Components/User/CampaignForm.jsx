import React, { useState } from 'react';

import axiosInstance from '../../Utils/axiosInstance';

const Campaign = () => {

    const [info, setInfo] = useState({});
    const [bannerImage, setBannerImage] = useState(null);


    const handleChange = (e) => {
        const { name, value } = e.target;
        setInfo((prevState) => ({
            ...prevState,
            [name]: value,
        }))

    }
    const handleFileChange = (e) => {
        setBannerImage(e.target.files[0]);
      };

    const handleSubmit = (e) => {
        e.preventDefault();

        const formData = new FormData();
        formData.append('campaignname', info.campaignname);
        formData.append('campaignobjective', info.campaignobjective);
        formData.append('budget', info.budget);
        formData.append('timeline', info.timeline);
        formData.append('location', info.location);
        formData.append('partnerships', info.partnerships);
        formData.append('bannerimage', bannerImage);

        axiosInstance.post(`/user/campaigndata`, formData)
        .then(() => {
          alert("Data successfully inserted");
        })
        .catch((error) => {
          console.error("There was an error inserting the data!", error);
        });



    }

    return (
        <div className="form-container">
            <form onSubmit={handleSubmit} className="login-form">
                <div className="form-group">
                    <label>Campaign Name</label>
                    <input type='text' name='campaignname' value={info?.campaignname || " "} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Campaign Objective</label>
                    <input type='text' name='campaignobjective' value={info?.campaignobjective || " "} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Banner Image</label>
                    <input type='file' name='bannerimage' onChange={handleFileChange} />
                </div>
                <div className="form-group" >
                    <label>Budget</label>
                    <input type='text' name='budget' value={info?.budget || " "} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Timeline</label>
                    <input type='text' name='timeline' value={info?.timeline || " "} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Location</label>
                    <input type='text' name='location' value={info?.location || " "} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Partnerships and Collaborations</label>
                    <input type='text' name='partnerships' value={info?.partnerships || " "} onChange={handleChange} />
                </div>
                <input type='submit' value="Submit" />

            </form>
        </div>
    )
}

export default Campaign
