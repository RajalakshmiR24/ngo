import React from 'react'

const GeneralUserList = () => {
  return (
    <div>
      GeneralUserList
      
    </div>
  )
}

export default GeneralUserList
