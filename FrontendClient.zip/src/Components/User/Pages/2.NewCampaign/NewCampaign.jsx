import React from 'react'
import CampaignManager from './CampaignManager'

const NewCampaign = () => {
  return (
    <div>
     
     <CampaignManager />
    </div>
  )
}

export default NewCampaign
