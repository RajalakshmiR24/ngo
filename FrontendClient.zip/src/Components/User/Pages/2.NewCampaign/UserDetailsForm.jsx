
import { useState } from 'react';
import axiosInstance from '../../../../Utils/axiosInstance';
const UserDetailsForm=()=>{
    const [details, setDetails] = useState({});
    const handleChange = (e) => {
        const { name, value } = e.target;
        setDetails((prevState) => ({
            ...prevState,
            [name]: value,
        }))

    }
    const handleSubmit = (e) => {
        e.preventDefault();

        const formUserData = new FormData();
        formUserData.append('campaignname', details.campaignname);
        formUserData.append('campaignobjective', details.campaignobjective);
        formUserData.append('campaigntype', details.campaigntype);
        formUserData.append('campaignbudget', details.campaignbudget);
        formUserData.append('starttime', details.starttime);
        formUserData.append('endtime', details.endtime);

        axiosInstance.post(`/user/register`, formUserData)
        .then(() => {
          alert("Data successfully inserted");
        })
        .catch((error) => {
          console.error("There was an error inserting the data!", error);
        });



    }

    return(
        <div className="form-container">
            <form onSubmit={handleSubmit} className="login-form">
                <div className="form-group">
                    <label>Campaign Name</label>
                    <input type='text' name='campaignname' value={details?.campaignname || " "} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Campaign Objective</label>
                    <input type='text' name='campaignobjective' value={details?.campaignobjective || " "} onChange={handleChange} />
                </div>
                <div className="form-group">
                    <label>Campaign Type </label>
                    <input type='text' name='campaigntype'value={details?.campaigntype || " "} onChange={handleChange} />
                </div>
                <div className="form-group" >
                    <label>Campaign Budget  </label>
                    <input type='text' name='campaignbudget' value={details?.campaignbudget || " "} onChange={handleChange} />
                </div>
                <div className="form-group" >
                    <label>Campaign Starting Time</label>
                    <input type='date' name='starttime' value={details?.starttime || " "} onChange={handleChange} />
                </div>
                <div className="form-group" >
                    <label>Campaign Ending Time</label>
                    <input type='date' name='endtime' value={details?.endtime || " "} onChange={handleChange} />
                </div>
                <input type='submit' value="Submit" />

            </form>
        </div>
    )
}
export default UserDetailsForm