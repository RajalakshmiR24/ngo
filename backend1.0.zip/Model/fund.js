const mongoose = require("mongoose");

const transactionSchema = new mongoose.Schema({
    campaignName: {
        type: String,
    },
    Description: {
        type: String
    },
    amount: {
        type: String,
    },
    emailHash: {
        type: String
    }

}, {
    timestamps: true
})



const fundRequestModel = mongoose.model("fund", transactionSchema);

module.exports = { fundRequestModel }