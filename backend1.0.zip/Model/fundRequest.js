const mongoose = require("mongoose");

const transactionSchema = new mongoose.Schema({
    campaignName: {
        type: String,
    },
    description: {
        type: String
    },
    amount: {
        type: String,
    },
    emailHash: {
        type: String,
    },   
}, {
    timestamps: true
})



const FundRequest = mongoose.model("fundRequest", transactionSchema);

module.exports = { FundRequest }