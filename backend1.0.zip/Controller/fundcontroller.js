const { fundRequestModel } = require("../Model/fund");

const fundRequest= async (req, res) => {
    console.log(req.body);
    try {
        const {campaignName, description, amount, emailHash} = req.body;
        if(!campaignName|| !description|| !amount|| !emailHash) {
            return res.status(200).json({msg:" Bad Request", code: 400});
        }
        const fundrequest = await fundRequestModel.create({
            campaignName: campaignName,
            Description: description,
            amount: amount,
            emailHash: emailHash
        })

        fundrequest.save();
        return res.status(200).json({msg: "Requsted Successfully", code: 200});
    } catch (error) {
        return res.status(200).json({msg: "Something went wrong", code: 500})
    }
}


module.exports = {fundRequest};

