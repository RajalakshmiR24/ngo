const { Campaign } = require("../Model/campaign");
const { User, ImageModel } = require("../Model/user");

const saveCampaignDetails = async (req, res) => {

    const { title, type, description, startdate, enddate, hash } = req.body;
    try {
        const campaign = await Campaign.create({ campaign_title: title, campaign_type: type, campaign_description: description, campaign_start_date: startdate, campaign_end_date: enddate, user_email_hash: hash })
        if (campaign) {
            return res.status(200).json({ code: 200, message: "Campaign data created successfully" })
        }
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }
}
const getAllCampaignDetails = async (req, res) => {
    try {
        const campaignDetails = await Campaign.find({});
        if (!campaignDetails) {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }
        return res.status(200).json({ code: 200, data: campaignDetails })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}

const getCampaignDetailsPerUserByEmailhash = async (req, res) => {
    const { hash } = req.body;
    try {
        const campaignData = await Campaign.find({ email_hash: hash });
        if (!campaignData) {
            return res.status(200).json({ code: 400, message: "No campaigns found" })

        }
        return res.status(200).json({ code: 200, data: campaignData })

    } catch (error) {

        return res.status(200).json({ code: 500, errorMessage: error.message })
    }

}

const getAllUpcomingCampaigns = async (req, res) => {
    try {
        const campaigns = await User.find(
            {
                "campaigndetails.status": "UPCOMING"
            },
            {
                campaigndetails: 1,
                _id: 0
            }
        )
        console.log(campaigns);


        // const images = await ImageModel.findOne({ campaign_id: campaigns.campaign_id })
        // const data = { campaigns, images }
        if (!campaigns) {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }
        return res.status(200).json({ code: 200, data: campaigns })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}

module.exports = { getCampaignDetailsPerUserByEmailhash, getAllUpcomingCampaigns, getAllCampaignDetails, saveCampaignDetails }
