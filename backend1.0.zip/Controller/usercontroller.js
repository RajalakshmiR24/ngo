const { Transaction } = require("../Model/transaction");
const { User } = require("../Model/user");
const jwt = require("jsonwebtoken")


const registerUser = async (req, res) => {

    // console.log("register", req.body);
    const { email, password, mobilenumber, address, fullname } = req.body;

    if (!email || !password) {
        return res.status(200).json({ code: 400, message: "Email and password required" })
    }

    try {
        const existedUserEmail = await User.findOne({ email: email });
        const existedMobileNumber = await User.findOne({ mobile_number: mobilenumber })

        if (existedUserEmail) {
            return res.status(200).json({ code: 400, message: "Email already registered" })
        }

        if (existedMobileNumber) {
            return res.status(200).json({ code: 400, message: "Mobilenumber exists" })
        }

        const user = await User.create({ fullname: fullname, email: email, password: password, current_address: address, mobile_number: mobilenumber });

        // console.log(user);
        const createdUser = await User.findById(user._id).select("-password -refreshToken -mobile_number");
        // console.log(createdUser);


        if (!createdUser) {
            return res.status(200).json({ code: 500, message: "Something went wrong" })
        }

        return res.status(200).json({ code: 200, message: "User created successfully" })

    } catch (error) {

        return res.status(200).json({ code: 500, message: error.message })

    }
}

const generateAccessAndRefreshTokens = async (hash, req, res) => {
    // console.log(hash);
    try {
        const user = await User.findOne({ email_hash: hash });
        const payload = {
            email_hash: user.email_hash,
            role: "user",
            date: user.createdAt
        }
        // console.log( );
        const accessToken = await jwt.sign(payload, process.env.ACCESS_TOKEN_SECRET_KEY, {
            expiresIn: process.env.ACCESS_TOKEN_EXPIRY,
        });
        // console.log(accessToken);

        const refreshToken = await jwt.sign(payload, process.env.REFRESH_TOKEN_SECRET_KEY, {
            expiresIn: process.env.REFRESH_TOKEN_EXPIRY,
        });

        user.refreshToken = refreshToken;

        // console.log(user);
        await user.save({ validateBeforeSave: false });
        // console.log(user);
        return { accessToken, refreshToken };


    } catch (error) {
        return res.status(200).json({ code: 500, ErrorMessage: error.message })

    }
}

const userLogin = async (req, res) => {
    const { email, password } = req.body;

    // console.log(userSchema);
    if (!email || !password) {
        return res.status(200).json({ code: 400, message: "Email and password required" })
    }

    try {
        const user = await User.findOne({ email: email, status: "ACTIVE" })

        // console.log(user.password);
        if (!user) {
            return res.status(200).json({ code: 400, message: "User not found" })
        }

        const isPasswordValid = await user.isPasswordCorrect(password);
        // console.log(isPasswordValid);


        if (!isPasswordValid) {
            return res.status(200).json({ code: 400, message: "Incorrect password" })
        }
        // console.log(user.email_hash);

        const { refreshToken, accessToken } = await generateAccessAndRefreshTokens(user.email_hash);
        // console.log(refreshToken);

        const loggedUser = await User.findOne({ email_hash: user.email_hash }, { email_hash: 1, _id: 0 });
        // console.log(loggedUser.email_hash, "loggg");

        const options = {
            httpOnly: true,
            secure: true,
        }

        return res.status(200).setHeader('Authorization', `Bearer ${accessToken}`).json({
            code: 200,
            data: loggedUser.email_hash,
            message: "Logged in successfully"
        })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}

const userRefreshToken = async (req, res) => {

    const incomingRefreshToken = req.cookies.refreshToken || req.body.refreshToken;

    if (!incomingRefreshToken) {
        return res.status(200).json({ code: 400, message: "Refresh token not found" })

    }

    // console.log(incomingRefreshToken);
    try {
        const decodedToken = jwt.verify(incomingRefreshToken, process.env.REFRESH_TOKEN_SECRET_KEY);

        // console.log(decodedToken);
        const user = await User.findById(decodedToken?.id);
        // console.log(user?.refreshToken, "user");

        if (!user) {
            return res.status(200).json({ code: 400, message: "user not found" })
        }

        if (!user?.refreshToken === incomingRefreshToken) {
            return res.status(200).json({ code: 400, message: "Refresh token is incorrect" })
        }

        const { accessToken, refreshToken } = await generateAccessAndRefreshTokens(user._id);

        return res.status(200).cookie("accessToken", accessToken).cookie("refreshToken", refreshToken)
            .json({ refreshToken, accessToken, message: "Access token refreshed" })
    } catch (error) {

        return res.status(200).json({ message: error.message })
    }
}

const userData = async (req, res) => {
    res.send("data");
}

const getUsersCount = async (req, res) => {

    const userCount = await User.countTotalUsers();
    if (userCount === 0) {
        return res.status(200).json({ code: 400, message: "No users" })
    }
    return res.status(200).json({ code: 200, data: userCount })

}

const userLogout = async (req, res) => {

    if (!req.cookies) {
        res.status(200).json({ code: 400, message: "User not logged in" })
    }
    // Clear the cookie
    res.clearCookie("accessToken");
    res.clearCookie("refreshToken");
    res.status(200).json({ code: 200, message: "User logged out successfully" })
}

// const insertCampaignDataByEmailHash = async (req, res) => {
//     // const { fullName, companyRole } = req.body;
//     console.log(req.body);
//     const bannerImage = req.file ? req.file.path : null;
//     // const user = new User();
//     // console.log(bannerImage);
//     // try {
//     //   await user.save();
//     //   res.send("Data successfully inserted");
//     // } catch (error) {
//     //   res.status(500).send("There was an error inserting the data");
//     // }
//     const { hash, info } = req.body;
//     if (!info) {

//         return res.status(200).json({ code: 400, message: "No data received" })
//     }
//     try {
//         const result = await User.updateOne({ email_hash: hash }, { $push: { campaigndetails: info } }, { new: true })
//         if (result.modifiedCount > 0) {
//             return res.status(200).json({ code: 200, message: "Object added into array successfully" })
//         }
//         else {
//             return res.status(200).json({ code: 400, message: "Unsuccessfull" })
//         }
//     } catch (error) {
//         return res.status(200).json({ code: 500, errorMessage: error.message })
//     }
// }

// const insertCampaignDataByEmailHash = async (req, res) => {
//     // console.log(req.body);
//     const { hash, info, base64Image } = req.body;

//     // Decode the Base64 image
//     // let image = null;
//     // if (base64Image) {
//     //     // const buffer = Buffer.from(base64Image, 'base64');
//     //     image = {
//     //         data: base64Image,
//     //         contentType: 'image/jpeg',
//     //     };
//     // }

//     if (!info) {
//         return res.status(200).json({ code: 400, message: "No data received" });
//     }

//     try {
//         const result = await User.updateOne({ email_hash: hash }, { $push: { campaigndetails: info } }, { new: true })
//         const camp = await User.findOn({ email_hash: hash, campaigndetails: 1, _id: 0 })
//         console.log(camp);
//         // const img = await User.updateOne({email_hash:hash},{campaigndetails[]:})



//         if (result.modifiedCount > 0) {
//             return res.status(200).json({ code: 200, message: "Object added into array successfully" });
//         } else {
//             return res.status(200).json({ code: 400, message: "Unsuccessful" });
//         }
//     } catch (error) {
//         return res.status(200).json({ code: 500, errorMessage: error.message });
//     }
// }

const insertCampaignDataByEmailHash = async (req, res) => {
    const { hash, info, base64Image } = req.body;

    if (!info) {
        return res.status(200).json({ code: 400, message: "No data received" });
    }

    try {
        // Step 1: Push the new campaign details
        const result = await User.updateOne(
            { email_hash: hash },
            { $push: { campaigndetails: info } },
            { new: true }
        );

        // Check if the update was successful
        if (result.modifiedCount > 0) {
            // Step 2: Find the user to get the latest campaigndetails
            const user = await User.findOne({ email_hash: hash }, { campaigndetails: 1 }).sort({ 'campaigndetails.createdAt': -1 }); // Sort to get the last entry

            if (user && user.campaigndetails.length > 0) {
                // Step 3: Update the last campaign detail with the image
                const lastCampaignId = user.campaigndetails[user.campaigndetails.length - 1]._id; // Get the ID of the last campaign

                // Prepare the image object
                const image = {
                    data: Buffer.from(base64Image, 'base64'), // Use the base64Image received
                    contentType: 'image/jpeg', // Set the content type accordingly
                };

                // Update the last campaign detail with the image
                await User.updateOne(
                    { email_hash: hash, 'campaigndetails._id': lastCampaignId },
                    { $set: { 'campaigndetails.$.image': image } } // Update the image field
                );

                return res.status(200).json({ code: 200, message: "Campaign details added successfully with image" });
            }
        }

        return res.status(200).json({ code: 400, message: "Unsuccessful" });
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message });
    }
}

const getAllCampaignDetails = async (req, res) => {
    try {
        const campaignDetails = await User.getAllCampaignDetails();
        if (campaignDetails.length === 0) {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }
        return res.status(200).json({ code: 200, data: campaignDetails })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }

}

// const totalCampaignCount = async (req, res) => {
//     try {
//         const count = await User.getTotalCampaignCount();
//         if (count === 0) {
//             return res.status(200).json({ code: 400, message: "No campaign found" })
//         }
//         return res.status(200).json({ code: 200, data: count })

//     } catch (error) {
//         return res.status(200).json({ code: 500, errorMessage: error.message })
//     }

// }

const campaignCountPerUserByEmailHash = async (req, res) => {
    const { hash } = req.body;
    try {
        const user = await User.findOne({ email_hash: hash });
        const campaignCountPerUser = await user.getUserCampaignCount();
        if (campaignCountPerUser === 0) {
            return res.status(200).json({ code: 200, data: "NA" })
        }
        return res.status(200).json({ code: 200, data: campaignCountPerUser })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }


}

// const getCampaignCountByMonth = async (req, res) => {
//     try {
//         const startOfMonth = new Date();
//         startOfMonth.setDate(1);
//         startOfMonth.setHours(0, 0, 0, 0);

//         const endOfMonth = new Date();
//         endOfMonth.setMonth(endOfMonth.getMonth() + 1);
//         endOfMonth.setDate(0);
//         endOfMonth.setHours(23, 59, 59, 999);

//         const campaignCount = await User.getTotalCampaignCount({
//             createdAt: {
//                 $gte: startOfMonth,
//                 $lte: endOfMonth
//             }
//         });

//         return res.status(200).json({ code: 200, data: { campaignCount } });

//     } catch (error) {
//         return res.status(500).json({ code: 500, errorMessage: error.message });
//     }

// };

const getCampaignCountByYear = async (req, res) => {
    try {
        const startOfYear = new Date();
        startOfYear.setMonth(0);
        startOfYear.setDate(1);
        startOfYear.setHours(0, 0, 0, 0);

        const endOfYear = new Date();
        endOfYear.setMonth(11);
        endOfYear.setDate(31);
        endOfYear.setHours(23, 59, 59, 999);

        const campaignCount = await User.getTotalCampaignCount({
            createdAt: {
                $gte: startOfYear,
                $lte: endOfYear
            }
        });
        return res.status(200).json({ code: 200, data: { campaignCount } });

    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }
}
// const getLiveCampaings = async (req, res) => {
//     try {
//         const currentDate = new Date();
//         const updatedCampaigns = await User.updateMany(
//             {
//                 "campaigndetails.start_date": { $lte: currentDate },
//                 "campaigndetails.end_date": { $gte: currentDate },
//                 // "campaigndetails.status": { $ne: "LIVE" }
//             },
//             {
//                 $set: {
//                     "campaigndetails.$[].status": "LIVE"
//                 }
//             }, {
//             new: true
//         }
//         );

//         if (updatedCampaigns.modifiedCount > 0) {
//             return res.status(200).json({ code: 200, message: "Updated" });
//         } else {
//             return res.status(200).json({ code: 400, message: "No campaigns found" })
//         }
//     } catch (error) {
//         return res.status(500).json({ code: 500, errorMessage: error.message });
//     }
// }
// const getCancelledCampaings = async (req, res) => {
//     try {
//         const cancel = await User.aggregate([
//             {
//                 $unwind: "$campaigndetails"
//             },

//             {
//                 $match: {
//                     "campaigndetails.status": "CANCELLED"
//                 },

//             },
//             {
//                 $project: {
//                     _id: 0,
//                     "campaign_title": "$campaigndetails.campaign_title",
//                     "campaigndetails": "$campaigndetails.campaigndetails    ",
//                     "campaign_description": "$campaigndetails.campaign_description",
//                     "start_date": "$campaigndetails.start_date",
//                     "end_date": "$campaigndetails.end_date",
//                     "campaign_address": "$campaigndetails.campaign_address",
//                     "budget": "$campaigndetails.budget",
//                     "status": "$campaigndetails.status",
//                     "reason_for_cancellation": "$campaigndetails.reason_for_cancellation"
//                 }
//             }


//         ]);

//         if (cancel.length > 0) {
//             return res.status(200).json({ code: 200, data: cancel })
//         } else {
//             return res.status(200).json({ code: 400, message: "No campaigns found" })
//         }

//     } catch (error) {
//         console.log(error.message);
//         return res.status(200).json({ code: 500, errorMessage: error.message });

//     }
// }

// const getUpcomingCampaings = async (req, res) => {
//     try {
//         const currentDate = new Date();

//         await User.updateMany(
//             {
//                 "campaigndetails.start_date": { $gte: currentDate }
//             },
//             {
//                 $set: {
//                     "campaigndetails.$[].status": "UPCOMING"
//                 }
//             }
//         );
//         const upcoming = await User.aggregate([
//             {
//                 $unwind: "$campaigndetails"
//             },
//             {
//                 $match: {
//                     "campaigndetails.start_date": { $gte: currentDate },
//                     "campaigndetails.status": "UPCOMING"
//                 }
//             },
//             {
//                 $project: {
//                     _id: 0,
//                     campaign_title: "$campaigndetails.campaign_title",
//                     campaign_description: "$campaigndetails.campaign_description",
//                     start_date: "$campaigndetails.start_date",
//                     end_date: "$campaigndetails.end_date",
//                     campaign_address: "$campaigndetails.campaign_address",
//                     budget: "$campaigndetails.budget",
//                     status: "$campaigndetails.status",
//                     reason_for_cancellation: "$campaigndetails.reason_for_cancellation"
//                 }
//             }
//         ]);

//         if (upcoming.length > 0) {
//             return res.status(200).json({ code: 200, data: upcoming });
//         } else {
//             return res.status(200).json({ code: 400, message: "No campaigns found" });
//         }

//     } catch (error) {
//         console.error(error.message);
//         return res.status(500).json({ code: 500, errorMessage: error.message });
//     }

// }
const getApprovedCampaings = async (req, res) => {
    try {
        const approved = await User.aggregate([
            {
                $unwind: "$campaigndetails"
            },

            {
                $match: {
                    "campaigndetails.status": "APPROVED"
                },

            },
            {
                $project: {
                    _id: 0,
                    "campaign_title": "$campaigndetails.campaign_title",
                    "campaigndetails": "$campaigndetails.campaigndetails    ",
                    "campaign_description": "$campaigndetails.campaign_description",
                    "start_date": "$campaigndetails.start_date",
                    "end_date": "$campaigndetails.end_date",
                    "campaign_address": "$campaigndetails.campaign_address",
                    "budget": "$campaigndetails.budget",
                    "status": "$campaigndetails.status",
                    "reason_for_cancellation": "$campaigndetails.reason_for_cancellation"
                }
            }


        ]);

        if (approved.length > 0) {
            return res.status(200).json({ code: 200, data: approved })
        } else {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }



    } catch (error) {
        console.log(error.message);
        return res.status(200).json({ code: 500, errorMessage: error.message });

    }
}
const getNotApprovedCampaings = async (req, res) => {

    try {
        const notApproved = await User.aggregate([
            {
                $unwind: "$campaigndetails"
            },

            {
                $match: {
                    "campaigndetails.status": "NOT_APPROVED"
                },

            },
            {
                $project: {
                    _id: 0,
                    "campaign_title": "$campaigndetails.campaign_title",
                    "campaigndetails": "$campaigndetails.campaigndetails    ",
                    "campaign_description": "$campaigndetails.campaign_description",
                    "start_date": "$campaigndetails.start_date",
                    "end_date": "$campaigndetails.end_date",
                    "campaign_address": "$campaigndetails.campaign_address",
                    "budget": "$campaigndetails.budget",
                    "status": "$campaigndetails.status",
                    "reason_for_cancellation": "$campaigndetails.reason_for_cancellation"
                }
            }


        ]);

        if (notApproved.length > 0) {
            return res.status(200).json({ code: 200, data: notApproved })
        } else {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }



    } catch (error) {
        console.log(error.message);
        return res.status(200).json({ code: 500, errorMessage: error.message });

    }
}
const getLiveCampaignWithDetails = async (req, res) => {
    try {
        const currentDate = new Date();
        const updatedCampaigns = await User.updateMany(
            {
                "campaigndetails.start_date": { $lte: currentDate },
                "campaigndetails.end_date": { $gte: currentDate },
            },
            {
                $set: {
                    "campaigndetails.$[].status": "LIVE"
                }
            }
        );

        if (updatedCampaigns.modifiedCount > 0) {
            const liveCampaigns = await User.aggregate([
                {
                    $unwind: "$campaigndetails"
                },
                {
                    $match: {
                        "campaigndetails.status": "LIVE",
                        "campaigndetails.start_date": { $lte: currentDate },
                        "campaigndetails.end_date": { $gte: currentDate }
                    }
                },
                {
                    $project: {
                        _id: 0,
                        campaign_title: "$campaigndetails.campaign_title",
                        campaign_description: "$campaigndetails.campaign_description",
                        start_date: "$campaigndetails.start_date",
                        end_date: "$campaigndetails.end_date",
                        campaign_address: "$campaigndetails.campaign_address",
                        budget: "$campaigndetails.budget",
                        status: "$campaigndetails.status",
                        reason_for_cancellation: "$campaigndetails.reason_for_cancellation"
                    }
                }
            ]);

            if (liveCampaigns.length > 0) {
                return res.status(200).json({ code: 200, data: liveCampaigns });
            } else {
                return res.status(200).json({ code: 400, message: "No live campaigns found" });
            }
        } else {
            return res.status(200).json({ code: 400, message: "No campaigns found" });
        }
    } catch (error) {
        console.error(error.message);
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }

}
const getCompleteCampaignWithDetails = async (req, res) => {
    try {
        const currentDate = new Date();

        const updatedCampaigns = await User.updateMany(
            {
                "campaigndetails.end_date": { $lt: currentDate },
                "campaigndetails.status": { $ne: "COMPLETED" }
            },
            {
                $set: {
                    "campaigndetails.$[].status": "COMPLETED"
                }
            }
        );

        if (updatedCampaigns.modifiedCount > 0) {
            const completedCampaigns = await User.aggregate([
                {
                    $unwind: "$campaigndetails"
                },
                {
                    $match: {
                        "campaigndetails.status": "COMPLETED",
                        "campaigndetails.end_date": { $lt: currentDate }
                    }
                },
                {
                    $project: {
                        _id: 0,
                        campaign_title: "$campaigndetails.campaign_title",
                        campaign_description: "$campaigndetails.campaign_description",
                        start_date: "$campaigndetails.start_date",
                        end_date: "$campaigndetails.end_date",
                        campaign_address: "$campaigndetails.campaign_address",
                        budget: "$campaigndetails.budget",
                        status: "$campaigndetails.status",
                        reason_for_cancellation: "$campaigndetails.reason_for_cancellation"
                    }
                }
            ]);

            if (completedCampaigns.length > 0) {
                return res.status(200).json({ code: 200, data: completedCampaigns });
            } else {
                return res.status(200).json({ code: 400, message: "No completed campaigns found" });
            }
        } else {
            return res.status(200).json({ code: 400, message: "No campaigns found" });
        }
    } catch (error) {
        console.error(error.message);
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }


}
const getBudgetPerUserForCampaignByEmailHash = async (req, res) => {

    const { hash } = req.body;
    try {
        const user = await User.findOne({ email_hash: hash });
        const result = user.map((item, index) => {

        })


        return res.status(200).json({ code: 200, data: user });

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }

}///// not completed

const expensesPerCampaign = async (req, res) => {

}
async function findAllUsers(req, res) {
    try {
        const users = await User.find({}).select("-refreshToken -password -_id -email_hash");
        // console.log(users);
        return res.status(200).json({ code: 200, data: users })
    } catch (error) {
        // console.error("Error finding users:", error);
        return res.status(200).json({ code: 400, message: "No users found" })
    }
}

// const findUserByEmailHash = async (req, res) => {
//     const { hash } = req.body;
//     // const id = req.params.id;

//     try {
//         const user = await User.findOne({ email_hash: hash });
//         if (!user) {
//             return res.status(200).json({ code: 400, message: "No user found" });
//         }
//         return res.status(200).json({ code: 200, data: user });

//     } catch (error) {
//         return res.status(200).json({ code: 500, errorMessage: error.message })
//     }
// }
const getCampaignDetailsPerUserByEmailHash = async (req, res) => {
    const { hash } = req.body;

    try {
        const users = await User.find(
            { email_hash: hash },
            { campaigndetails: 1, _id: 0, email_hash: 1 }
        ).lean();

        if (!users.length) {
            return res.status(200).json({ code: 400, message: "No campaigns found" });
        }

        const filteredCampaigns = users.flatMap(user =>
            user.campaigndetails
                .filter(campaign => ["APPROVED", "UPCOMING", "LIVE", "COMPLETED", "CANCELLED"].includes(campaign.status))
                .map(campaign => ({
                    campaign_id: campaign.campaign_id,
                    email_hash: user.email_hash,
                    campaign_title: campaign.campaign_title,
                    campaign_type: campaign.campaign_type,
                    campaign_description: campaign.campaign_description,
                    campaign_address: campaign.campaign_address,
                    budget: campaign.budget,
                    start_date: campaign.start_date,
                    end_date: campaign.end_date,
                    status: campaign.status
                }))
        );

        if (!filteredCampaigns.length) {
            return res.status(200).json({ code: 400, message: "No valid campaigns found" });
        }

        return res.status(200).json({ code: 200, data: filteredCampaigns });
    } catch (error) {
        console.error("Error fetching campaign details:", error);
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }
};

const getTotalRegisteredUsers = async (req, res) => {
    try {
        const count = await User.countDocuments();
        if (count === 0) {
            return res.status(200).json({ code: 400, message: "No users found" })
        }
        return res.status(200).json({ code: 200, data: count });
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }

}

const getAllTransactions = async (req, res) => {

    try {
        const result = await Transaction.find({}).select("-_id")
        return res.status(200).json({ code: 200, data: result });

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })


    }

}

const getTransactionDetailsPerCampaignType = async (req, res) => {
    const { campaigntype } = req.body;
    try {
        const transaction = await Transaction.aggregate([
            {
                $match: {
                    campaigndetails: {
                        $elemMatch: { "campaign_type": campaigntype } // Match documents with an address in the specified city
                    }
                }
            }
        ]);
        if (transaction.length > 0) {
            return res.status(200).json({ code: 200, data: transaction })
        }
        return res.status(200).json({ code: 400, message: "no transactions found" })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }

}

const getTransactionDetailsPerDay = async (req, res) => {
    try {
        const startOfDay = new Date();
        startOfDay.setHours(0, 0, 0, 0);

        const endOfDay = new Date();
        endOfDay.setHours(23, 59, 59, 999);

        const transactions = await Transaction.find({
            createdAt: {
                $gte: startOfDay,
                $lte: endOfDay
            }
        }).sort({ createdAt: -1 });

        if (transactions.length > 0) {
            return res.status(200).json({ code: 200, data: transactions });
        }

        return res.status(200).json({ code: 400, message: "No transactions found for today" });

    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }
}

const getTransactionDetailsPerMonth = async (req, res) => {
    try {
        const startOfMonth = new Date();
        startOfMonth.setDate(1);
        startOfMonth.setHours(0, 0, 0, 0);

        const endOfMonth = new Date();
        endOfMonth.setMonth(endOfMonth.getMonth() + 1);
        endOfMonth.setDate(0);
        endOfMonth.setHours(23, 59, 59, 999);

        const transactions = await Transaction.find({
            createdAt: {
                $gte: startOfMonth,
                $lte: endOfMonth
            }
        }).sort({ createdAt: -1 });

        if (transactions.length > 0) {
            return res.status(200).json({ code: 200, data: transactions });
        }

        return res.status(200).json({ code: 400, message: "No transactions found for this month" });

    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }

}
const getTransactionDetailsPerYear = async (req, res) => {
    try {
        const startOfYear = new Date();
        startOfYear.setMonth(0);
        startOfYear.setDate(1);
        startOfYear.setHours(0, 0, 0, 0);

        const endOfYear = new Date();
        endOfYear.setMonth(11);
        endOfYear.setDate(31);
        endOfYear.setHours(23, 59, 59, 999);

        const transactions = await Transaction.find({
            createdAt: {
                $gte: startOfYear,
                $lte: endOfYear
            }
        }).sort({ createdAt: -1 });

        if (transactions.length > 0) {
            return res.status(200).json({ code: 200, data: transactions });
        }

        return res.status(200).json({ code: 400, message: "No transactions found for this year" });

    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }

}


const getRegisteredUserClaimingAmount = async (req, res) => {

}
const getRegisteredUserClaimAmountBillDetails = async (req, res) => {

}
const approveRegisteredUserClaimingAmount = async (req, res) => {

}
const getRegisteredUserExpenseAmount = async (req, res) => {

}

const getCancelRequest = () => {

}

//general user management
const getTotalGeneralUsers = async (req, res) => {
    try {
        const total = await Transaction.countDocuments();
        return res.status(200).json({ code: 200, data: total })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }

}

const getTransactionDataPerCampaigns = async (req, res) => {


}

//request

// const getUserDetailsToVerify = async (req, res) => {

//     try {
//         const users = await User.find({ status: "NOT_ACTIVE" }, { _id: 0, email_hash: 0, refresh_token: 0, password: 0, campaigndetails: 0 });
//         if (!users) {
//             return res.status(200).json({ code: 400, message: "No users found" })

//         }
//         return res.status(200).json({ code: 200, data: users })

//     } catch (error) {
//         return res.status(200).json({ code: 500, errorMessage: error.message })
//     }


// }

const rejectUserRegistration = async (req, res) => {

    const { hash } = req.body;
    try {
        const user = await User.findOne({ email_hash: hash })
        if (!user) {
            return res.status(200).json({ code: 400, message: "No user to reject" })
        }
        user.status = "REJECTED";
        return res.status(200).json({ code: 200, message: "User registration rejected" })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }


}

// const getCampaignDetailRequestToVerify = async (req, res) => {

//     //update array in user db
//     const { hash } = req.body;
//     try {
//         const user = await User.find({ email_hash: hash }, { campaigndetails: 1, _id: 0 });
//         return res.status(200).json({ code: 200, data: user })

//     } catch (error) {
//         return res.status(200).json({ code: 500, errorMessage: error.message });

//     }

// }

const rejectCampaignRequest = async (req, res) => {
    const { hash } = req.body;
    try {

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message });

    }

}

// const saveVerifiedCampaignDetails = async (req, res) => {

//     //update array in user db
// }

const getCampaignRequestedRegisteredUserDetails = async (req, res) => {

}

// const getRegisteredBillsToVerify = async (req, res) => {
//     const { hash } = req.body;

//     try {
//         const user = await User.find({ email_hash: hash });
//         const bills = user.campaigndetails




//     } catch (error) {

//     }
// }

// const rejectBills = () => {

// }



//Queries

const getAllQueries = async (req, res) => {

}



//RegisteredUser Queries


// const getAllRegisteredUserQueries = async (req, res) => {

// }
// const getRegisteredUserQueriesByEmailHash = async (req, res) => {

// }
// const getRegisteredUserQueriesByCampaign = async (req, res) => {

// }
// const getRegisteredUserQueriesByCampaignType = async (req, res) => {

// }
// const getRegisteredUserQueriesByLocation = async (req, res) => {

// }



//GeneralUser Queries



// const getAllGeneralUserQueries = async (req, res) => {

// }
// const getGeneralUserQueriesByCampaign = async (req, res) => {

// }
// const getGeneralUserQueriesByCampaignType = async (req, res) => {

// }
// const getGeneralUserQueriesByLocation = async (req, res) => {

// }
const uploadImage = async (req, res) => {
    const { base64Image, campId, email_hash } = req.body;
    // console.log(req.body);
    const buffer = Buffer.from(base64Image, 'base64');
    const image = await ImageModel.create({
        data: buffer,
        email_hash: email_hash,
        campaign_id: campId,
        contentType: 'image/png'
    });
    await User.findByIdAndUpdate({ email_hash: email_hash }, { campaigndetails: { $push: { images: image._id } } });

    await image.save();
    res.send('Image uploaded successfully');
};

const fetchImage = async (req, res) => {
    const { campId, email_hash } = req.body;
    // console.log(req.body);
    try {
        const images = await ImageModel.find({ campaign_id: campId, email_hash: email_hash });
        if (!images || images.length === 0) {
            return res.status(404).json({ code: 400, message: "Images not found" });
        }

        const imageData = images.map(image => ({
            id: image._id,
            contentType: image.contentType,
            data: image.data.toString('base64')
        }));

        return res.status(200).json({ code: 200, data: imageData });
    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }
};


const getUserCampaignImages = async (userId) => {
    const user = await User.findById(userId)
        .populate({ path: 'campaigndetails.images', model: 'Image' }) // Populate images in campaigns
        .exec();

    return res.status(200).json({ code: 200, data: user })
};

const getTotalTransactionAmount = async (req, res) => {
    try {
        const result = await Transaction.aggregate([
            {
                $group: {
                    _id: null,
                    totalAmount: {
                        $sum: { $toDouble: "$amount" }
                    }
                }
            }
        ]);

        const totalAmount = result.length > 0 ? result[0].totalAmount : 0;
        return res.status(200).json({ code: 200, totalAmount });

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message });
    }
}

const getTotalExpense = async (req, res) => {
    try {
        const result = await User.aggregate([
            {
                $unwind: "$campaigndetails"
            },
            {
                $unwind: {
                    path: "$campaigndetails.bills",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $group: {
                    _id: null,
                    totalExpense: {
                        $sum: { $toDouble: "$campaigndetails.bills.expense" }
                    }
                }
            }
        ]);

        const totalExpense = result.length > 0 ? result[0].totalExpense : 0;
        return res.status(200).json({ code: 200, totalExpense });

    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }
};

const totalCampaignCount = async (req, res) => {
    try {
        const countResult = await User.aggregate([
            {
                $count: "totalCampaigns"
            }
        ]);

        const count = countResult.length > 0 ? countResult[0].totalCampaigns : 0;

        if (count === 0) {
            return res.status(200).json({ code: 400, message: "No campaign found" });
        }

        return res.status(200).json({ code: 200, data: count });

    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }


}

const getCampaignCountByMonth = async (req, res) => {
    try {
        const startOfMonth = new Date();
        startOfMonth.setDate(1);
        startOfMonth.setHours(0, 0, 0, 0);

        const endOfMonth = new Date();
        endOfMonth.setMonth(endOfMonth.getMonth() + 1);
        endOfMonth.setDate(0);
        endOfMonth.setHours(23, 59, 59, 999);

        const campaignCount = await User.aggregate([
            {
                $match: {
                    createdAt: {
                        $gte: startOfMonth,
                        $lte: endOfMonth
                    }
                }
            },
            {
                $count: "totalCampaigns"
            }
        ]);

        return res.status(200).json({
            code: 200,
            data: {
                campaignCount: campaignCount.length > 0 ? campaignCount[0].totalCampaigns : 0
            }
        });

    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }


};

const getCampaignCountPerDay = async (req, res) => {
    try {
        const startOfDay = new Date();
        startOfDay.setHours(0, 0, 0, 0);

        const endOfDay = new Date();
        endOfDay.setHours(23, 59, 59, 999);

        const campaignCountday = await User.aggregate([
            {
                $match: {
                    createdAt: {
                        $gte: startOfDay,
                        $lte: endOfDay
                    }
                }
            },
            {
                $count: "totalCampaigns"
            }
        ]);

        return res.status(200).json({
            code: 200,
            data: {
                campaignCountday: campaignCountday.length > 0 ? campaignCountday[0].totalCampaigns : 0
            }
        });

    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }

}

const getCampaignCountByweek = async (req, res) => {
    try {
        const startOfWeek = new Date();
        startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay());
        startOfWeek.setHours(0, 0, 0, 0);

        const endOfWeek = new Date();
        endOfWeek.setDate(endOfWeek.getDate() + (6 - endOfWeek.getDay()));
        endOfWeek.setHours(23, 59, 59, 999);

        const campaignCountWeek = await User.aggregate([
            {
                $match: {
                    createdAt: {
                        $gte: startOfWeek,
                        $lte: endOfWeek
                    }
                }
            },
            {
                $count: "totalCampaigns"
            }
        ]);

        return res.status(200).json({
            code: 200,
            data: {
                campaignCountWeek: campaignCountWeek.length > 0 ? campaignCountWeek[0].totalCampaigns : 0
            }
        });

    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }


}

const getLiveCampaings = async (req, res) => {
    try {
        const currentDate = new Date();

        await User.updateMany(
            {
                "campaigndetails.start_date": { $lte: currentDate },
                "campaigndetails.end_date": { $gte: currentDate },
                "campaigndetails.status": "UPCOMING"
            },
            {
                $set: {
                    "campaigndetails.$[elem].status": "LIVE"
                }
            },
            {
                arrayFilters: [{ "elem.status": "LIVE" }]
            }
        );

        const liveCampaigns = await User.aggregate([
            {
                $unwind: "$campaigndetails"
            },
            {
                $match: {
                    "campaigndetails.start_date": { $lte: currentDate },
                    "campaigndetails.end_date": { $gte: currentDate },
                    "campaigndetails.status": "LIVE"
                }
            },
            {
                $project: {
                    _id: 0,
                    campaign_title: "$campaigndetails.campaign_title",
                    campaign_description: "$campaigndetails.campaign_description",
                    start_date: "$campaigndetails.start_date",
                    end_date: "$campaigndetails.end_date",
                    campaign_address: "$campaigndetails.campaign_address",
                    budget: "$campaigndetails.budget",
                    status: "$campaigndetails.status",
                    reason_for_cancellation: "$campaigndetails.reason_for_cancellation"
                }
            }
        ]);

        if (liveCampaigns.length > 0) {
            return res.status(200).json({ code: 200, data: liveCampaigns.length });
        } else {
            return res.status(200).json({ code: 404, message: "No live campaigns found" });
        }

    } catch (error) {
        console.error(error.message);
        return res.status(200).json({ code: 500, errorMessage: error.message });
    }

}

const getCancelledCampaings = async (req, res) => {
    try {
        const cancel = await User.aggregate([
            {
                $unwind: "$campaigndetails"
            },

            {
                $match: {
                    "campaigndetails.status": "CANCELLED"
                },

            },
            {
                $project: {
                    _id: 0,
                    "campaign_title": "$campaigndetails.campaign_title",
                    "campaigndetails": "$campaigndetails.campaigndetails    ",
                    "campaign_description": "$campaigndetails.campaign_description",
                    "start_date": "$campaigndetails.start_date",
                    "end_date": "$campaigndetails.end_date",
                    "campaign_address": "$campaigndetails.campaign_address",
                    "budget": "$campaigndetails.budget",
                    "status": "$campaigndetails.status",
                    "reason_for_cancellation": "$campaigndetails.reason_for_cancellation"
                }
            }


        ]);

        if (cancel.length > 0) {
            return res.status(200).json({ code: 200, data: cancel.length })
        } else {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }

    } catch (error) {
        console.log(error.message);
        return res.status(200).json({ code: 500, errorMessage: error.message });

    }
}

const getCompletedCampaings = async (req, res) => {
    try {
        const currentDate = new Date();

        await User.updateMany(
            {
                "campaigndetails.end_date": { $lte: currentDate },
                "campaigndetails.status": "APPROVED"
            },
            {
                $set: {
                    "campaigndetails.$[elem].status": "COMPLETED"
                }
            },
            {
                arrayFilters: [{ "elem.status": "APPROVED" }]
            }
        );

        const completedCampaigns = await User.aggregate([
            {
                $unwind: "$campaigndetails"
            },
            {
                $match: {
                    "campaigndetails.start_date": { $lte: currentDate },
                    "campaigndetails.status": "COMPLETED"
                }
            },
            {
                $project: {
                    _id: 0,
                    campaign_title: "$campaigndetails.campaign_title",
                    campaign_description: "$campaigndetails.campaign_description",
                    start_date: "$campaigndetails.start_date",
                    end_date: "$campaigndetails.end_date",
                    campaign_address: "$campaigndetails.campaign_address",
                    budget: "$campaigndetails.budget",
                    status: "$campaigndetails.status",
                    reason_for_cancellation: "$campaigndetails.reason_for_cancellation"
                }
            }
        ]);

        if (completedCampaigns.length > 0) {
            return res.status(200).json({ code: 200, data: completedCampaigns.length });
        } else {
            return res.status(200).json({ code: 404, message: "No campaigns found" });
        }

    } catch (error) {
        console.error("Error processing campaigns:", error.message);
        return res.status(200).json({ code: 500, message: "Internal Server Error" });
    }


}

const getUpcomingCampaings = async (req, res) => {
    try {
        const currentDate = new Date();

        await User.updateMany(
            {
                "campaigndetails.start_date": { $gte: currentDate },
                "campaigndetails.status": "APPROVED"
            },
            {
                $set: {
                    "campaigndetails.$[elem].status": "UPCOMING"
                }
            },
            {
                arrayFilters: [{ "elem.status": "APPROVED" }]
            }
        );

        const upcoming = await User.aggregate([
            {
                $unwind: "$campaigndetails"
            },
            {
                $match: {
                    "campaigndetails.start_date": { $gte: currentDate },
                    "campaigndetails.status": "UPCOMING"
                }
            },
            {
                $project: {
                    _id: 0,
                    campaign_title: "$campaigndetails.campaign_title",
                    campaign_description: "$campaigndetails.campaign_description",
                    start_date: "$campaigndetails.start_date",
                    end_date: "$campaigndetails.end_date",
                    campaign_address: "$campaigndetails.campaign_address",
                    budget: "$campaigndetails.budget",
                    status: "$campaigndetails.status",
                    reason_for_cancellation: "$campaigndetails.reason_for_cancellation"
                }
            }
        ]);

        if (upcoming.length > 0) {
            return res.status(200).json({ code: 200, data: upcoming.length });
        } else {
            return res.status(200).json({ code: 404, message: "No campaigns found" }); // Changed to 404
        }

    } catch (error) {
        console.error(error.message);
        return res.status(200).json({ code: 500, errorMessage: error.message });
    }

}




module.exports = { registerUser, getTotalTransactionAmount, getCompletedCampaings, getTotalExpense, getCampaignCountByweek, getCampaignCountPerDay, getUserCampaignImages, fetchImage, uploadImage, userLogout, getAllCampaignDetails, getCampaignDetailsPerUserByEmailHash, generateAccessAndRefreshTokens, userLogin, userData, userRefreshToken, insertCampaignDataByEmailHash, getUsersCount, getTransactionDetailsPerDay, getAllTransactions, getTransactionDetailsPerMonth, getTransactionDetailsPerYear, totalCampaignCount, getCampaignCountByMonth, getCampaignCountByYear, getLiveCampaings, getCancelledCampaings, getUpcomingCampaings, getApprovedCampaings, getNotApprovedCampaings, getLiveCampaignWithDetails, getCompleteCampaignWithDetails }