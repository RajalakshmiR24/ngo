const express = require("express");
const { saveQueries } = require("../Controller/querycontroller");
const { uploadImage, fetchImage } = require("../Controller/admincontroller");
const { getTransactionResponse } = require("../Controller/transactioncontroller");
const { getAllUpcomingCampaigns } = require("../Controller/campaigncontroller");

const router = express.Router();


router.post("/savequeries", saveQueries);


router.post("/bannerimage", uploadImage);
router.post("/fetchbannerimage", fetchImage);

router.post("/tran", getTransactionResponse)
router.get("/getallca", getAllUpcomingCampaigns)


module.exports = { router };
