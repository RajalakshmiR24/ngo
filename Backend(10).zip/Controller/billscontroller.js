const { BillModel } = require("../Model/bills.js");
const { Campaign } = require("../Model/campaign.js");
const { User } = require("../Model/user.js");

const saveUserCampaignBills = async (req, res) => {
    const { bills, amount, campId, email } = req.body;
    if (!bills || !amount || !campId || !email) {
        return res.status(400).json({ code: 400, message: "All fields are required." });
    }
    try {
        const bill = await BillModel.create({ bills, claiming_amount: amount, campaign_id: campId, email_hash: email });

        if (!bill) {
            return res.status(200).json({ code: 400, message: "Bills not uploaded" })
        }

        const campaign = await Campaign.findOne({ user_email: email });

        if (!campaign) {
            return res.status(200).json({ code: 400, message: "cannot push campaign id" })
        }

        campaign.bills.push(bill._id);
        campaign.save();

        const user = await User.findOne({ email_hash: email });

        if (!user) {
            return res.status(200).json({ code: 400, message: "cannot push user id" })
        }

        bill.campaign.push(campaign._id);
        bill.user.push(user._id);
        bill.save();
        return res.status(200).json({ code: 200, message: "Bills uploaded successfully" })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }

}

const saveAdminCampaignBills = async (req, res) => {
    const { bills, amount, campId, email } = req.body;
    if (!bills || !amount || !campId || !email) {
        return res.status(400).json({ code: 400, message: "All fields are required." });
    }
    try {
        const bill = await BillModel.create({ bills, claiming_amount: amount, campaign_id: campId, admin_email: email_hash });
        if (!bill) {
            return res.status(200).json({ code: 400, message: "Bills not uploaded" })
        }
        const campaign = await Campaign.findOne({ admin_email: email });
        campaign.bills.push(bill._id);
        await campaign.save();
        bill.status = "APPROVED";
        await bill.save();
        return res.status(200).json({ code: 200, message: "Bills uploaded successfully" })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }

}

const findBillsByID = async(req,res)=>{
    try {
        const {id} = req.body;
        const bills = await BillModel.findById(id).select("-_id");
        if(!bills){
            return res.status(200).json({code:400,message:"No bills found"})
        }
        return res.status(200).json({code:200,data:bills})
    } catch (error) {
        return res.status(200).json({code:500,errorMessage:error.message})
    }
}

const getRegisteredUsersBillsToVerify = async (req, res) => {
    // const { campId } = req.body;

    try {
        const bills = await BillModel.find({ status: "PENDING" }, { _id: 0 })
            .populate({
                path: 'user',
                select: '-_id fullname email mobile_number'
            })
            .populate({
                path: 'campaign',
                select: '-_id -bills -status -reason_for_cancellation -user_email'
            })
            .exec();


        if (bills) {
            return res.status(200).json({ code: 200, count: bills.length, data: bills })
        } else {
            return res.status(200).json({ code: 400, message: "No bills found for this campaign" })
        }

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message });

    }
}

const rejectOrVerifyBillsByCampaignId = async (req, res) => {

    const { campaign_id, status, reason } = req.body;
    if (!campaign_id) {
        return res.status(200).json({ code: 400, message: "Campaign ID is missing" })
    }
    if (!reason || !status === "APPROVED" || !status === "REJECTED") {
        return res.status(200).json({ code: 400, message: "Reason and status is missing" })
    }
    try {
        const billToReject = await BillModel.findOne({ campaign_id });
        if (!billToReject) {
            return res.status(200).json({ code: 400, message: "Bill not found" })
        }
        if (billToReject && status === "APPROVED") {
            billToReject.status = status;
            billToReject.save();
            return res.status(200).json({ code: 200, message: "Approved successfully" })
        }
        if (billToReject && status === "REJECTED") {
            billToReject.status = status
            billToReject.reason_for_cancellation = reason;
            billToReject.save();
            return res.status(200).json({ code: 200, message: "Rejected successfully" })
        }

        return res.status(200).json({ code: 400, message: "status update Unsuccessfull" })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })


    }

}

const getTotalExpense = async (req, res) => {
    try {
        const expense = await BillModel.find({ status: "APPROVED" }).populate({
            path: 'campaign',
            select: '-_id campaign_title campaign_description'
        })
        if (!expense) {
            return res.status(200).json({ code: 400, message: "No bills found" })
        }
        let totalExpense = 0;
        let totalApprovedBills = 0;
        expense.forEach((item) => {
            totalExpense += Number(item.claiming_amount);
            // console.log(item.claiming_amount);
            totalApprovedBills++
        }
        );
        return res.status(200).json({ code: 200, data:expense , expense: totalExpense, count: totalApprovedBills })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}

module.exports = {
    saveAdminCampaignBills,
    saveUserCampaignBills,
    getRegisteredUsersBillsToVerify,
    rejectOrVerifyBillsByCampaignId,
    getTotalExpense,
    findBillsByID
}