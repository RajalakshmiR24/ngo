const { Campaign } = require("../../Model/campaign");
const { User } = require("../../Model/user");

//user
const saveUserCampaignDetails = async (req, res) => {
    try {
        const { title, type, description, start_date, end_date, banner, user_email, address, budget } = req.body;
        if (!title || !type || !description || !start_date || !end_date || !banner || !user_email || !address || !budget) {
            return res.status(200).json({ code: 400, message: "Bad request" })
        }
        const campaign = await Campaign.create({
            campaign_title: title,
            campaign_address: address,
            estimated_budget: budget,
            banner: banner,
            campaign_type: type,
            campaign_description: description,
            campaign_start_date: start_date,
            campaign_end_date: end_date,
            user_email: user_email,
        });

        // Find the user
        const user = await User.findOne({ email_hash: user_email });
        if (!user) {
            return res.status(404).json({ code: 404, message: "User not found" });
        }
        if (!campaign) {
            return res.status(200).json({ code: 400, message: "Campaign not saved" })
        }
        user.campaigns.push(campaign._id);
        await user.save();

        campaign.user.push(user._id);
        campaign.save();

        return res.status(200).json({ code: 200, message: "Campaign data created successfully" });

    } catch (error) {
        return res.status(500).json({ code: 500, errorMessage: error.message });
    }
};


const findUsersByCampaignId = async (req, res) => {
    try {
        const { campaign_id } = req.body;
        if (!campaign_id) {
            return res.status(200).json({ code: 400, message: "campId is missing" })
        }
        const campaigns = await Campaign.findOne({ campaign_id }, { _id: 0 })
            .populate({
                path: 'user',
                select: '-_id fullname mobile_number email'
            })
            .populate({
                path: 'admin',
                select: '- _id fullname mobile_number email'
            })
            .populate({
                path: 'bills',
                select: '-_id -email_hash -campaign_id'
            })
            .exec();

        if (!campaigns) {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }
        return res.status(200).json({ code: 200, data: campaigns });

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message });
    }
}

const getAllUserCampaignDetails = async (req, res) => {
    try {
        const userCampaigns = await Campaign.find({ user_email: { $exists: true }, status: { $ne: "NOT_APPROVED" } }, { _id: 0 })
        .populate({
            path:'user',
            select:'-_id fullname email mobile_number'
        })
        if (!userCampaigns) {
            return res.status(200).json({ code: 400, message: "No user campaigns found" })
        }
        // console.log(userCampaigns.user_email);
        // const user = await User.find({ email_hash: userCampaigns.user_email })
        return res.status(200).json({ code: 200, count: userCampaigns.length, data: userCampaigns })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }
}

const getUserCampaignDetailsById = async (req, res) => {
    const { hash } = req.body;
    if (!hash) {
        return res.status(200).json({ code: 400, message: "Email is missing" })
    }
    try {
        const campaignData = await Campaign.find({ user_email: hash, status: { $ne: "NOT_APPROVED" } })
            .populate(
                {
                    path: 'user',
                    select: " -_id fullname email mobile_number"

                }
            ).exec();
        if (!campaignData) {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }
        return res.status(200).json({ code: 200, count: campaignData.length, data: campaignData })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }

}

const saveReasonForCampaignCancellation = async (req, res) => {
    try {
        const { campaign_id, cancel_reason } = req.body;
        if (!campaign_id) {
            return res.status(200).json({ code: 400, message: "Campaign ID is missing" })
        }
        if (!cancel_reason) {
            return res.status(200).json({ code: 400, messag: "Reason is missing" })
        }
        const campaign = await Campaign.findOne({ campaign_id });
        if (!campaign) {
            return res.status(200).json({ code: 400, message: "no campaigns found" })
        }
        if (campaign.status === "CANCELLED") {
            return res.status(200).json({ code: 400, message: "campaign cancelled" })
        }
        campaign.status = "CANCELLED";
        campaign.reason_for_cancellation = cancel_reason;
        campaign.save();
        return res.status(200).json({ code: 200, message: "Reason saved successfully" })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }

}

module.exports = {
    saveUserCampaignDetails,
    findUsersByCampaignId,
    getAllUserCampaignDetails,
    getUserCampaignDetailsById,
    saveReasonForCampaignCancellation
}