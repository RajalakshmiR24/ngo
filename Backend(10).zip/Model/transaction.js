const mongoose = require("mongoose");

const transactionSchema = new mongoose.Schema({
    name: {
        type: String,
    },
    email: {
        type: String
    },
    amount: {
        type: String,
    },
    mobilenumber: {
        type: String,
    },

    transactionid: {
        type: String
    },
    campaign: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Campaign' }],
    user: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
    hash: { type: String },
    campaign_id: { type: String },
    campaigndetails: [Object],
    pg_response: [Object],

}, {
    timestamps: true
})



const Transaction = mongoose.model("Transaction", transactionSchema);

module.exports = { Transaction }