const mongoose = require("mongoose");

const billSchema = new mongoose.Schema({

    bills: { type: String },
    claiming_amount: { type: String },
    status: {
        type: String,
        enum: ['PENDING', 'APPROVED'],
        default: 'PENDING'
    },
    campaign_id: { type: String },
    campaign: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Campaign' }],
    user: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    reason_for_cancellation: { type: String },
    email_hash: { type: String },
    uploadedAt: { type: Date, default: Date.now }
})


const BillModel = mongoose.model("Bills", billSchema);

module.exports = { BillModel };