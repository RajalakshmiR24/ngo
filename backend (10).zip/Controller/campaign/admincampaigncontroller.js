const { Admin } = require("../../Model/admin");
const { Campaign } = require("../../Model/campaign");

//admin
const saveAdminCampaignDetails = async (req, res) => {
    const { title, type, description, start_date, end_date, banner, admin_email, address, budget } = req.body;

    try {
        if (!title || !type || !description || !start_date || !end_date || !banner || !admin_email || !address || !budget) {
            return res.status(200).json({ code: 400, message: "Bad request" })
        }
        const campaign = await Campaign.create({
            campaign_title: title,
            campaign_address: address,
            estimated_budget: budget,
            banner: banner,
            campaign_type: type,
            campaign_description: description,
            campaign_start_date: start_date,
            campaign_end_date: end_date,
            admin_email: admin_email,
            status: "APPROVED"
        });
        const admin = await Admin.findOne({ email_hash: admin_email });
        if (!admin) {
            return res.status(200).json({ code: 404, message: "Admin not found" });
        }
        if (!campaign) {
            return res.status(200).json({ code: 400, message: "Campaign not saved" })
        }
        admin.campaigns.push(campaign._id);
        await admin.save();

        return res.status(200).json({ code: 200, message: "Admin Campaign data created successfully" });

    } catch (error) {

        return res.status(200).json({ code: 500, errorMessage: error.message });
    }
}

const getAdminsByCampaignId = async (req, res) => {
    try {
        const { campaign_id } = req.body;
        if (!campaign_id) {
            return res.status(200).json({ code: 400, message: "campaign_id is missing" })
        }
        const campaigns = await Campaign.findOne({ campaign_id: campaign_id })
            .populate('Admin')
            .exec();

        if (!campaigns) {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }
        return res.status(200).json({ code: 200, data: campaigns });

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message });
    }
}

const getAdminCampaignDetailsById = async (req, res) => {
    try {
        const { email } = req.body;
        if (!email) {
            return res.status(200).json({ code: 400, message: "Email is missing" });
        }
        const adminCampaigns = await Admin.findOne({ admin_email: email });
        if (!adminCampaigns) {
            return res.status(200).json({ code: 400, message: "No admin campaigns found" })
        }
        return res.status(200).json({ code: 200, data: adminCampaigns })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}

const getAllAdminCampaignDetails = async (req, res) => {
    try {
        const adminCampaigns = await Campaign.find({ admin_email: { $exists: true } }, { _id: 0, admin_email: 0 })
            .populate("Admin").exec();
        if (!adminCampaigns) {
            return res.status(200).json({ code: 400, message: "No admin campaigns found" })
        }
        return res.status(200).json({ code: 200, count: adminCampaigns.length, data: adminCampaigns })
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })
    }
}

const updateAdminCampaignDetails = async (req, res) => {
    try {
        const { title, type, description, start_date, end_date, banner, admin_email, address, budget } = req.body;

        if (!title || !type || !description || !start_date || !end_date || !banner || !admin_email || !address || !budget) {
            return res.status(200).json({ code: 400, message: "Bad request" })
        }

        const checkCampaign = await Campaign.findOne({ admin_email: admin_email });
        if (!checkCampaign) {
            return res.status(200).json({ code: 400, message: "No campaign found to update" })
        }
        const campaign = await Campaign.findOneAndUpdate(
            { admin_email: admin_email },
            {
                $set: {
                    campaign_title: title,
                    campaign_address: address,
                    banner: banner,
                    estimated_budget: budget,
                    campaign_type: type,
                    campaign_description: description,
                    campaign_start_date: start_date,
                    campaign_end_date: end_date,
                    status: "APPROVED"
                }
            },
            { new: true }
        );
        // const admin = await Admin.findOne({ email_hash: admin_email });
        if (!campaign) {
            return res.status(200).json({ code: 400, message: "Update unsuccessfull" })
        }
        return res.status(200).json({ code: 200, message: "Admin Campaign data updated successfully" });
    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message });
    }
}


const deleteAdminCampaignDetails = async (req, res) => {
    try {
        const { email, campaign_id } = req.body;
        if (!campaign_id) {
            return res.status(200).josn({ code: 400, message: "Campaign ID is missing" })
        }

        const campaign = await Campaign.findOne({ campaign_id: campaign_id });
        if (!campaign) {
            return res.status(200).json({ code: 400, message: "No campaign found" })
        }
        const deleteCampaign = await Campaign.deleteOne({ campaign_id: campId });
        if (deleteCampaign.deletedCount === 0) {
            return res.status(200).json({ code: 400, message: "Deletion unsuccessfull" })
        }
        const bill = await BillModel.deleteMany({ campaign_id: campId });
        if (bill.deletedCount === 0) {
            return res.status(200).json({ code: 400, message: "Bill deletion unsuccessfull for campaign" })
        }
        return res.status(200).json({ code: 200, message: "Campaign deleted successfully", data: campaign })

    } catch (error) {
        return res.status(200).json({ code: 500, errorMessage: error.message })

    }
}

const getAllLiveCampaings = async (req, res) => {
    try {
        const currentDate = new Date();

        await Campaign.updateMany(
            {
                "campaign_start_date": { $lte: currentDate },
                "campaign_end_date": { $gte: currentDate },
                "status": "UPCOMING"
            },
            {
                $set: {
                    "campaigndetails.$[elem].status": "LIVE"
                }
            },
            {
                arrayFilters: [{ "elem.status": "LIVE" }]
            }
        );

        const liveCampaigns = await User.aggregate([
            {
                $unwind: "$campaigndetails"
            },
            {
                $match: {
                    "campaigndetails.start_date": { $lte: currentDate },
                    "campaigndetails.end_date": { $gte: currentDate },
                    "campaigndetails.status": "LIVE"
                }
            },
            {
                $project: {
                    _id: 0,
                    campaign_title: "$campaigndetails.campaign_title",
                    campaign_description: "$campaigndetails.campaign_description",
                    start_date: "$campaigndetails.start_date",
                    end_date: "$campaigndetails.end_date",
                    campaign_address: "$campaigndetails.campaign_address",
                    budget: "$campaigndetails.budget",
                    status: "$campaigndetails.status",
                    reason_for_cancellation: "$campaigndetails.reason_for_cancellation"
                }
            }
        ]);

        if (liveCampaigns.length > 0) {
            return res.status(200).json({ code: 200, data: liveCampaigns.length });
        } else {
            return res.status(200).json({ code: 404, message: "No live campaigns found" });
        }

    } catch (error) {
        console.error(error.message);
        return res.status(200).json({ code: 500, errorMessage: error.message });
    }

}


const getCancelledCampaings = async (req, res) => {
    try {
        const cancel = await User.aggregate([
            {
                $unwind: "$campaigndetails"
            },

            {
                $match: {
                    "campaigndetails.status": "CANCELLED"
                },

            },
            {
                $project: {
                    _id: 0,
                    "campaign_title": "$campaigndetails.campaign_title",
                    "campaigndetails": "$campaigndetails.campaigndetails    ",
                    "campaign_description": "$campaigndetails.campaign_description",
                    "start_date": "$campaigndetails.start_date",
                    "end_date": "$campaigndetails.end_date",
                    "campaign_address": "$campaigndetails.campaign_address",
                    "budget": "$campaigndetails.budget",
                    "status": "$campaigndetails.status",
                    "reason_for_cancellation": "$campaigndetails.reason_for_cancellation"
                }
            }


        ]);

        if (cancel.length > 0) {
            return res.status(200).json({ code: 200, data: cancel.length })
        } else {
            return res.status(200).json({ code: 400, message: "No campaigns found" })
        }

    } catch (error) {
        console.log(error.message);
        return res.status(200).json({ code: 500, errorMessage: error.message });

    }
}

const getCompletedCampaings = async (req, res) => {
    try {
        const currentDate = new Date();

        await User.updateMany(
            {
                "campaigndetails.end_date": { $lte: currentDate },
                "campaigndetails.status": "APPROVED"
            },
            {
                $set: {
                    "campaigndetails.$[elem].status": "COMPLETED"
                }
            },
            {
                arrayFilters: [{ "elem.status": "APPROVED" }]
            }
        );

        const completedCampaigns = await User.aggregate([
            {
                $unwind: "$campaigndetails"
            },
            {
                $match: {
                    "campaigndetails.start_date": { $lte: currentDate },
                    "campaigndetails.status": "COMPLETED"
                }
            },
            {
                $project: {
                    _id: 0,
                    campaign_title: "$campaigndetails.campaign_title",
                    campaign_description: "$campaigndetails.campaign_description",
                    start_date: "$campaigndetails.start_date",
                    end_date: "$campaigndetails.end_date",
                    campaign_address: "$campaigndetails.campaign_address",
                    budget: "$campaigndetails.budget",
                    status: "$campaigndetails.status",
                    reason_for_cancellation: "$campaigndetails.reason_for_cancellation"
                }
            }
        ]);

        if (completedCampaigns.length > 0) {
            return res.status(200).json({ code: 200, data: completedCampaigns.length });
        } else {
            return res.status(200).json({ code: 404, message: "No campaigns found" });
        }

    } catch (error) {
        console.error("Error processing campaigns:", error.message);
        return res.status(200).json({ code: 500, message: "Internal Server Error" });
    }


}

const getUpcomingCampaings = async (req, res) => {
    try {
        const currentDate = new Date();

        await User.updateMany(
            {
                "campaigndetails.start_date": { $gte: currentDate },
                "campaigndetails.status": "APPROVED"
            },
            {
                $set: {
                    "campaigndetails.$[elem].status": "UPCOMING"
                }
            },
            {
                arrayFilters: [{ "elem.status": "APPROVED" }]
            }
        );

        const upcoming = await User.aggregate([
            {
                $unwind: "$campaigndetails"
            },
            {
                $match: {
                    "campaigndetails.start_date": { $gte: currentDate },
                    "campaigndetails.status": "UPCOMING"
                }
            },
            {
                $project: {
                    _id: 0,
                    campaign_title: "$campaigndetails.campaign_title",
                    campaign_description: "$campaigndetails.campaign_description",
                    start_date: "$campaigndetails.start_date",
                    end_date: "$campaigndetails.end_date",
                    campaign_address: "$campaigndetails.campaign_address",
                    budget: "$campaigndetails.budget",
                    status: "$campaigndetails.status",
                    reason_for_cancellation: "$campaigndetails.reason_for_cancellation"
                }
            }
        ]);

        if (upcoming.length > 0) {
            return res.status(200).json({ code: 200, data: upcoming.length });
        } else {
            return res.status(200).json({ code: 404, message: "No campaigns found" }); // Changed to 404
        }

    } catch (error) {
        console.error(error.message);
        return res.status(200).json({ code: 500, errorMessage: error.message });
    }

}

module.exports = {
    saveAdminCampaignDetails,
    getAdminCampaignDetailsById, getAllAdminCampaignDetails,
    updateAdminCampaignDetails, deleteAdminCampaignDetails,
    getAdminsByCampaignId
}
