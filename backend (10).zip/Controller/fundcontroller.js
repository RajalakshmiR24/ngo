const { FundRequestModel } = require("../Model/fund");

const fundRequest = async (req, res) => {
    // console.log(req.body);
    try {
        const { title, description, campId, amount, email } = req.body;
        if (!title || !description || !amount || !email || !campId) {
            return res.status(200).json({ msg: " Bad Request", code: 400 });
        }
        const fundrequest = await FundRequestModel.create({
            title: title,
            description: description,
            amount: amount,
            email_hash: email,
            campaign_id: campId,
        })
        fundrequest.save();
        if (!fundrequest) {
            return res.status(200).json({ code: 400, message: "Something went wrong" })
        }
        return res.status(200).json({ message: "Requested Successfully", code: 200 });
    } catch (error) {
        return res.status(200).json({ message: "Something went wrong", code: 500 })
    }
}


module.exports = { fundRequest };

