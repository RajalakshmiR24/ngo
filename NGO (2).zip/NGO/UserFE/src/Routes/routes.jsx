import { createBrowserRouter, Navigate } from "react-router-dom";

// User Components
import UserSignIn from "../Components/User/UserLogin/UserSignIn.jsx";
import UserSignUp from "../Components/User/UserLogin/UserSignUp.jsx";
import CampaignDashboard from "../Components/User/Pages/1.Dashboard/Dashboard";
import CampaignLayout from "../Components/User/Layout/UserLayout";
import GeneralUsersList from "../Components/User/Pages/3.General/List/GeneralUsersList";

// ?Landing
import NotFound from "../Components/Common/NotFound/notFound";
import UserCampaigns from "../Components/User/Pages/2.Campaigns/UserCampaigns.jsx";
import PaymentForm from "../Utils/PaymentForm";
import { Layout } from "./../LandingPage/Layout/Layout";
import { HomePage } from "./../LandingPage/Pages/Home/Home";
import { Payments } from "../Utils/Payments.jsx";

export const router = createBrowserRouter([
  {
    path: "/ngo",
    element: <Navigate to="/ngo/home" />,
  },
  {
    path: "/ngo/home", //landing page
    element: <Layout />,
    children: [{ index: true, element: <HomePage /> }],
  },
  {
    path: "/ngo/register-user",
    element: <CampaignLayout />,
    children: [
      { index: true, element: <CampaignDashboard /> },
      {
        path: "new-campaign",
        element: <UserCampaigns />,
      },
      { path: "general-users", element: <GeneralUsersList /> },
    ],
  },
  {
    path: "/ngo/signin",
    element: <UserSignIn />,
  },
  {
    path: "/ngo/signup",
    element: <UserSignUp />,
  },
  {
    path: "/ngo/transaction",
    element: <PaymentForm />,
  },
  {
    path: "/ngo/logout",
    element: <UserSignIn />,
  },
  {
    path: "*",
    element: <NotFound />,
  },
  {
    path:"/ngo/payments",
    element:<Payments/>
  },
]);
