import React from 'react';
import './Donate.css'

export const Donate = () => {

  return (
    <div>
      <div className='form_container'>
        <form className='forms'>
          <label className='donate_form_name'>Name:
            <input type="text"
              placeholder='Enter your Name'
              required />
          </label>
          <br />
          <label className='donate_form_email'>Email:
            <input type="email"
              placeholder='Enter email'
              required />
          </label>
          <br />
          <label className='donate_form_number'>Ph Number:
            <input type="text"
              placeholder='Enter Phone number'
              required />
          </label>
          <br />
          <label className='donate_form_amount'>Amount:
            <input type="text"
              placeholder='Enter amount'
              required />
          </label>
          <div className='button_for_donate'>
            <button>Pay</button>
          </div>
        </form>
      </div>
    </div>

  );
};

