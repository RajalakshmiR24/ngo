import { Outlet } from "react-router-dom";
import Navbar from "../Common/Navbar/Navbar";
import { HomePage } from "../Pages/Home/Home";


export const Layout = () => {
    return (
        <>
            <Navbar />
            <Outlet />
        </>
    )
}