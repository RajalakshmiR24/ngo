import React, { useState } from 'react';
import axiosInstance from '../../../Utils/axiosInstance'; // Importing axiosInstance
import './Footer.css';

const Footer = () => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [message, setMessage] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const response = await axiosInstance.post('/api/ngo/user/general/savequeries', {
                name,
                email,
                message,
            });
            // Optionally, handle the response (e.g., show a success message)
            console.log('Response:', response.data);
            // Clear form fields
            setName('');
            setEmail('');
            setMessage('');
        } catch (error) {
            console.error('Error submitting feedback:', error);
        }
    };

    return (
        <footer>
            <div className='footer_flex'>
                <div className='ngo_content'>
                    <h2>Who We Are</h2>
                    <p>
                        Access to healthcare is essential for the well-being of any community, yet millions lack basic medical services. We focus on bridging this gap by bringing healthcare to underserved regions through mobile clinics, health camps, and partnerships with local providers. Our efforts emphasize preventive care, maternal and child health, and the treatment of common illnesses that disproportionately affect disadvantaged populations. We believe healthcare is a fundamental right, and we are committed to ensuring that those in need receive the care they deserve, regardless of their circumstances, helping to build healthier and more resilient communities.
                    </p>
                </div>
                <div className='landingpage_contect_page'>
                    <form className='footer_forms' onSubmit={handleSubmit}>
                        <label className='footer_name_feedbackname'>
                            <input
                                type="text"
                                placeholder='Enter your name..'
                                value={name}
                                required
                                onChange={(e) => setName(e.target.value)}
                            />
                        </label>
                        <br />
                        <label className='footer_email_form'>
                            <input
                                type="email"
                                placeholder='Enter your email..'
                                required
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                            />
                        </label>
                        <br />
                        <label>
                            <textarea
                                className='text_area'
                                placeholder='Write your inquiries..'
                                value={message}
                                required
                                onChange={(e) => setMessage(e.target.value)}
                            />
                        </label>

                        <div className='content_button'>
                            <button type="submit" className='cont_colors'>Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
