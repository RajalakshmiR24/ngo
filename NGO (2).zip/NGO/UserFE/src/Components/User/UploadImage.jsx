import React, { useState, useEffect } from "react";
import axiosInstance from "../../Utils/axiosInstance";

const UploadImage = () => {
  const [file, setFile] = useState(null);
  const [imageSrcs, setImageSrcs] = useState([]);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file) {
      alert("Please select an image file.");
      return;
    }

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64Image = reader.result.split(",")[1];
      try {
        await axiosInstance.post("/api/ngo/user/general/bannerimage", {
          campId: "7837385f-32e4-42f9-89ce-6f91347532b9",
          email_hash:
            "02ee7bdc4ccf5c94808a0118eb531822f13e7e38e3810ab29ebefb2c2feb8e58",
          base64Image,
        });
        alert("Image uploaded successfully");
        fetchImages(); // Fetch images after successful upload
      } catch (error) {
        console.error("Error uploading image:", error);
        alert("Image upload failed");
      }
    };
    reader.readAsDataURL(file);
  };

  const fetchImages = async () => {
    try {
      const res = await axiosInstance.post("/api/ngo/user/user/usercampaigndata", {
        campId: "a5ba3d99-bbf8-404c-b681-c796be863ddb",
      });

      if (res.data.code === 200) {
        const banner = res.data.data.banner; // Ensure this is the correct path
        if (banner) {
          setImageSrcs(banner); // Assuming banner is a string or array of strings
        }
      } else {
        console.error("Error fetching images:", res.data.message);
      }
    } catch (error) {
      console.error("Error fetching images:", error);
    }
  };

  useEffect(() => {
    fetchImages(); // Fetch images on component mount
  }, []);

  return (
    <div>
      <h1>Upload Image</h1>
      <form onSubmit={handleSubmit}>
        <input type="file" onChange={handleFileChange} accept="image/*" />
        <button type="submit">Upload</button>
      </form>

      <div>
        {imageSrcs.length > 0 ? (
          imageSrcs.map((src, index) => (
            <img key={index} src={`data:image/png;base64,${src}`} alt={`Image ${index}`} />
          ))
        ) : (
          <p>No images found.</p>
        )}
      </div>
    </div>
  );
};

export default UploadImage;
