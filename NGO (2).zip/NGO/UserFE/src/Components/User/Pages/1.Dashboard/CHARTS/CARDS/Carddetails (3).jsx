import React, { useEffect, useState } from "react";
import axios from "axios";
import "./Carddetails.css";
import axiosInstance from "../../../../../../Utils/axiosInstance.js";

export const Carddetails = () => {
  const [monthCount, setMonthCount] = useState(0);
  const [dayCount, setDayCount] = useState(0);
  const [weekCount, setWeekCount] = useState(0);
  const [yearCount, setYearCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const email = localStorage.getItem("hash");
        const response = await axiosInstance.post(
          "/api/ngo/user/user/statuscount1",
          { email }
        );
        const counts = extractCounts(response.data.data);

        setMonthCount(counts.totalMonthCount);
        setDayCount(counts.totalDayCount);
        setWeekCount(counts.totalWeekCount);
        setYearCount(counts.totalYearCount);
      } catch (err) {
        setError("Failed to fetch data.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const extractCounts = (data) => {
    let totalMonthCount = 0;
    let totalDayCount = 0;
    let totalWeekCount = 0;
    let totalYearCount = 0;

    const now = new Date();
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(now.getDate() - 7);
    data.counts.forEach((month) => {
      totalMonthCount += month.totalCount;
      totalYearCount += month.totalCount;

      month.dailyCounts.forEach((day) => {
        totalDayCount += day.completedCount;

        const dayDate = new Date(day.day);
        if (dayDate >= oneWeekAgo) {
          totalWeekCount += day.completedCount;
        }
      });
    });

    return {
      totalMonthCount,
      totalDayCount,
      totalWeekCount,
      totalYearCount,
    };
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <div className="card-details">
      <h2>Total Campaign Count</h2>
      <div className="cards">
        <div className="card">
          <h2>Total Month Count</h2>
          <p>{monthCount}</p>
        </div>
        <div className="card">
          <h2> Total Days Count</h2>
          <p>{dayCount}</p>
        </div>
        <div className="card">
          <h2>Total Week Count</h2>
          <p>{weekCount}</p>
        </div>
        <div className="card">
          <h2>Total Year Count</h2>
          <p>{yearCount}</p>
        </div>
      </div>
    </div>
  );
};
