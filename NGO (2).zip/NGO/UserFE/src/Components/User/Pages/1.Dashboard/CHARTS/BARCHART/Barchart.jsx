import React, { useEffect, useState } from 'react';
import { Bar } from 'react-chartjs-2';
import axiosInstance from '../../../../../../Utils/axiosInstance';
import { Chart as ChartJS, BarElement, CategoryScale, LinearScale, Title, Tooltip, Legend } from 'chart.js';
import { useNavigate } from 'react-router-dom';

ChartJS.register(BarElement, CategoryScale, LinearScale, Title, Tooltip, Legend);

const Barchart = () => {
    const navigate = useNavigate();

    const [chartData, setChartData] = useState({
        labels: ['LIVE', 'ONGOING', 'UPCOMING', 'COMPLETED', 'CANCELLED'],
        datasets: [
            {
                label: 'Event Status Counts',
                data: [0, 0, 0, 0, 0],
                backgroundColor: [
                    'rgba(179, 179, 116, 0.6)',
                    'rgba(255, 206, 86, 0.6)',
                    'rgba(54, 162, 235, 0.6)',
                    'rgba(255, 99, 132, 0.6)',
                    'rgba(153, 102, 255, 0.6)',
                ],
            },
        ],
    });

    const options = {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
            title: {
                display: true
            },
        },
    };

    const fetchData = async () => {
        try {
            const email = localStorage.getItem('hash');
            const response = await axiosInstance.post('/api/ngo/user/user/statuscount', { email });
            if (!localStorage.getItem("token")) {
                window.location.href = "/"
            }
            console.log(response.data, "9999999999999999999999");
            const campaignCounts = response.data.data;

            const salesData = [
                campaignCounts.LIVE || 0,
                campaignCounts.ONGOING || 0,
                campaignCounts.UPCOMING || 0,
                campaignCounts.COMPLETED || 0,
                campaignCounts.CANCELLED || 0,
            ];

            setChartData(prevData => ({
                ...prevData,
                datasets: [{
                    ...prevData.datasets[0],
                    data: salesData,
                }],
            }));
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };
    useEffect(() => {

        fetchData();
    }, []);

    return (
        <div style={{ height: "50vh", width: "100%" }} className='bar_chart'>
            <h2 >Event Status Counts</h2>
            <Bar style={{ boxShadow: "0px 5px 8px 3px rgb(214, 206, 206)", height: "40vh", width: "100%", marginLeft: "400px" }} data={chartData} options={options} />
        </div>
    );
};

export default Barchart;
