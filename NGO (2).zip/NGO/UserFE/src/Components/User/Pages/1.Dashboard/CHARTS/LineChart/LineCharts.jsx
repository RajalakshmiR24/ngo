import React, { useEffect, useRef, useState } from "react";
import { Pie } from "react-chartjs-2";
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
} from "chart.js";
import axiosInstance from "../../../../../../Utils/axiosInstance";
import empty from './empty pie image.jpeg';

ChartJS.register(ArcElement, Tooltip, Legend);

const PieChart = () => {
  const [contribution, setContribution] = useState(0);
  const [pendingExpense, setPendingExpense] = useState(0);
  const [approvedExpense, setApprovedExpense] = useState(0);
  const email = localStorage.getItem("hash");

  const fetchDatas = () => {

    axiosInstance.post(`/api/ngo/user/user/contribution`, { email })
      .then((res) => {
        if (res.data.code === 200) {
          setContribution(res.data.data);
        }else{
          setContribution(0);

        }
      })
      .catch((err) => {
        console.log(err, "error in fetching contribution data");
      })

    axiosInstance.post(`/api/ngo/user/user/getpendingexpense`, { email })
      .then((res) => {
        if (res.data.code === 200) {
          setPendingExpense(res.data.expense);
        }
      })
      .catch((err) => {
        console.log(err, "error in fetching pending expense data");
      })

    axiosInstance.post(`/api/ngo/user/user/getapprovedexpense`, { email })
      .then((res) => {
        if (res.data.code === 200) {
          setApprovedExpense(res.data.expense);
        }
      })
      .catch((err) => {
        console.log(err, "error in fetching approved expense data");
      })
  };

  useEffect(() => {
    fetchDatas();
  }, []);

  const pieChartData = {
    labels: ['Total Contribution', 'Approved Expense', 'Pending Expense'],
    datasets: [
      {
        label: 'Amount',
        data: [contribution || 0, approvedExpense || 0, pendingExpense || 0],
        backgroundColor: [
          'rgba(255, 99, 132, 0.7)', // Contribution color
          'rgba(54, 162, 235, 0.7)', // Approved Expense color
          'rgba(255, 206, 86, 0.7)', // Pending Expense color
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
        ],
        borderWidth: 2,
      },
    ],
  }

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
        labels: {
          font: {
            size: 14,
            weight: 'bold',
          },
        },
      },
      title: {
        display: true,
        text: 'Contribution and Expenses Overview',
        font: {
          size: 18,
          weight: 'bold',
        },
      },
      tooltip: {
        callbacks: {
          label: function (context) {
            let label = context.label || ' ';
            if (context.parsed !== null) {
              label += `: ${context.raw}`;
            }
            return label;
          }
        },
        backgroundColor: 'rgba(0, 0, 0, 0.7)',
      },
    },
  };

  return (
    <div
      style={{
        boxShadow: "0px 5px 8px 3px rgb(214, 206, 206)",
        height: "50vh",
        width: "300px",
        padding:"20px",
        margin: "0 auto",
        maxWidth: "800px",

      }}
      className="pie_chart"
    >
      {/* <h2>Contribution and Expenses</h2> */}
      {/* {contribution === 0 ? <img src={empty}></img> : */}

      <Pie data={pieChartData} options={options} />
      {/* } */}
    </div>
  );
    }

export default PieChart;
