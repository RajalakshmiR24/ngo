import React from 'react';
import Sidebar from '../Common/Sidebar/Sidebar';
import { Outlet } from 'react-router-dom';
import './userLayout.css'

const UserLayout = () => {
  return (

    <div className='layout'>
      <Sidebar />
      <div>
        <Outlet />
      </div>
    </div>
  );
}

export default UserLayout;
