import "./style122.css";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axiosInstance from "../../../Utils/axiosInstance.js";

const UserSignUp = () => {
  const [values, setValues] = useState({});
  const [focused, setFocused] = useState({});
  const navigate = useNavigate();

  const handleFocus = (name) => {
    setFocused((prev) => ({ ...prev, [name]: true }));
  };

  const inputs = [
    {
      id: 1,
      name: "username",
      type: "text",
      placeholder: "Username",
      errormessage:
        "Username should be 3-16 characters and shouldn't include any special characters",
      pattern: "^[a-zA-Z0-9]{3,16}$",
      label: "Name",
      required: true,
    },
    {
      id: 2,
      name: "email",
      type: "email",
      errormessage: "It should be a valid email",
      pattern: "^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$",
      placeholder: "Email",
      label: "Email",
      required: true,
    },
    {
      id: 3,
      name: "mobilenumber",
      type: "text",
      errormessage: "It should be a valid mobile number",
      pattern: "^[0-9]{10}$",
      placeholder: "Mobile Number",
      label: "Mobile Number",
      required: true,
    },
    {
      id: 4,
      name: "password",
      type: "password",
      errormessage:
        "Password should be 8-20 characters and include at least 1 letter, 1 number, and 1 special character",
      placeholder: "Password",
      pattern: "^(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[!@#$%^&*]).{8,20}$",
      label: "Password",
      required: true,
    },
    {
      id: 5,
      name: "confirmPassword",
      type: "password",
      errormessage: "Passwords don't match!",
      placeholder: "Confirm Password",
      label: "Confirm Password",
      required: true,
    },
  ];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues({ ...values, [name]: value });
    if (name === "confirmPassword") {
      setFocused({ ...focused, confirmPassword: true });
    }
  };

  const handleSubmit = async (e) => {
    console.log("hhhhhhh");
    
    e.preventDefault();
    await axiosInstance
      .post(`/api/ngo/user/user/register`, values)
      .then((res) => {
        if (res.data.code === 200) {
          localStorage.setItem("hash", res.data.hash);
          setValues({});
          navigate("/ngo/signin");
        }
      })
      .catch((err) => {
        console.log(err, "error in registering user details");
      });
  };

  return (
    <div className="app">
      <form className="form" onSubmit={handleSubmit}>
        <h1 className="form-title">Register</h1>
        {inputs.map((input) => (
          <div className="formInput" key={input.id}>
            <label className="form-label">{input.label}</label>
            <input
              {...input}
              className="form-input"
              value={values[input.name] || ""}
              onChange={handleChange}
              onFocus={() => handleFocus(input.name)}
              onBlur={() => handleFocus(input.name)}
            />
            {focused[input.name] && !values[input.name] && (
              <span className="error">{input.errormessage}</span>
            )}
            {input.name !== "confirmPassword" &&
              focused[input.name] &&
              values[input.name] &&
              !new RegExp(input.pattern).test(values[input.name]) && (
                <span className="error">{input.errormessage}</span>
              )}
            {input.name === "confirmPassword" &&
              values[input.name] !== values.password && (
                <span className="error">{input.errormessage}</span>
              )}
          </div>
        ))}
        <button type="submit" className="form-button">
          Register
        </button>
        <p className="form-text">
          Already have an account? <Link to="/ngo/signin">Login here</Link>
        </p>
      </form>
    </div>
  );
};

export default UserSignUp;
