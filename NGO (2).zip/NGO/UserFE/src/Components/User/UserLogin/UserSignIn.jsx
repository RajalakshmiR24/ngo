import "./style122.css";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axiosInstance from "../../../Utils/axiosInstance.js";

const UserSignIn = () => {
  const [values, setValues] = useState({});
  const [focused, setFocused] = useState({});
  const navigate = useNavigate();

  const handleFocus = (name) => {
    setFocused((prev) => ({ ...prev, [name]: true }));
  };

  const inputs = [
    {
      id: 1,
      name: "email",
      type: "email",
      placeholder: "Email",
      errormessage: "It should be a valid email",
      pattern: "^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$",
      label: "Email",
      required: true,
    },
    {
      id: 2,
      name: "password",
      type: "password",
      placeholder: "Password",
      errormessage:
        "Password should be 8-20 characters and include at least 1 letter, 1 number, and 1 special character",
      pattern: "^(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[!@#$%^&*]).{8,20}$",
      label: "Password",
      required: true,
    },
  ];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues({ ...values, [name]: value });
    setFocused({ ...focused, [name]: true });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    axiosInstance
      .post(`/api/ngo/user/user/login`, values)
      .then((res) => {
        if (res.data.code === 200) {
          localStorage.setItem("hash", res.data.data);
          localStorage.setItem("token", res.data.accessToken);
          setValues({});
          axiosInstance.defaults.headers[
            "Authorization"
          ] = `Bearer ${res.data.accessToken}`;
          navigate("/ngo/register-user");
        } else {
          alert(res.data.msg)
          window.location = "/"
        }
      })
      .catch((err) => {
        console.log(err, "error in signing in user");
      });
  };

  return (
    <div className="app">
      <form className="form" onSubmit={handleSubmit}>
        <h1 className="form-title">Login</h1>
        {inputs.map((input) => (
          <div className="formInput" key={input.id}>
            <label className="form-label">{input.label}</label>
            <input
              {...input}
              className="form-input"
              value={values[input.name] || ""}
              onChange={handleChange}
              onFocus={() => handleFocus(input.name)}
              onBlur={() => handleFocus(input.name)}
            />
            {focused[input.name] && !values[input.name] && (
              <span className="error">{input.errormessage}</span>
            )}
            {focused[input.name] &&
              values[input.name] &&
              !new RegExp(input.pattern).test(values[input.name]) && (
                <span className="error">{input.errormessage}</span>
              )}
          </div>
        ))}
        <button type="submit" className="form-button">
          Login
        </button>
        <p className="form-text">
          Don't have an account? <Link to="/ngo/signup">Create an account</Link>
        </p>
      </form>
    </div>
  );
};

export default UserSignIn;
