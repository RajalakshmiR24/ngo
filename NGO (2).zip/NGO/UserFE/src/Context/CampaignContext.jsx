import React, { createContext, useState } from "react";

export const CampaignContext = createContext();

export const CampaignProvider = ({ children }) => {
  const [adminCampaigns, setAdminCampaigns] = useState([]);
  const [userCampaigns, setUserCampaigns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newCampaign, setNewCampaign] = useState({
    campaign_title: "",
    campaign_description: "",
    start_date: "",
    end_date: "",
    campaign_address: "",
    budget: "",
    campaign_type: "",
    isAdmin: false,
  });
  const [activeCampaignType, setActiveCampaignType] = useState("user");

  const email = localStorage.getItem("hash");
  

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewCampaign((prev) => ({ ...prev, [name]: value }));
  };

  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);

  const handleToggleCampaignType = (type) => {
    setActiveCampaignType(type);
  };

  return (
    <CampaignContext.Provider
      value={{
        adminCampaigns,
        userCampaigns,
        loading,
        newCampaign,
        handleChange,
        openModal,
        closeModal,
        handleToggleCampaignType,
        activeCampaignType,
        isModalOpen,
        setAdminCampaigns,
        setUserCampaigns,
        setLoading,
        setIsModalOpen,
        email,
      }}
    >
      {children}
    </CampaignContext.Provider>
  );
};
