import React, { useRef, useState } from 'react';
import axiosInstance from './axiosInstance';
import './PaymentForm.css'
import { useLocation } from 'react-router-dom';
const Form = () => {
    const formRef = useRef(null);
    const { state } = useLocation();
    console.log(state, "999999999999999999999999999999999");

    const [formData, setFormData] = useState({
        "platform": "web",
        "name": "",
        "mobilenumber": "",
        'email': "",
        "amount": "",
        'creditcardnumber': "",
        "registeredmobilenumber": ""
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
            campId: state.camp,

        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log(formData);
        try {
            await axiosInstance.post('/api/ngo/user/transaction/trans', formData, { timeout: 30000 })
                .then((res) => {
                    console.log(res);
                    if (res.data.code === 200) {
                        let form = res.data.value;
                        console.log(form);
                        if (formRef.current) {
                            formRef.current.innerHTML = form;
                            const formElement = formRef.current.querySelector("form");
                            if (formElement) {
                                HTMLFormElement.prototype.submit.call(formElement);
                            }
                        }
                    }
                })
        } catch (error) {
            console.error('Payment Error:', error);
        }
    };

    return (
        <div>
            <div className='container_page'>
                <form className='payments_donate_forms' onSubmit={handleSubmit}>
                    <h2>Payment Form</h2>
                    <div className='width_for_paymentsform'>
                        <div className='payments_divs'>
                            <label className='payment_name'>
                                Name :<br />
                                <input
                                    type="text"
                                    placeholder='Enter your name'
                                    name="name"
                                    value={formData.name}
                                    onChange={handleChange}
                                />
                            </label>
                            {/* <label className='payment_name'>
                                Name: <br />
                                <input
                                    type="text"
                                    placeholder="Enter your name"
                                    name="name"
                                    required // Makes the field required
                                    pattern=".*\S.*"
                                />
                                <div className="error-message">
                                    Name is required.
                                </div>
                            </label> */}

                        </div>
                        <div className='payments_divs'>
                            <label className='payment_email'>
                                Email :<br />
                                <input
                                    type="email"
                                    name="email"
                                    placeholder='Enter email'
                                    value={formData.email}
                                    onChange={handleChange}
                                />
                            </label>
                        </div>
                        <div className='payments_divs'>
                            <label className='payment_number'>
                                Mobile Number :<br />
                                <input
                                    type="text"
                                    name="mobilenumber"
                                    placeholder='Mobile number'
                                    pattern='^[7896]\d{9}$'
                                    value={formData.mobilenumber}
                                    onChange={handleChange}
                                />
                            </label>
                        </div>
                        <div className='payments_divs'>
                            <label className='payment_card_number'>
                                Credit Card Number : <br />
                                <input
                                    type="text"
                                    name="creditcardnumber"
                                    placeholder='Last 4 digits'
                                    value={formData.creditcardnumber}
                                    onChange={handleChange}
                                />
                            </label>
                        </div>
                        <div className='payments_divs'>
                            <label className='payment_ph_number'>
                                Registered Mobile Number :<br />
                                <input
                                    type="text"
                                    name="registeredmobilenumber"
                                    placeholder='Reg Mobile number'
                                    pattern='^[7896]\d{9}$'
                                    value={formData.registeredmobilenumber}
                                    onChange={handleChange}
                                    required
                                />
                            </label>
                        </div>
                        <div className='payments_divs'>
                            <label className='payments_amount'>
                                Amount :<br />
                                <input
                                    type="text"
                                    name="amount"
                                    placeholder='Enter amount'
                                    value={formData.amount}
                                    onChange={handleChange}
                                />
                            </label>
                        </div>
                        <button className='donate_button' type="submit">Pay Now</button>
                    </div>
                </form>
                <div ref={formRef}></div>
            </div>
        </div>
    );
};

export default Form;
