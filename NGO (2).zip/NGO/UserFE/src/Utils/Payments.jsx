import { useLocation, useNavigate } from "react-router-dom";
import axiosInstance from "./axiosInstance";
import { toast } from "react-toastify";

export const Payments = () => {
  const location = useLocation();

  const navigate = useNavigate();
  const query = new URLSearchParams(location.search);
  //   console.log("fawefawfe");

  //   console.log(query);
  // Function to parse query parameters
  // const getQueryParams = () => {
  // return {
  // };
  // };

  const transid = query.get("transid");
  const code = query.get("code");
  const status = query.get("status");

  console.log(transid, code, "qqqqqqqqqqq");
  if (transid && code) {
    // const { transid, code } = getQueryParams();
    axiosInstance
      .post(`/api/ngo/user/transaction/getparams`, { transId: transid, code, status })
      .then((res) => {
        if (res.data.code === 200) {
          if (res.data.msg === "success") {
            alert("Payment Success. Thank you!");
            navigate("/");
          } else {
            alert("Payment failed. Try again later");
          }
        }
      });
  }
  console.log(transid, code);
  return (
    <div>
      <p>Redirecting...</p>
    </div>
  );
};
