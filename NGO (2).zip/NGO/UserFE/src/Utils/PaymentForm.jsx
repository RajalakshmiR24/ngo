import React, { useRef, useState } from 'react';
import axiosInstance from './axiosInstance';
import './PaymentForm.css';
import { useLocation } from 'react-router-dom';

const PaymentForm = () => {
    const formRef = useRef(null);
    const { state } = useLocation();
    console.log(state, "00000000000000000000000");

    const initialFormData = {
        platform: "web",
        name: "",
        mobilenumber: "",
        email: "",
        amount: "",
        creditcardnumber: "",

    };

    const [formData, setFormData] = useState(initialFormData);
    const [errors, setErrors] = useState({});

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
            registeredmobilenumber: formData.mobilenumber,
            campId: state.camp

        }));
        setErrors((prevErrors) => ({ ...prevErrors, [name]: '' }));
    };

    const validate = () => {
        const newErrors = {};

        if (!formData.name) {
            newErrors.name = "Name is required";
        }
        if (!formData.email) {
            newErrors.email = "Email is required";
        } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
            newErrors.email = "Email format is invalid";
        }
        if (!formData.mobilenumber) {
            newErrors.mobilenumber = "Mobile number is required";
        } else if (!/^\d{10}$/.test(formData.mobilenumber)) {
            newErrors.mobilenumber = "Mobile number must be 10 digits";
        }
        if (!formData.creditcardnumber) {
            newErrors.creditcardnumber = "Credit card number is required";
        } else if (!/^\d{4}$/.test(formData.creditcardnumber)) {
            newErrors.creditcardnumber = "Credit card number must be 4 digits";
        }
        // if (!formData.registeredmobilenumber) {
        //     newErrors.registeredmobilenumber = "Registered mobile number is required";
        // } else if (!/^[7689]\d{9}$/.test(formData.registeredmobilenumber)) {
        //     newErrors.registeredmobilenumber = "Registered mobile number must be 10 digits";
        // }
        if (!formData.amount) {
            newErrors.amount = "Amount is required";
        } else if (isNaN(formData.amount) || Number(formData.amount) <= 0) {
            newErrors.amount = "Amount must be a positive number";
        }

        return newErrors;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const validationErrors = validate();
        setErrors(validationErrors);

        if (Object.keys(validationErrors).length > 0) {
            return;
        }

        try {
            const res = await axiosInstance.post('/api/ngo/user/transaction/trans', formData, { timeout: 30000 });
            if (res.data.code === 200) {
                let form = res.data.value;
                if (formRef.current) {
                    formRef.current.innerHTML = form;
                    const formElement = formRef.current.querySelector("form");
                    if (formElement) {
                        HTMLFormElement.prototype.submit.call(formElement);
                    }
                }
            }
        } catch (error) {
            console.error('Payment Error:', error);
        }
    };

    return (
        <div>
            <div className='container_page'>
                <form className='payments_donate_forms' onSubmit={handleSubmit}>
                    <h2>Payment Form</h2>
                    <div className='width_for_paymentsform'>
                        <div>
                            <label className='payment_name'>
                                Name <br />
                                <input
                                    type="text"
                                    placeholder='Enter your name'
                                    name="name"
                                    value={formData.name}
                                    onChange={handleChange}
                                />
                                <br />
                                {errors.name && <span className="error">{errors.name}</span>}
                            </label>
                        </div>
                        <div>
                            <label className='payment_email'>
                                Email <br />
                                <input
                                    type="email"
                                    name="email"
                                    placeholder='Enter email'
                                    value={formData.email}
                                    onChange={handleChange}
                                />
                                <br />
                                {errors.email && <span className="error">{errors.email}</span>}
                            </label>
                        </div>
                        <div>
                            <label className='payment_number'>
                                Mobile Number <br />
                                <input
                                    type="text"
                                    name="mobilenumber"
                                    placeholder='Mobile number'
                                    value={formData.mobilenumber}
                                    onChange={handleChange}
                                />
                                <br />
                                {errors.mobilenumber && <span className="error">{errors.mobilenumber}</span>}
                            </label>
                        </div>
                        <div>
                            <label className='payment_card_number'>
                                Credit Card Number <br />
                                <input
                                    type="text"
                                    name="creditcardnumber"
                                    placeholder='Last 4 digits'
                                    value={formData.creditcardnumber}
                                    onChange={handleChange}
                                />
                                <br />
                                {errors.creditcardnumber && <span className="error">{errors.creditcardnumber}</span>}
                            </label>
                        </div>
                        {/* <div>
                            <label className='payment_ph_number'>
                                Registered Mobile Number<br />
                                <input
                                    type="text"
                                    name="registeredmobilenumber"
                                    placeholder='Reg Mobile number'
                                    value={formData.registeredmobilenumber}
                                    onChange={handleChange}
                                    required
                                /><br />
                                {errors.registeredmobilenumber && <span className="error">{errors.registeredmobilenumber}</span>}
                            </label>
                        </div> */}
                        <div>
                            <label className='payment_amount'>
                                Amount :<br />
                                <input
                                    type="text"
                                    name="amount"
                                    placeholder='Enter amount'
                                    value={formData.amount}
                                    onChange={handleChange}
                                />
                                <br />
                                {errors.amount && <span className="error">{errors.amount}</span>}
                            </label>
                        </div>
                        <button className='donate_button' type="submit">Pay Now</button>
                    </div>
                </form>
                <div ref={formRef}></div>
            </div>
        </div>
    );
};

export default PaymentForm;
