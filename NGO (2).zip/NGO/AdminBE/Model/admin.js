const mongoose = require("mongoose")

const bcrypt = require("bcrypt")
const crypto = require("crypto");
const jwt = require("jsonwebtoken")

const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

const adminSchema = new mongoose.Schema({
    fullname: {
        type: String,
    },
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        // match: [/.+\@.+\..+/, '@ . required']
    },
    password: {
        type: String,
        required: true,
        minlength: 8,
        // validate: {
        //     validator: function (value) {
        //         return passwordRegex.test(value);
        //     },
        //     message: 'Password must be at least 8 characters long, include at least one letter, one digit, and one special character.'
        // }

    },
    mobile_number: {
        type: String,
        unique: true,
        // match: [/^([6-9][0-9]{9})$/, 'Please enter a valid mobile number']
    },
    campaigns: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Campaign'
    }],
    bills: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: "Bills"
    }],
    transactions: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Transaction' }],

    email_hash: {
        type: String
    },
    role: {
        type: String,
        enum: ['USER', 'ADMIN', 'VOLUNTEER'],
        default: "ADMIN"
    },
    refreshToken: {
        type: String
    }
}, { timestamps: true }
);


adminSchema.pre("save", async function (next) {
    if (this.isModified("password")) {
        console.log("Original password:", this.password);
        if (!passwordRegex.test(this.password)) {
            return next(new Error('Password must be at least 8 characters long, include at least one letter, one digit, and one special character.'));
        }
        const saltRounds = 12;
        try {
            this.password = await bcrypt.hash(this.password, saltRounds);
        } catch (error) {
            return next(error);
        }
    }
    if (this.isModified("email")) {
        try {
            const hash = crypto.createHash('sha256');
            hash.update(this.email);
            this.email_hash = hash.digest('hex');
            // console.log("Hashed email:", this.email_hash);
        } catch (error) {
            console.log("Error in saving email hash:", error);
            return next(error);
        }
    }
    next();
})

adminSchema.methods.isPasswordCorrect = async function (password) {
    return await bcrypt.compare(password, this.password);
}

// adminSchema.methods.generateAccessToken = function () {
//     const payload = {
//         email_hash: this.email_hash,
//         date: this.createdAt
//     }

//     return jwt.sign(payload, process.env.ACCESS_TOKEN_SECRET_KEY, { expiresIn: process.env.ACCESS_TOKEN_EXPIRY })
// }

// adminSchema.methods.generateRefreshToken = function () {
//     const payload = {
//         email_hash: this.email_hash,
//         date: this.createdAt
//     }

//     return jwt.sign(payload, process.env.REFRESH_TOKEN_SECRET_KEY, { expiresIn: process.env.REFRESH_TOKEN_EXPIRY })

// }

adminSchema.methods.getEmailHash = function () {
    return this.email_hash;

}

const Admin = mongoose.model("Admin", adminSchema);

module.exports = { Admin }










