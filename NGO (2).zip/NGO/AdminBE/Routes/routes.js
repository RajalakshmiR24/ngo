const express = require("express");
const { uploadImage, fetchImage } = require("../Controller/admincontroller");
const { getTransactionResponse, transactionsDetailsByCampaignId } = require("../Controller/transactioncontroller");
const { getAllUpcomingCampaigns } = require("../Controller/campaigncontroller");
const { saveQueries } = require("../Controller/querycontroller");

const router = express.Router();

router.post("/savequeries", saveQueries);

router.get("/getallca", getAllUpcomingCampaigns)
router.post("/gettransactiondetails", transactionsDetailsByCampaignId)


module.exports = { router };
