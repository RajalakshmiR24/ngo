// Routes/ngoRoutes.js
const express = require('express');
const adminRouter = require('./adminroutes');
const userRouter = require('./userroutes');
const { transactionRouter } = require('./transactionroutes');

const router = express.Router();

// Mount the routers
router.use('/admin', adminRouter);

module.exports = router;
