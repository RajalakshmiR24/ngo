const dotenv = require("dotenv");
dotenv.config();
const express = require("express");
const connectDB = require("./Database/Db");
const cors = require("cors");
const ngoRouter = require("./Routes/ngoRoutes"); // Use the new ngoRoutes
const bodyParser = require("body-parser");
const app = express();

app.use(express.json({ limit: "10mb" }));
app.use(cors({
    // Configure your CORS options here
}));
app.use(express.urlencoded({ extended: true }));

const PORT = process.env.PORT || 5000;

// Use the new ngoRouter
app.use("/api/ngo", ngoRouter);

connectDB().then(() => {
    const server = app.listen(PORT, () => {
        console.log(`Listening on port ${PORT}`);
    });

    server.on("request", (req, res) => {
        console.log(`${req.method}-----${req.url}`);
    });

}).catch((err) => {
    console.log(err);
});
