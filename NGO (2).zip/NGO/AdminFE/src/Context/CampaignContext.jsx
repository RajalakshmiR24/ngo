import React, { createContext, useState } from 'react';

export const CampaignContext = createContext();

export const CampaignProvider = ({ children }) => {
  const [adminCampaigns, setAdminCampaigns] = useState([]);
  const [userCampaigns, setUserCampaigns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newCampaign, setNewCampaign] = useState({
    campaign_title: '',
    campaign_description: '',
    start_date: '',
    end_date: '',
    campaign_address: '',
    budget: '',
    campaign_type: '',
    isAdmin: false,
  });
  const [activeCampaignType, setActiveCampaignType] = useState('user');

  // New states added
  const [campaignType, setCampaignType] = useState('admin');
  const [createCampaignType, setCreateCampaignType] = useState('admin');
  const [statusFilter, setStatusFilter] = useState("all");
  const [isCampaignFormModalOpen, setCampaignFormModalOpen] = useState(false);
  const [isUserCampaignFormModalOpen, setUsersCampaignFormModalOpen] = useState(false);
  const [isAdminCampaignDetailModalOpen, setAdminCampaignDetailModalOpen] = useState(false);
  const [isUserCampaignDetailModalOpen, setUserCampaignDetailModalOpen] = useState(false);
  const [campaign, setCampaign] = useState({
    campaign_title: "",
    campaign_type: "",
    campaign_description: "",
    start_date: "",
    end_date: "",
    campaign_address: "",
    estimated_budget: "",
    collected_amount: "",
    banner: "",
    mobilenumber: "",
  });
  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const [isCancelModalOpen, setIsCancelModalOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState("");
  const [selectedCampaignForCancellation, setSelectedCampaignForCancellation] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewCampaign((prev) => ({ ...prev, [name]: value }));
  };

  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);

  const handleToggleCampaignType = (type) => {
    setActiveCampaignType(type);
  };

  return (
    <CampaignContext.Provider
      value={{
        adminCampaigns,
        userCampaigns,
        loading,
        newCampaign,
        handleChange,
        openModal,
        closeModal,
        handleToggleCampaignType,
        activeCampaignType,
        isModalOpen,
        setAdminCampaigns,
        setUserCampaigns,
        setLoading,
        // New context values added
        campaignType,
        createCampaignType,
        statusFilter,
        isCampaignFormModalOpen,
        isUserCampaignFormModalOpen,
        isAdminCampaignDetailModalOpen,
        isUserCampaignDetailModalOpen,
        campaign,
        selectedCampaign,
        isCancelModalOpen,
        cancelReason,
        selectedCampaignForCancellation,
        setCampaignType,
        setCreateCampaignType,
        setStatusFilter,
        setCampaignFormModalOpen,
        setUsersCampaignFormModalOpen,
        setAdminCampaignDetailModalOpen,
        setUserCampaignDetailModalOpen,
        setCampaign,
        setSelectedCampaign,
        setIsCancelModalOpen,
        setCancelReason,
        setSelectedCampaignForCancellation,
      }}
    >
      {children}
    </CampaignContext.Provider>
  );
};
