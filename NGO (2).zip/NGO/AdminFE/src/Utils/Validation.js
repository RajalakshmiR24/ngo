// Validation.js

const validateEmail = (email) => {
    const re = /^[^\s@]+([_.]?[^\s@]+)*@[^\s@]+\.[^\s@]+$/; // Allows underscore and dot in local part
    return re.test(String(email).toLowerCase());
};

const validateMobileNumber = (number) => {
    const re = /^\d{10}$/; // Ensures a 10-digit mobile number
    return re.test(String(number));
};

const validatePassword = (password) => {
    const re = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[\W_]).{8,}$/; // At least 8 characters, 1 letter, 1 number, 1 special character
    return re.test(password);
};

export const validateForm = (info) => {
    const errors = {};
    
    if (!validateEmail(info.email)) {
        errors.email = 'Invalid email address';
    }
    
    if (validateMobileNumber(info.mobilenumber)) {
        errors.mobilenumber = 'Mobile number must be 10 digits';
    }
    
    if (!validatePassword(info.password)) {
        errors.password = 'Password must be at least 8 characters long, with at least one letter, one number, and one special character';
    }
    
    return errors;
};

// validation.js

export const validateCampaignForm = (startDateStr, endDateStr, estimatedBudget) => {
    const today = new Date();
    const startDate = new Date(startDateStr);
    const endDate = new Date(endDateStr);

    // Start date must be at least one week from today
    const oneWeekFromNow = new Date();
    oneWeekFromNow.setDate(today.getDate() + 7);

    if (startDate < oneWeekFromNow) {
        return { isValid: false, message: "Start date must be at least one week from today." };
    }
    if (endDate <= startDate) {
        return { isValid: false, message: "End date must be after start date." };
    }
    if (startDate.toDateString() === endDate.toDateString()) {
        return { isValid: false, message: "Start and end dates should not be the same." };
    }
    if (estimatedBudget < 0) {
        return { isValid: false, message: "Estimated budget must be a non-negative value." };
    }

    return { isValid: true };
};
