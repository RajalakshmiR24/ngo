import React, { useEffect, useState } from "react";
import axiosInstance from "../../../../../Utils/axiosInstance";
import "./GeneralUserList.css";

const GeneralUserList = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedUser, setSelectedUser] = useState(null);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axiosInstance.get("/api/ngo/admin/alltransactions");
        const usersData = response.data?.data || [];
        if (usersData.length === 0) {
          setError("No transaction documents found");
          return;
        }

        const userMap = usersData.reduce((acc, user) => {
          const email = user.email;

          
          if (!acc[email]) {
            acc[email] = {
              ...user,
              campaign: user.campaign || [],
              pg_response: [],
            };
          }
          
          if (user.pg_response) {
            acc[email].pg_response.push({
              transactionid: user.pg_response.transactionid || "N/A",
              orderid: user.pg_response.orderid || "N/A",
              amount: user.amount || "N/A",
              bank_ref_no: user.pg_response.bank_ref_no || "N/A",
              transaction_error_desc: user.pg_response.transaction_error_desc || "N/A",
            });
          }

          return acc;
        }, {});

        setUsers(Object.values(userMap));
      } catch (err) {
        setError(err.message || "An error occurred while fetching users.");
      } finally {
        setLoading(false);
      }
    };

    fetchUsers();
  }, []);

  const handleAction = (userId) => {
    const user = users.find((u) => u.email === userId) || null;
    setSelectedUser(user);
  };

  const handleCampaignClick = async (campaign_id) => {
    try {
      const response = await axiosInstance.post("/api/ngo/admin/campaignbyid", {
        campId: campaign_id,
      });

      const result = response.data;

      if (result.code === 200) {
        const campaign = result.data[0].campaign;
        alert(`Campaign Title: ${campaign.campaign_title}`);
      } else {
        alert("No campaign found.");
      }
    } catch (error) {
      console.error("Error fetching campaign details:", error);
      alert("Error fetching campaign details.");
    }
  };

  const closeModal = () => setSelectedUser(null);

  if (loading) return <div>Loading...</div>;
  if (error) return (
    <div className="container">
      <h2 className="header">General User List</h2>
      <table className="user-table">
        <thead>
          <tr>
            <th className="table-header">S.No</th>
            <th className="table-header">Full Name</th>
            <th className="table-header">Mobile Number</th>
            <th className="table-header">No. of Campaigns</th>
            <th className="table-header">Total Amount</th>
            <th className="table-header">Action</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td colSpan="6" className="error-message">{error}</td>
          </tr>
        </tbody>
      </table>
    </div>
  );

  return (
    <div className="container">
      <h2 className="header">General User List</h2>
      <table className="user-table">
        <thead>
          <tr>
            <th className="table-header">S.No</th>
            <th className="table-header">Full Name</th>
            <th className="table-header">Mobile Number</th>
            <th className="table-header">No. of Campaigns</th>
            <th className="table-header">Total Amount</th>
            <th className="table-header">Action</th>
          </tr>
        </thead>
        <tbody>
          {users.length ? (
            users.map((user, index) => (
              <tr key={user.email}>
                <td className="table-data">{index + 1}</td>
                <td className="table-data">{user.name}</td>
                <td className="table-data">{user.mobilenumber}</td>
                <td className="table-data">{user.campaign.length || 0}</td>
                <td className="table-data">{user.amount}</td>
                <td className="table-data">
                  <button
                    className="action-button"
                    onClick={() => handleAction(user.email)}
                  >
                    View
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="6" className="no-users">No users found</td>
            </tr>
          )}
        </tbody>
      </table>
      <UserModal user={selectedUser} onClose={closeModal} handleCampaignClick={handleCampaignClick} />
    </div>
  );
};

const UserModal = ({ user, onClose, handleCampaignClick }) => {
  if (!user) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <h2 className="modal-header">User Details</h2>
        <table className="user-table">
          <tbody>
            <tr>
              <td className="table-data"><strong>Total Amount:</strong></td>
              <td className="table-data">{user.amount || "N/A"}</td>
            </tr>
            <tr>
              <td className="table-data"><strong>Number of Campaigns:</strong></td>
              <td className="table-data">{user.campaign.length || 0}</td>
            </tr>
            <tr>
              <td className="table-data"><strong>PG Status:</strong></td>
              <td className="table-data">{user.pgStatus}</td>
            </tr>
          </tbody>
        </table>

        <h3 className="pg-response-header">Payment Gateway Response</h3>
        <table className="user-table pg-response-table">
          <thead>
            <tr>
              <th className="table-header">Transaction ID</th>
              <th className="table-header">Order ID</th>
              <th className="table-header">Amount</th>
              <th className="table-header">Bank Reference No</th>
              <th className="table-header">Transaction Status</th>
            </tr>
          </thead>
          <tbody>
            {user.pg_response.length ? (
              user.pg_response.map((response, index) => (
                <tr key={index}>
                  <td>{response.transactionid}</td>
                  <td>{response.orderid}</td>
                  <td>{response.amount}</td>
                  <td>{response.bank_ref_no}</td>
                  <td>{response.transaction_error_desc}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5" className="no-transactions">No transaction details available</td>
              </tr>
            )}
          </tbody>
        </table>

        <button className="close-button" onClick={onClose}>Close</button>
      </div>
    </div>
  );
};

export default GeneralUserList;
