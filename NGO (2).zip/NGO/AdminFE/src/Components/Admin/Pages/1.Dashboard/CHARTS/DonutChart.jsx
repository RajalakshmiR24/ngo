import React, { useEffect, useState } from "react";
import { Doughnut } from "react-chartjs-2";
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
} from "chart.js";
import axiosInstance from "../../../../../Utils/axiosInstance";

ChartJS.register(ArcElement, Tooltip, Legend);

const DonutChart = () => {
  const [contribution, setContribution] = useState(0);
  const [pendingExpense, setPendingExpense] = useState(0);
  const [approvedExpense, setApprovedExpense] = useState(0);
  const email = localStorage.getItem("hash");

  const fetchDatas = () => {
    axiosInstance.get(`/api/ngo/admin/totalcontribution`, { email })
      .then((res) => {
        if (res.data.code === 200) {
          setContribution(res.data.data || 0);
        }
      })
      .catch((err) => {
        console.log(err, "error in fetching contribution data");
      });
  
    axiosInstance.get(`/api/ngo/admin/totalpendingexpense`, { email })
      .then((res) => {
        if (res.data.code === 200) {
          setPendingExpense(res.data.expense);
        }
      })
      .catch((err) => {
        console.log(err, "error in fetching pending expense data");
      });
  
    axiosInstance.get(`/api/ngo/admin/totalapprovedexpense`, { email })
      .then((res) => {
        if (res.data.code === 200) {
          setApprovedExpense(res.data.expense);
        }
      })
      .catch((err) => {
        console.log(err, "error in fetching approved expense data");
      });
  };
  
  useEffect(() => {
    fetchDatas();
  }, []);

  const totalData = [contribution, approvedExpense, pendingExpense];
  const isEmpty = totalData.every(value => value === 0);

  const donutChartData = {
    labels: ['Total Contribution', 'Approved Expense', 'Pending Expense'],
    datasets: [
      {
        label: 'Amount',
        data: isEmpty ? [1, 1, 1] : totalData,
        backgroundColor: [
          'rgba(255, 99, 132, 0.7)',
          'rgba(54, 162, 235, 0.7)',
          'rgba(255, 206, 86, 0.7)',
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
        ],
        borderWidth: 2,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
        labels: {
          font: {
            size: 14,
            weight: 'bold',
          },
        },
      },
      title: {
        display: true,
        text: isEmpty ? 'No Data Available' : 'Contribution and Expenses Overview',
        font: {
          size: 18,
          weight: 'bold',
        },
      },
      tooltip: {
        callbacks: {
          label: function (context) {
            let label = context.label || '';
            if (context.parsed !== null) {
              label += `: ${context.raw}`;
            }
            return label;
          }
        },
        backgroundColor: 'rgba(0, 0, 0, 0.7)',
      },
    },
  };

  return (
    <div
      style={{
        height: "100vh",
        width: "300px",
        margin: "0 auto",
        maxWidth: "800px",
        textAlign: 'center',
      }}
      className="donut_chart"
    >
      {isEmpty ? (
        <img 
          src="https://images.edrawsoft.com/articles/donut-chart/donut-chart-1.png" 
          alt="No Data Available" 
          style={{ width: '100%', height: 'auto' }} 
        />
      ) : (
        <Doughnut data={donutChartData} options={options} />
      )}
    </div>
  );
};

export default DonutChart;
