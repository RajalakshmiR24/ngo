import React, { useEffect, useState } from 'react';
import { Bar } from 'react-chartjs-2';
import axiosInstance from '../../../../../Utils/axiosInstance';
import { Chart as ChartJS, BarElement, CategoryScale, LinearScale, Title, Tooltip, Legend } from 'chart.js';

ChartJS.register(BarElement, CategoryScale, LinearScale, Title, Tooltip, Legend);

const Barchart = () => {
    const [chartData, setChartData] = useState({
        labels: [
            'Upcoming', 
            'Ongoing', 
            'Completed', 
            'Cancelled', 
            'Live', 
            'Rejected', 
            'Not Approved', 
            'Approved'
        ],
        datasets: [
            {
                label: 'Campaign Counts',
                data: [0, 0, 0, 0, 0, 0, 0, 0], // Initialize with zero counts
                backgroundColor: [
                    'rgba(75, 192, 192, 0.6)', // Upcoming
                    'rgba(255, 206, 86, 0.6)', // Ongoing
                    'rgba(54, 162, 235, 0.6)', // Completed
                    'rgba(255, 99, 132, 0.6)', // Cancelled
                    'rgba(153, 102, 255, 0.6)', // Live
                    'rgba(255, 159, 64, 0.6)', // Rejected
                    'rgba(255, 205, 86, 0.6)', // Not Approved
                    'rgba(75, 192, 192, 0.3)', // Approved
                ],
            },
        ],
    });

    const options = {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'Campaign Counts by Status',
            },
        },
    };

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axiosInstance.get('/api/ngo/admin/statuscount');
                
                const campaignCounts = response.data.data;

                // Extract counts based on the new response structure
                const salesData = [
                    campaignCounts.UPCOMING || 0,    // Upcoming
                    campaignCounts.ONGOING || 0,     // Ongoing
                    campaignCounts.COMPLETED || 0,   // Completed
                    campaignCounts.CANCELLED || 0,   // Cancelled
                    campaignCounts.LIVE || 0,        // Live
                    campaignCounts.REJECTED || 0,    // Rejected
                    campaignCounts.NOT_APPROVED || 0, // Not Approved
                    campaignCounts.APPROVED || 0      // Approved
                ];

                setChartData(prevData => ({
                    ...prevData,
                    datasets: [{
                        ...prevData.datasets[0],
                        data: salesData,
                    }],
                }));
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        fetchData();
    }, []);

    return (
        <div style={{ height: "50vh", width: "100%" }} className='bar_chart'>
            {/* <h2 style={{ textAlign: 'center' }}>Campaign Counts by Status</h2> */}
            <Bar data={chartData} options={options} />
        </div>
    );
};

export default Barchart;
