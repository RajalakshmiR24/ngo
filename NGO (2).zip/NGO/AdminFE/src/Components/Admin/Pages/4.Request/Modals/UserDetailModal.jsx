import React from 'react'

const UserDetailModal = ({ user, onClose, verifyreject }) => {
    if (!user) return null;

    return (
        <div className="modal user-modal">
          <div className="modal-content">
            <h2>User Details</h2>
            <div
              className="modal-background"
              style={{
                backgroundImage: `url(${user.id_proof})`,
              }}
            />
            <h3 className="modal-subtitle">User Information</h3>
            <p><strong>Full Name:</strong> {user.fullname}</p>
            <p><strong>Email:</strong> {user.email}</p>
            <p><strong>Current Address:</strong> {user.current_address}</p>
            <p><strong>Mobile Number:</strong> {user.mobile_number}</p>
            <p><strong>Account Created:</strong> {new Date(user.account_created_date).toLocaleDateString()}</p>
            <p><strong>Status:</strong> {user.status}</p>
            <button className="modal-button" onClick={() => verifyreject("ACTIVE")}>Verify</button>
            <button className="modal-button" onClick={() => verifyreject("REJECTED")}>Reject</button>
    
    
            <button className="modal-button" onClick={onClose}>Close</button>
          </div>
        </div>
      );
}

export default UserDetailModal


