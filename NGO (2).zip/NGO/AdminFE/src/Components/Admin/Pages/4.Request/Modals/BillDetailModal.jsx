import React ,{useState}from 'react';
import RejectModal from '../Modals/RejectModal'

const BillDetailModal = ({ bill, onClose, verifyreject }) => {
    const [showRejectModal, setShowRejectModal] = useState(false);
  const [reason, setReason] = useState('');

  const handleReject = (reason) => {
    verifyreject("REJECTED", reason);
    setReason('');
  };

  if (!bill) return null;

  return (
    <div className="modal bill-modal">
      <div className="modal-content">
        <div className="modal-container">
          <div className="modal-text-content">
            <h2>Bill Details</h2>
            <img className="bill-image" src={bill.bills} alt="bill" srcset="" />

            <p><strong>Email:</strong> {bill.user[0]?.email || "Unknown email"}</p>
            <p><strong>Campaign:</strong> {bill.campaign[0]?.campaign_title || "Unknown campaign"}</p>
            <p><strong>Claiming Amount:</strong> {bill.claiming_amount}</p>
            <p><strong>Status:</strong> {bill.status}</p>


            {/* Verify button */}
            <button className="modal-button" onClick={() => verifyreject("APPROVED")}>
              Verify
            </button>

            {/* Reject button to open the reject modal */}
            <button className="modal-button" onClick={() => setShowRejectModal(true)}>
              Reject
            </button>

            {/* Close button */}
            <button className="modal-button" onClick={onClose}>
              Close
            </button>
          </div>
        </div>
      </div>

      {/* Reject Modal */}
      <RejectModal
        isOpen={showRejectModal}
        onClose={() => setShowRejectModal(false)}
        onReject={handleReject}
        reason={reason}
        setReason={setReason}
      />
    </div>
  );
}

export default BillDetailModal
