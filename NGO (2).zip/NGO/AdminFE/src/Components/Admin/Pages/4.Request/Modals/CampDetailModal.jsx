import React from 'react'

const CampDetailModal = ({ camp, onClose, verifyreject }) => {
    if (!camp) return null;

    return (
      <div className="modal campaign-modal">
        <div className="modal-content">
          <div className="modal-container">
            <div className="modal-text-content">
              <h2>Campaign Details</h2>
              <p><strong>Title:</strong> {camp.campaign_title}</p>
              <p><strong>Type:</strong> {camp.campaign_type}</p>
              <p><strong>Description:</strong> {camp.campaign_description}</p>
              <p><strong>Start Date:</strong> {new Date(camp.campaign_start_date).toLocaleDateString()}</p>
              <p><strong>End Date:</strong> {new Date(camp.campaign_end_date).toLocaleDateString()}</p>
              <p><strong>Address:</strong> {camp.campaign_address}</p>
              <p><strong>Budget:</strong> {camp.estimated_budget}</p>
              <p><strong>Collected Amount:</strong> {camp.collected_amount}</p>
              <p><strong>Status:</strong> {camp.status}</p>
              <button className="modal-button" onClick={() => verifyreject("APPROVED")}>Verify</button>
              <button className="modal-button" onClick={() => verifyreject("REJECTED")}>Reject</button>
              <button className="modal-button" onClick={onClose}>Close</button>
            </div>
            <div className="modal-banner">
              <img src={camp.banner} alt="Campaign Banner" />
            </div>
          </div>
        </div>
      </div>
    );
}

export default CampDetailModal
