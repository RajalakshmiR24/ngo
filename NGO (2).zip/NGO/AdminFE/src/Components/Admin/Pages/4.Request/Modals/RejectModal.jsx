import React from 'react'

const RejectModal = ({ isOpen, onClose, onReject, reason, setReason }) => {
    const handleReject = () => {
        if (!reason) {
          return;
        }
        onReject(reason);
        setReason('');
        onClose();
      };
    
      if (!isOpen) return null;
    
      return (
        <div className="modal">
          <div className="modal-content">
            <h2>Reject Bill</h2>
            <label htmlFor="reason">Reason for Rejection:</label>
            <input
              type="text"
              id="reason"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Enter reason for rejection"
            />
            <button onClick={handleReject}>Submit</button>
            <button onClick={onClose}>Cancel</button>
          </div>
        </div>
      );
}

export default RejectModal
