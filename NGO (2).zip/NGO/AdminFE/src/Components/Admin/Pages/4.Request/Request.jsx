import React, { useEffect, useState } from "react";
import axiosInstance from "../../../../Utils/axiosInstance";
import { useRequests } from '../../../../Context/RequestsContext';
import UserDetailModal from './Modals/UserDetailModal';
import CampDetailModal from './Modals/CampDetailModal';
import BillDetailModal from './Modals/BillDetailModal';

import './Request.css';

const Requests = () => {
  const {
    users, setUsers,
    camp, setCamps,
    bills, setBills,
    loading, setLoading,
    error, setError,
    successMessage, setSuccessMessage,
    activeTab, setActiveTab,
    selectedCampaign, setSelectedCampaign,
    selectedUser, setSelectedUser,
    selectedBill, setSelectedBill,
  } = useRequests();
  const [reason, setReason] = useState('');


  useEffect(() => {
    const fetchData = async () => {
      try {
        const [usersResponse, campsResponse, billsResponse] = await Promise.all([
          axiosInstance.get("/api/ngo/admin/verifyuserdetails"),
          axiosInstance.get("/api/ngo/admin/campaignstatustoverify"),
          axiosInstance.get("/api/ngo/admin/verifybills"),
        ]);

        setUsers(usersResponse.data?.data || []);
        setCamps(campsResponse.data?.data || []);
        setBills(billsResponse.data?.data || []);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleUserAction = (userId) => {
    setSelectedUser(users.find((u) => u.email_hash === userId) || null);
  };

  const handleCampAction = (campId) => {
    setSelectedCampaign(camp.find((c) => c.campaign_id === campId) || null);
  };

  const handleBillsAction = (billId) => {
    setSelectedBill(bills.find((b) => b.billID === billId) || null);
  };


  const closeUserDetailModal = () => {
    setSelectedUser(null);
  };

  const closeCampaignDetailModal = () => {
    setSelectedCampaign(null);
  };

  const closeBillDetailModal = () => {
    setSelectedBill(null);
  };


  const handleUserApproval = async (status) => {
    console.log(selectedUser, '...........................');

    try {
      const response = await axiosInstance.post("/api/admin/rejectuser", {
        email: selectedUser.email_hash,
        status,
      });

      if (response.data.code === 200) {
        setSelectedUser(response.data.data);
        setSuccessMessage(response.data.message);
        setUsers((prevUsers) =>
          prevUsers.map((user) =>
            user.email === selectedUser.email
              ? { ...user, status: status === "ACTIVE" ? "ACTIVE" : "REJECTED" }
              : user
          )
        );
      } else {
        setError(response.data.message || "Failed to update user status");
      }
    } catch (error) {
      console.error("Error approving/rejecting user:", error);
      setError("Failed to update user status");
    } finally {
      setLoading(false);
      closeUserDetailModal();
    }
  };

  const handleCampaignApproval = async (status) => {
    setLoading(true);
    console.log(selectedCampaign, '...........................');

    try {
      const response = await axiosInstance.post("/api/admin/rejectcampreq", {
        campaign_id: selectedCampaign.campaign_id,
        status,
      });

      if (response.data.code === 200) {
        setSuccessMessage(response.data.message);
        setCamps((prevCamp) =>
          prevCamp.map((campaign) =>
            campaign.campaign_id === selectedCampaign.campaign_id
              ? {
                ...campaign,
                status: status === "APPROVED" ? "APPROVED" : "REJECTED",
              }
              : campaign
          )
        );
      } else {
        setError("Failed to update campaign status");
      }
    } catch (error) {
      console.error("Error approving/rejecting campaign:", error);
      setError("Failed to update campaign status");
    } finally {
      setLoading(false);
      closeCampaignDetailModal();
    }
  };

  const handleBillApproval = async (status, reason) => {
    if (!selectedBill) return;

    setLoading(true);
    try {

      const response = await axiosInstance.put("/api/admin/verifyrejectbills", {
        billID: selectedBill._id,
        status,
        reason: status === "REJECTED" ? reason : undefined,
      });


      if (response.data.code === 200) {
        setSuccessMessage(response.data.message);
        setBills((prevBills) =>
          prevBills.map((bill) =>
            bill.id === selectedBill.id
              ? {
                ...bill,
                status: status,
                reason_for_cancellation: status === "REJECTED" ? reason : undefined,
              }
              : bill
          )
        );
      } else {
        setError("Failed to update bill status");
      }
    } catch (error) {
      console.error("Error approving/rejecting bill:", error);
      setError("Failed to update bill status");
    } finally {
      setLoading(false);
      closeBillDetailModal();
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div className="dashboard-container">
      <h2 className="dashboard-title">Management</h2>
      {successMessage && (
        <div className="success-message">{successMessage}</div>
      )}
      <div className="select">
        <select onChange={(e) => setActiveTab(e.target.value)} value={activeTab}>
          <option value="all">All</option>
          <option value="users">Users</option>
          <option value="camp">Campaigns</option>
          <option value="bills">Bills</option>
        </select>
      </div>

      {activeTab === "all" && (
        <div className="all-section">
          <h2 className="section-title">All Data to Verify</h2>

          {/* Users Section */}
          <div className="users-section">
            <h3>Users to Verify</h3>
            <table className="table users-table">
              <thead className="table-header">
                <tr>
                  <th>S.No</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Mobile number</th>
                  <th>Created date</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody className="table-body">
                {users.length > 0 ? (
                  users.map((user, i) => (
                    <tr key={user.email_hash}>
                      <td>{i + 1}</td>
                      <td>{user.fullname}</td>
                      <td>{user.email}</td>
                      <td>{user.mobile_number}</td>
                      <td>{new Date(user.account_created_date).toLocaleDateString()}</td>
                      <td>{user.status}</td>
                      <td>
                        <button className="action-button" onClick={() => handleUserAction(user.email_hash)}>
                          View
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="7">No user data found</td>
                  </tr>
                )}
              </tbody>
            </table>
            <UserDetailModal user={selectedUser} onClose={closeUserDetailModal} verifyreject={handleUserApproval} />
          </div>

          {/* Campaigns Section */}
          <div className="campaigns-section">
            <h3>Campaigns to Verify</h3>
            <table className="table campaigns-table">
              <thead className="table-header">
                <tr>
                  <th>S.No</th>
                  <th>Campaign Name</th>
                  <th>Campaign Type</th>
                  <th>Campaign Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody className="table-body">
                {camp.length > 0 ? (
                  camp.map((campaign, i) => (
                    <tr key={campaign._id}>
                      <td>{i + 1}</td>
                      <td>{campaign.campaign_title}</td>
                      <td>{campaign.campaign_type}</td>
                      <td>{campaign.status}</td>
                      <td>
                        <button className="action-button" onClick={() => handleCampAction(campaign.campaign_id)}>
                          View
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="5">No campaign data found</td>
                  </tr>
                )}
              </tbody>
            </table>
            <CampDetailModal camp={selectedCampaign} onClose={closeCampaignDetailModal} verifyreject={handleCampaignApproval} />
          </div>

          {/* Bills Section */}
          <div className="bills-section">
            <h3>Bills to Verify</h3>
            <table className="table bills-table">
              <thead className="table-header">
                <tr>
                  <th>S.No</th>
                  <th>Email</th>
                  <th>Campaign Name</th>
                  <th>Bill Amount</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody className="table-body">
                {bills.length > 0 ? (
                  bills.map((bill, i) => (
                    <tr key={bill._id}>
                      <td>{i + 1}</td>
                      <td>{bill.user ? bill.user[0]?.email : "Unknown email"}</td>
                      <td>{bill.campaign ? bill.campaign[0]?.campaign_title : "Unknown campaign"}</td>
                      <td>{bill.claiming_amount}</td>
                      <td>{bill.status}</td>
                      <td>
                        <button className="action-button" onClick={() => handleBillsAction(bill.billID)}>
                          View
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="7">No bills available</td>
                  </tr>
                )}
              </tbody>
            </table>
            <BillDetailModal bill={selectedBill} onClose={closeBillDetailModal} verifyreject={handleBillApproval} reason={reason} setReason={setReason} />
          </div>
        </div>
      )}

      {activeTab === "users" && (
        <div className="users-section">
          <h2 className="section-title">Users to Verify</h2>
          <table className="table users-table">
            <thead className="table-header">
              <tr>
                <th>S.No</th>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile number</th>
                <th>Created date</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody className="table-body">
              {users.length > 0 ? (
                users.map((user, i) => (
                  <tr key={user.email_hash}>
                    <td>{i + 1}</td>
                    <td>{user.fullname}</td>
                    <td>{user.email}</td>
                    <td>{user.mobile_number}</td>
                    <td>{new Date(user.account_created_date).toLocaleDateString()}</td>
                    <td>{user.status}</td>
                    <td>
                      <button className="action-button" onClick={() => handleUserAction(user.email_hash)}>
                        View
                      </button>

                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="7">No user data found</td>
                </tr>
              )}
            </tbody>
          </table>
          <UserDetailModal user={selectedUser} onClose={closeUserDetailModal} verifyreject={handleUserApproval} />

        </div>
      )}

      {activeTab === "camp" && (
        <div className="campaigns-section">
          <h2 className="section-title">Campaigns to Verify</h2>
          <table className="table campaigns-table">
            <thead className="table-header">
              <tr>
                <th>S.No</th>
                <th>Campaign Name</th>
                <th>Campaign Type</th>
                <th>Campaign Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody className="table-body">
              {camp.length > 0 ? (
                camp.map((campaign, i) => (
                  <tr key={campaign._id}>
                    <td>{i + 1}</td>
                    <td>{campaign.campaign_title}</td>
                    <td>{campaign.campaign_type}</td>
                    <td>{campaign.status}</td>
                    <td>
                      <button className="action-button" onClick={() => handleCampAction(campaign.campaign_id)}>
                        View
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="5">No campaign data found</td>
                </tr>
              )}
            </tbody>
          </table>
          <CampDetailModal camp={selectedCampaign} onClose={closeCampaignDetailModal} verifyreject={handleCampaignApproval} />

        </div>
      )}

      {activeTab === "bills" && (
        <div className="bills-section">
          <h2 className="section-title">Bills to Verify</h2>
          <table className="table bills-table">
            <thead className="table-header">
              <tr>
                <th>S.No</th>
                <th>Email</th>
                <th>Campaign Name</th>
                <th>Bill Amount</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody className="table-body">
              {bills.length > 0 ? (
                bills.map((bill, i) => (
                  <tr key={bill._id}>
                    <td>{i + 1}</td>
                    <td>{bill.user ? bill.user[0]?.email : "Unknown email"}</td>
                    <td>{bill.campaign ? bill.campaign[0]?.campaign_title : "Unknown campaign"}</td>
                    <td>{bill.claiming_amount}</td>
                    <td>{bill.status}</td>
                    <td>
                      <button className="action-button" onClick={() => handleBillsAction(bill.billID)}>
                        View
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="7">No bills available</td>
                </tr>
              )}
            </tbody>
          </table>
          <BillDetailModal bill={selectedBill} onClose={closeBillDetailModal} verifyreject={handleBillApproval} reason={reason} setReason={setReason} />

        </div>
      )}
    </div>
  );
};

export default Requests;
