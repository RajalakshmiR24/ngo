import React, { useContext, useEffect } from "react";
import { CampaignContext } from "../../../../Context/CampaignContext";
import axiosInstance from "../../../../Utils/axiosInstance";
import "./Campaigns.css";

const Campaigns = () => {
  const {
    adminCampaigns,
    userCampaigns,
    loading,
    setAdminCampaigns,
    setUserCampaigns,
    setLoading,
    activeCampaignType,
    campaignType,
    createCampaignType,
    statusFilter,
    isCampaignFormModalOpen,
    isUserCampaignFormModalOpen,
    isAdminCampaignDetailModalOpen,
    isUserCampaignDetailModalOpen,
    campaign,
    selectedCampaign,
    isCancelModalOpen,
    cancelReason,
    selectedCampaignForCancellation,
    setCampaignType,
    setCreateCampaignType,
    setStatusFilter,
    setCampaignFormModalOpen,
    setUsersCampaignFormModalOpen,
    setAdminCampaignDetailModalOpen,
    setUserCampaignDetailModalOpen,
    setCampaign,
    setSelectedCampaign,
    setIsCancelModalOpen,
    setCancelReason,
    setSelectedCampaignForCancellation,
  } = useContext(CampaignContext);


  const openCampaignFormModal = () => setCampaignFormModalOpen(true);

  const closeCampaignFormModal = () => {
    setCampaignFormModalOpen(false);
    setCampaign({
      campaign_title: "",
      campaign_type: "",
      campaign_description: "",
      start_date: "",
      end_date: "",
      campaign_address: "",
      estimated_budget: "",
      collected_amount: "",
      banner: "",
    });
  };

  const openUsersCampaignFormModal = () => setUsersCampaignFormModalOpen(true);
  const closeUsersCampaignFormModal = () => {
    setUsersCampaignFormModalOpen(false);
    setCampaign({
      campaign_title: "",
      campaign_type: "",
      campaign_description: "",
      start_date: "",
      end_date: "",
      campaign_address: "",
      estimated_budget: "",
      collected_amount: "",
      banner: "",
      mobilenumber: "",
    });
  };

  const closeCampaignDetailModal = () => {
    setAdminCampaignDetailModalOpen(false);
    setUserCampaignDetailModalOpen(false);
    setSelectedCampaign(null);
  };

  useEffect(() => {
    const fetchCampaigns = async () => {
      setLoading(true);
      try {
        const endpoint =
          activeCampaignType === "user"
            ? "/api/ngo/admin/allusercampaigns"
            : "/api/ngo/admin/alladmincampaigns";

        const response = await axiosInstance.get(endpoint);

        const allCampaigns = response.data.data.map((item) => ({
          campaign_title: item.campaign_title,
          campaign_type: item.campaign_type,
          campaign_description: item.campaign_description,
          start_date: item.campaign_start_date,
          end_date: item.campaign_end_date,
          campaign_address: item.campaign_address,
          estimated_budget: item.estimated_budget,
          banner: item.banner || "default_banner.png", // Corrected this line
          collected_amount: item.collected_amount || 0,
          reason_for_cancellation: item.reason_for_cancellation,
          _id: item.campaign_id,
          user: item.user,
          status: item.status // Make sure to include the status field from the DB
        }));

        if (activeCampaignType === "user") {
          setUserCampaigns(allCampaigns);
          setAdminCampaigns([]);
        } else {
          setAdminCampaigns(allCampaigns);
          setUserCampaigns([]);
        }
      } catch (error) {
        console.error("Error fetching campaign data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchCampaigns();
  }, [activeCampaignType, setLoading, setUserCampaigns, setAdminCampaigns]);

  const filteredCampaigns = (campaigns) => {
    if (statusFilter === "all") return campaigns;
    return campaigns.filter(
      (campaign) => campaign.status.toLowerCase() === statusFilter
    );
  };


  const handleChange = (e) => {
    const { name, value } = e.target;
    setCampaign((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const convertIntoBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const fileReader = new FileReader();
      fileReader.readAsDataURL(file);
      fileReader.onload = () => {
        resolve(fileReader.result);
      };
      fileReader.onerror = (error) => {
        reject(error);
      };
    });
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (file) {
      const base64 = await convertIntoBase64(file);
      setCampaign((prevState) => ({
        ...prevState,
        banner: base64,
      }));
    }
  };

  const validateDates = (campaign) => {
    const today = new Date();
    const startDate = new Date(campaign.start_date);
    const endDate = new Date(campaign.end_date);

    // Start date must be at least one week from today
    const oneWeekFromNow = new Date(today);
    oneWeekFromNow.setDate(today.getDate() + 7);

    // Validate the date conditions
    if (startDate < oneWeekFromNow) {
      return false; // Start date must be at least one week from today
    }
    if (endDate <= startDate) {
      return false; // End date must be after start date
    }
    if (startDate.toDateString() === endDate.toDateString()) {
      return false; // Start and end dates should not be the same
    }

    return true; // All validations passed
  };





  const fetchAdminCampDetails = async (campaignId) => {
    setLoading(true);
    try {
      const response = await axiosInstance.post("/api/ngo/admin/getadmincampaignbyid", {
        campaign_id: campaignId,
      });

      setSelectedCampaign(response.data.data);
      setAdminCampaignDetailModalOpen(true);
    } catch (error) {
      console.error("Error fetching campaign details:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchUserCampDetails = async (campaignId) => {
    setLoading(true);
    try {
      const response = await axiosInstance.post("/api/ngo/admin/getusercampaigns", {
        campaign_id: campaignId,
      });
      setSelectedCampaign(response.data.data[0]);
      setUserCampaignDetailModalOpen(true);
    } catch (error) {
      console.error("Error fetching campaign details:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleCancelCampaign = async () => {
    try {
      const response = await axiosInstance.post("/api/ngo/admin/campaigncancel", {
        campaign_id: selectedCampaignForCancellation,
        cancel_reason: cancelReason,
      });

      if (response.data.code === 200) {
        // Handle success (e.g., refresh campaign list, show success message)
        alert(response.data.message);
      } else {
        // Handle error (e.g., show error message)
        alert(response.data.message);
      }
    } catch (error) {
      // Handle error from the API or network
      alert(
        "An error occurred: " + (error.response?.data?.message || error.message)
      );
    } finally {
      setIsCancelModalOpen(false);
      setCancelReason(""); // Reset the reason input
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const emailHash = localStorage.getItem("hash");
    if (!validateDates(campaign)) {
      alert("Start date must be at least one week from today.End date must be after start date.Start and end dates should not be the same. ");
      return;
    }
    if (campaign.estimated_budget < 0) {
      alert("Estimated budget must be a non-negative value.");
      return;
    }


    const campaignData = {
      title: campaign.campaign_title,
      type: campaign.campaign_type,
      description: campaign.campaign_description,
      start_date: campaign.start_date,
      end_date: campaign.end_date,
      banner: campaign.banner || "default_banner.png",
      admin_email: emailHash,
      address: campaign.campaign_address,
      budget: campaign.estimated_budget,
    };


    try {
      const response = await axiosInstance.post(
        "/api/ngo/admin/savecampaigndata",
        campaignData
      );

      if (response.data.code === 200) {
        setAdminCampaigns((prev) => [
          ...prev,
          { ...campaign, _id: Date.now() },
        ]);
        closeCampaignFormModal();
        console.log("Campaign created successfully");
      } else {
        console.error("Error:", response.data.message);
      }
    } catch (error) {
      console.error("Error submitting campaign data:", error.message);
    }
  };

  const handleSubmitUserCampaign = async (e) => {
    e.preventDefault();
    const emailHash = localStorage.getItem("hash");
  
    if (!validateDates(campaign)) {
      alert("Start date must be at least one week from today. End date must be after start date. Start and end dates should not be the same.");
      return;
    }
  
    if (campaign.estimated_budget < 0) {
      alert("Estimated budget must be a non-negative value.");
      return;
    }
  
    const campaignData = {
      title: campaign.campaign_title,
      type: campaign.campaign_type,
      description: campaign.campaign_description,
      start_date: campaign.start_date,
      end_date: campaign.end_date,
      banner: campaign.banner || "default_banner.png",
      address: campaign.campaign_address,
      budget: campaign.estimated_budget,
      mobilenumber: campaign.mobilenumber,
    };
  
    try {
      const response = await axiosInstance.post(
        "/api/ngo/admin/campaignforuser",
        campaignData
      );
  
      if (response.data.code === 200) {
        // Handle success (e.g., refresh user campaign list, show success message)
        alert("User campaign created successfully");
        closeUsersCampaignFormModal(false);
      } else {
        alert("Error: " + response.data.message); // Show alert with error message
      }
    } catch (error) {
      alert("Error submitting user campaign data: " + error.message); // Show alert with error message
    }
  };
  

  const handleSelectChange = (e) => {
    setCampaignType(e.target.value);
  }

  const handleStatusChange = (e) => {
    setStatusFilter(e.target.value);
  }

  const handleSelectChangeForm = (event) => {
    setCreateCampaignType(event.target.value);
  };

  const handleCreateCampaign = () => {
    if (createCampaignType === 'admin') {
      openCampaignFormModal();
    } else {
      openUsersCampaignFormModal();
    }
  };
  return (
    <div className="camp">
      <h1 className="camp-title">Campaigns</h1>

      <select
        id="campaign-type"
        value={campaignType}
        onChange={handleSelectChange}
      >
        <option value="admin">Admin Campaign</option>
        <option value="user">User Campaign</option>
      </select>

      {campaignType === "admin" && (
        <>
          {createCampaignType === "admin" && isCampaignFormModalOpen && (
            <div className="modal modal-form">
              <div className="modal-content">
                <form className="campaign-form" onSubmit={handleSubmit} val>
                  <h2 className="form-title">Admin Campaign Form</h2>
                  {[
                    {
                      name: "campaign_title",
                      type: "text",
                      placeholder: "Campaign Title",
                    },
                    {
                      name: "campaign_type",
                      type: "text",
                      placeholder: "Campaign Type",
                    },
                    {
                      name: "campaign_description",
                      type: "textarea",
                      placeholder: "Description",
                    },
                    {
                      name: "campaign_address",
                      type: "text",
                      placeholder: "Address",
                    },
                    {
                      name: "estimated_budget",
                      type: "number",
                      placeholder: "Estimated Budget",
                    },
                  ].map(({ name, type, placeholder }) =>
                    type === "textarea" ? (
                      <textarea
                        key={name}
                        className={`textarea-field ${name}-input`}
                        name={name}
                        value={campaign[name]}
                        onChange={handleChange}
                        placeholder={placeholder}
                      />
                    ) : (
                      <input
                        key={name}
                        className={`input-field ${name}-input`}
                        type={type}
                        name={name}
                        value={campaign[name]}
                        onChange={handleChange}
                        placeholder={placeholder}
                      />
                    )
                  )}
                  {["start_date", "end_date"].map((name) => (
                    <input
                      key={name}
                      className={`input-field ${name}-input`}
                      type="date"
                      name={name}
                      value={campaign[name]}
                      onChange={handleChange}
                    />
                  ))}
                  <input
                    className="input-field file-input"
                    type="file"
                    name="bannerimage"
                    onChange={handleFileUpload}
                  />
                  <button className="submit-button" type="submit">
                    Submit Campaign
                  </button>
                  <button
                    className="close-button"
                    type="button"
                    onClick={closeCampaignFormModal}
                  >
                    Close
                  </button>
                </form>
              </div>
            </div>
          )}
          {createCampaignType === "user" && isUserCampaignFormModalOpen && (
            <div className="modal modal-form">
              <div className="modal-content">
                <form
                  className="campaign-form"
                  onSubmit={handleSubmitUserCampaign}
                >
                  <h2 className="form-title">User Campaign Form</h2>
                  {[
                    {
                      name: "campaign_title",
                      type: "text",
                      placeholder: "Campaign Title",
                      required: true,
                    },
                    {
                      name: "campaign_type",
                      type: "text",
                      placeholder: "Campaign Type",
                      required: true,
                    },
                    {
                      name: "campaign_description",
                      type: "textarea",
                      placeholder: "Description",
                      required: true,
                    },
                    {
                      name: "campaign_address",
                      type: "text",
                      placeholder: "Address",
                      required: true,
                    },
                    {
                      name: "estimated_budget",
                      type: "number",
                      placeholder: "Estimated Budget",
                      required: true,
                    },
                    {
                      name: "mobilenumber",
                      type: "text",
                      placeholder: "User Mobile Number",
                      required: true,
                    },
                    { name: "start_date", type: "date", required: true },
                    { name: "end_date", type: "date", required: true },
                    { name: "banner", type: "file", required: true },
                  ].map(({ name, type, placeholder, required }) =>
                    type === "textarea" ? (
                      <textarea
                        key={name}
                        className={`textarea-field ${name}-input`}
                        name={name}
                        value={campaign[name]}
                        onChange={handleChange}
                        placeholder={placeholder}
                        required={required}
                      />
                    ) : type === "file" ? (
                      <input
                        key={name}
                        className={`input-field ${name}-input`}
                        type={type}
                        name={name}
                        onChange={handleFileUpload} // Handle file upload separately
                        required={required}
                      />
                    ) : (
                      <input
                        key={name}
                        className={`input-field ${name}-input`}
                        type={type}
                        name={name}
                        value={campaign[name]}
                        onChange={handleChange}
                        placeholder={placeholder}
                        required={required}
                      />
                    )
                  )}
                  <button className="submit-button" type="submit">
                    Create Campaign
                  </button>
                  <button
                    className="close-button"
                    type="button"
                    onClick={closeUsersCampaignFormModal}
                  >
                    Close
                  </button>
                </form>
              </div>
            </div>
          )}

          {isAdminCampaignDetailModalOpen && selectedCampaign && (
            <div className="modal modal-details">
              <div className="modal-content">
                <div className="modal-container">
                  <div className="modal-text-content">
                    <h2 className="details-title">Campaign Details</h2>
                    <img
                      className="banner-image"
                      src={selectedCampaign.banner}
                      alt="Campaign Banner"
                    />

                    <p className="detail-item">
                      <strong>Title:</strong> {selectedCampaign.campaign_title}
                    </p>

                    <p className="detail-item">
                      <strong>Type:</strong> {selectedCampaign.campaign_type}
                    </p>

                    <p className="detail-item">
                      <strong>Description:</strong>{" "}
                      {selectedCampaign.campaign_description}
                    </p>

                    <p className="detail-item">
                      <strong>Start Date:</strong>{" "}
                      {new Date(
                        selectedCampaign.campaign_start_date
                      ).toLocaleDateString()}
                    </p>

                    <p className="detail-item">
                      <strong>End Date:</strong>{" "}
                      {new Date(
                        selectedCampaign.campaign_end_date
                      ).toLocaleDateString()}
                    </p>

                    <p className="detail-item">
                      <strong>Address:</strong>{" "}
                      {selectedCampaign.campaign_address}
                    </p>

                    <p className="detail-item">
                      <strong>Budget:</strong>{" "}
                      {selectedCampaign.estimated_budget}
                    </p>

                    <p className="detail-item">
                      <strong>Collected Amount:</strong>{" "}
                      {selectedCampaign.collected_amount}
                    </p>

                    <button
                      className="close-button"
                      onClick={closeCampaignDetailModal}
                    >
                      Close
                    </button>
                  </div>


                </div>
              </div>
            </div>
          )}

          <section className="admin-campaign-overview">
            <h3 className="overview-title">Admin Campaign Overview</h3>


              <select id="select" value={statusFilter} onChange={handleStatusChange}>
                <option value="all"> All</option>
                <option value="upcoming"> Upcoming</option>
                <option value="ongoing"> Ongoing</option>

                <option value="live"> Live</option>
                <option value="completed"> Completed</option>

              </select>

              <select
                id="campaign-type"
                value={createCampaignType}
                onChange={handleSelectChangeForm}
              >
                <option value="admin" onClick={handleCreateCampaign} >Admin Campaign</option>
                <option value="user" onClick={handleCreateCampaign}        >User Campaign</option>
              </select>

              <button
                className="create-campaign-button"
                onClick={handleCreateCampaign}
              >
                {createCampaignType}
              </button>




            {loading ? (
              <p className="loading-message">Loading...</p>
            ) : (
              <table className="campaign-table">
                <thead>
                  <tr>
                    <th className="table-header">S.No</th>
                    <th className="table-header">Campaign Title</th>
                    <th className="table-header">Campaign Type</th>
                    <th className="table-header">Estimated Budget</th>
                    <th className="table-header">Collected Amount</th>
                    <th className="table-header">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredCampaigns(adminCampaigns).map((campaign, index) => (
                    <tr key={campaign._id}>
                      <td className="table-data">{index + 1}</td>
                      <td className="table-data">{campaign.campaign_title}</td>
                      <td className="table-data">{campaign.campaign_type}</td>
                      <td className="table-data">{campaign.estimated_budget}</td>
                      <td className="table-data">{campaign.collected_amount}</td>


                      <td className="table-action">
                        <button
                          className="view-button"
                          onClick={() => fetchAdminCampDetails(campaign._id)}
                        >
                          View
                        </button>



                        {/* CANCELLED Button Logic */}
                        {campaign.status === "CANCELLED" ? (
                          <button className="canceled-button" disabled>
                            Cancelled
                          </button>
                        ) : (
                          statusFilter !== "all" &&
                          statusFilter !== "completed" && (
                            <button
                              className="cancel-button"
                              onClick={() => {
                                setSelectedCampaignForCancellation(campaign._id);
                                setIsCancelModalOpen(true);
                              }}
                            >
                              Cancel
                            </button>
                          )
                        )}
                      </td>
                    </tr>
                  ))}

                </tbody>
              </table>
            )}
          </section>
        </>
      )}

      {campaignType === "user" && (
        <section className="user-campaign-overview">


          {/* Campaign Detail Modal */}
          {isUserCampaignDetailModalOpen && selectedCampaign && (
            <div className="modal modal-details">
              <div className="modal-content">
                <div className="modal-container">
                  <div className="modal-text-content">
                    <h2 className="details-title">Campaign Details</h2>

                    <p className="detail-item">
                      <strong>Title:</strong> {selectedCampaign.campaign_title}
                    </p>

                    <p className="detail-item">
                      <strong>Type:</strong> {selectedCampaign.campaign_type}
                    </p>

                    <p className="detail-item">
                      <strong>Description:</strong>{" "}
                      {selectedCampaign.campaign_description}
                    </p>

                    <p className="detail-item">
                      <strong>Start Date:</strong>{" "}
                      {new Date(
                        selectedCampaign.campaign_start_date
                      ).toLocaleDateString()}
                    </p>

                    <p className="detail-item">
                      <strong>End Date:</strong>{" "}
                      {new Date(
                        selectedCampaign.campaign_end_date
                      ).toLocaleDateString()}
                    </p>

                    <p className="detail-item">
                      <strong>Address:</strong>{" "}
                      {selectedCampaign.campaign_address}
                    </p>

                    <p className="detail-item">
                      <strong>Budget:</strong>{" "}
                      {selectedCampaign.estimated_budget}
                    </p>

                    <p className="detail-item">
                      <strong>Collected Amount:</strong>{" "}
                      {selectedCampaign.collected_amount}
                    </p>

                    <p className="detail-item">
                      <strong>Status:</strong> {selectedCampaign.status}
                    </p>

                    <button
                      className="close-button"
                      onClick={closeCampaignDetailModal}
                    >
                      Close
                    </button>
                  </div>

                  <div className="modal-banner">
                    <img
                      className="banner-image"
                      src={selectedCampaign.banner}
                      alt="Campaign Banner"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          <h2 className="overview-title">User Campaign Overview</h2>

          <div className="status-buttons">

            <select id="select" value={statusFilter} onChange={handleStatusChange}>
              <option value="all"> All</option>
              <option value="upcoming"> Upcoming</option>
              <option value="ongoing"> Ongoing</option>

              <option value="live"> Live</option>
              <option value="completed"> Completed</option>

            </select>

          </div>


          {loading ? (
            <p className="loading-message">Loading...</p>
          ) : (
            <table className="campaign-table">
              <thead>
                <tr>
                  <th className="table-header">S.No</th>
                  <th className="table-header">Campaign Title</th>
                  <th className="table-header">Campaign Type</th>
                  <th className="table-header">Estimated Budget</th>
                  <th className="table-header">Collected Amount</th>
                  {/* <th className="table-header">Status</th> */}
                  <th className="table-header">Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredCampaigns(userCampaigns).map((campaign, index) => (
                  <tr key={campaign._id}>
                    <td className="table-data">{index + 1}</td>
                    <td className="table-data">{campaign.campaign_title}</td>
                    <td className="table-data">{campaign.campaign_type}</td>
                    <td className="table-data">{campaign.estimated_budget}</td>
                    <td className="table-data">{campaign.collected_amount}</td>

                    <td className="table-action">
                      <div className="view-cancel-btn">
                        {/* View Button */}
                        <button
                          className="view-button"
                          onClick={() => fetchUserCampDetails(campaign._id)}
                        >
                          View
                        </button>

                        {/* Claim Button (show only in completed filter)
        {statusFilter === "completed" && (
          <button className="claim-button">
            Claim
          </button>
        )} */}

                        {/* Canceled Button Logic */}
                        {campaign.status === "CANCELLED" ? (
                          <button className="canceled-button" disabled>
                            Cancelled
                          </button>
                        ) : (
                          // Show Cancel button only if it's not in "all" or "completed" filter
                          statusFilter !== "all" &&
                          statusFilter !== "completed" && (
                            <button
                              className="cancel-button"
                              onClick={() => {
                                setSelectedCampaignForCancellation(campaign._id, campaign.reason_for_cancellation);
                                setIsCancelModalOpen(true);
                              }}
                            >
                              Cancel
                            </button>
                          )
                        )}
                      </div>
                    </td>
                  </tr>
                ))}

              </tbody>
            </table>
          )}
        </section>
      )}

      {isCancelModalOpen && (
        <div className="modal modal-cancel">
          <div className="modal-content">
            <h2 className="modal-title">Cancel Campaign</h2>
            <textarea
              className="textarea-field cancel-reason-input"
              value={cancelReason}
              onChange={(e) => setCancelReason(e.target.value)}
              placeholder="Enter reason for cancellation"
            />
            <button className="submit-button" onClick={handleCancelCampaign}>
              Submit Cancellation
            </button>
            <button
              className="close-button"
              onClick={() => setIsCancelModalOpen(false)}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Campaigns;
