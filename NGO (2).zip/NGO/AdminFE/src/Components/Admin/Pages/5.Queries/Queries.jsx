import React, { useEffect, useState } from "react";
import axiosInstance from "../../../../Utils/axiosInstance";
import "./Queries.css";

const Queries = () => {
  const [queries, setQueries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchQueries = async () => {
      try {
        const response = await axiosInstance.get("/api/ngo/admin/allqueries");
        console.log(response.data);

        if (Array.isArray(response.data.data)) {
          setQueries(response.data.data);
        } else {
          setError("Unexpected response format");
        }
      } catch (err) {
        setError("Error fetching queries");
      } finally {
        setLoading(false);
      }
    };

    fetchQueries();
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;

  return (
    <div className="queries-container">
      <h1 className="queries-title">Queries</h1>
      <table className="queries-table">
        <thead className="queries-thead">
          <tr className="queries-header-row">
            <th className="queries-header">Name</th>
            <th className="queries-header">Email</th>{" "}
            {/* Changed from Mobile Number to Email */}
            <th className="queries-header">Message</th>
          </tr>
        </thead>
        <tbody className="queries-tbody">
          {queries.map((query) => (
            <tr key={query.name} className="queries-row">
              {" "}
              {/* Use name as the key */}
              <td className="queries-cell">{query.name}</td>
              <td className="queries-cell">
                {query.email ? query.email : "No email provided"}
              </td>{" "}
              {/* Changed to query.email */}
              <td className="queries-cell">{query.message}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Queries;
