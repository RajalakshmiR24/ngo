const dotenv = require("dotenv");
dotenv.config();
const express = require("express");
const connectDB = require("./Database/Db");
const cors = require("cors");
const ngoRouter = require("./Routes/ngoRoutes");
const bodyParser = require("body-parser");
const app = express();

app.use(express.json({ limit: "10mb" }));
app.use(cors({
    origin: 'http://localhost:3000',
    allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.urlencoded({ extended: true }));

const PORT = process.env.PORT || 5000;

// Use the new ngoRouter
app.use("/api/ngo/user", ngoRouter);

connectDB().then(() => {
    const server = app.listen(PORT, () => {
        console.log(`Listening on port ${PORT}`);
    });

    server.on("request", (req, res) => {
        console.log(`${req.method}-----${req.url}`);
    });

}).catch((err) => {
    console.log(err);
});
