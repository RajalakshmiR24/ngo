const mongoose = require("mongoose");
const crypto = require("crypto");
const { v4: uuidv4 } = require('uuid');

const campaignSchema = new mongoose.Schema({
    campaign_id: { type: String, default: uuidv4, unique: true },
    campaign_title: { type: String },
    campaign_type: { type: String },
    campaign_description: { type: String },
    campaign_start_date: { type: Date },
    campaign_end_date: { type: Date },
    banner: { type: String },
    campaign_address: { type: String },
    estimated_budget: { type: Number, default: 0 },
    collected_amount: { type: Number, default: 0 },
    user: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    }],
    admin: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: "Admin"
    }],
    bills: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Bills' }],
    transactions: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Transaction' }],

    user_email: { type: String },
    admin_email: { type: String },
    status: {
        type: String,
        enum: ['LIVE', 'COMPLETED','ONGOING', 'CANCELLED', 'UPCOMING', 'NOT_APPROVED', 'APPROVED'],
        default: 'NOT_APPROVED'
    },
    reason_for_cancellation: { type: String, default: "NA" }
}, { timestamps: true });

// You might want to consider removing the hashing of _id.
// campaignSchema.pre("save", async function (next) {
//     if (!this.isModified("campaign_address")) {
//         return next();
//     }
//     try {
//         const hash = crypto.createHash('sha256');
//         hash.update(this._id);
//         const hashedData = hash.digest('hex');
//         this._id = hashedData;
//         next();
//     } catch (error) {
//         console.log("error in saving emailhash", error);
//         next(error); // Propagate the error
//     }
// });

const Campaign = mongoose.model("Campaign", campaignSchema);

module.exports = { Campaign, campaignSchema };
