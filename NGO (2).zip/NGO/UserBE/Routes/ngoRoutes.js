
const express = require('express');
const adminRouter = require('./adminroutes');
const userRouter = require('./userroutes');
const { transactionRouter } = require('./transactionroutes');
const router = express.Router();


router.use('/user', userRouter);
router.use('/transaction', transactionRouter);
router.use('/general', adminRouter); 

module.exports = router;
