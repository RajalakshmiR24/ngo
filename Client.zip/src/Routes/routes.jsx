import { createBrowserRouter, Navigate } from "react-router-dom";
import { Suspense, lazy } from "react";

// ProtectedRoute
import ProtectedRoute from "./ProtectedRoute";
import PublicRoute from "./PublicRoute";
// Lazy load Admin Components
const AdminLayout = lazy(() =>
  import("../Components/Admin/Layout/AdminLayout")
);
const AdminDashboard = lazy(() =>
  import("../Components/Admin/Pages/1.Dashboard/Dashboard")
);
const RegisteredUserList = lazy(() =>
  import(
    "../Components/Admin/Pages/3.UserManagement/2.Registered/List/RegisteredUserList"
  )
);
const GeneralUserList = lazy(() =>
  import(
    "../Components/Admin/Pages/3.UserManagement/3.General/List/GeneralUserList"
  )
);
const Request = lazy(() =>
  import("../Components/Admin/Pages/4.Request/Request")
);
const Queries = lazy(() =>
  import("../Components/Admin/Pages/5.Queries/Queries")
);
const AdminSignIn = lazy(() => import("../Components/Admin/auth/AdminSignIn"));
const Campaigns = lazy(() =>
  import("../Components/Admin/Pages/2.Campaigns/Campaigns")
);
const NotFound = lazy(() =>
  import("../Components/Admin/Common/NotFound/notFound")
);

const Loading = () => <div>Loading...</div>;

const adminRoutes = [
  { index: true, element: <AdminDashboard /> },
  { path: "campaigns", element: <Campaigns /> },
  { path: "registered-users", element: <RegisteredUserList /> },
  { path: "general-users", element: <GeneralUserList /> },
  { path: "requests", element: <Request /> },
  { path: "queries", element: <Queries /> },
];

export const router = createBrowserRouter([
  {
    path: "/",
    element: <PublicRoute element={<Navigate to="/admin/signin" />} />,
  },
  {
    path: "/admin",
    element: (
      <Suspense fallback={<Loading />}>
        <ProtectedRoute>
          <AdminLayout />
        </ProtectedRoute>
      </Suspense>
    ),
    children: adminRoutes.map((route) => ({
      ...route,
      element: <Suspense fallback={<Loading />}>{route.element}</Suspense>,
    })),
  },
  {
    path: "/admin/signin",
    element: (
      <Suspense fallback={<Loading />}>
        <PublicRoute element={<AdminSignIn />} />,
      </Suspense>
    ),
  },
  {
    path: "*",
    element: (
      <Suspense fallback={<Loading />}>
        <NotFound />
      </Suspense>
    ),
  },
]);
