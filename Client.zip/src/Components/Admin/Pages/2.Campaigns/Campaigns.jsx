import React, { useContext, useEffect, useState } from "react";
import { CampaignContext } from "../../../../Context/CampaignContext";
import axiosInstance from "../../../../Utils/axiosInstance";
import "./Campaigns.css";

const Campaigns = () => {
  const {
    adminCampaigns,
    userCampaigns,
    loading,
    setAdminCampaigns,
    setUserCampaigns,
    setLoading,
    handleToggleCampaignType,
    activeCampaignType,
  } = useContext(CampaignContext);

  const [statusFilter, setStatusFilter] = useState("all");
  const [isCampaignFormModalOpen, setCampaignFormModalOpen] = useState(false);
  const [isUserCampaignFormModalOpen, setUsersCampaignFormModalOpen] = useState(false)
  const [isAdminCampaignDetailModalOpen, setAdminCampaignDetailModalOpen] =
    useState(false);
  const [isUserCampaignDetailModalOpen, setUserCampaignDetailModalOpen] =
    useState(false);
  const [campaign, setCampaign] = useState({
    campaign_title: "",
    campaign_type: "",
    campaign_description: "",
    start_date: "",
    end_date: "",
    campaign_address: "",
    estimated_budget: "",
    collected_amount: "",
    banner: "",
    mobilenumber: "",

  });
  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const [isCancelModalOpen, setIsCancelModalOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState("");
  const [selectedCampaignForCancellation, setSelectedCampaignForCancellation] = useState(null);
  


  const openCampaignFormModal = () => setCampaignFormModalOpen(true);

  const closeCampaignFormModal = () => {
    setCampaignFormModalOpen(false);
    setCampaign({
      campaign_title: "",
      campaign_type: "",
      campaign_description: "",
      start_date: "",
      end_date: "",
      campaign_address: "",
      estimated_budget: "",
      collected_amount: "",
      banner: "",
    });
  };

  const openUsersCampaignFormModal = () => setUsersCampaignFormModalOpen(true);
  const closeUsersCampaignFormModal = () => {
    setUsersCampaignFormModalOpen(false);
    setCampaign({
      campaign_title: "",
      campaign_type: "",
      campaign_description: "",
      start_date: "",
      end_date: "",
      campaign_address: "",
      estimated_budget: "",
      collected_amount: "",
      banner: "",
      mobilenumber: "",
    });
  };




  const closeCampaignDetailModal = () => {
    setAdminCampaignDetailModalOpen(false);
    setUserCampaignDetailModalOpen(false);
    setSelectedCampaign(null);
  };

  useEffect(() => {
    const fetchCampaigns = async () => {
      setLoading(true);
      try {
        const endpoint =
          activeCampaignType === "user"
            ? "/admin/allusercampaigns"
            : "/admin/alladmincampaigns";

        const response = await axiosInstance.get(endpoint);

        const allCampaigns = response.data.data.map((item) => ({
          campaign_title: item.campaign_title,
          campaign_type: item.campaign_type,
          campaign_description: item.campaign_description,
          start_date: item.campaign_start_date,
          end_date: item.campaign_end_date,
          campaign_address: item.campaign_address,
          estimated_budget: item.estimated_budget,
          banner: campaign.banner || "default_banner.png",
          collected_amount: item.collected_amount || 0,
          reason_for_cancellation: item.reason_for_cancellation,
          _id: item.campaign_id,
          user: item.user,
        }));

        if (activeCampaignType === "user") {
          setUserCampaigns(allCampaigns);
          setAdminCampaigns([]);
        } else {
          setAdminCampaigns(allCampaigns);
          setUserCampaigns([]);
        }
      } catch (error) {
        console.error("Error fetching campaign data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchCampaigns();
  }, [activeCampaignType, setLoading, setUserCampaigns, setAdminCampaigns]);

  const getCampaignStatus = (startDate, endDate) => {
    const now = new Date();
    const start = new Date(startDate);
    const end = new Date(endDate);

    if (now < start) return "Upcoming";
    if (now >= start && now <= end) return "Live";
    return "Completed";
  };

  const filteredCampaigns = (campaigns) => {
    if (statusFilter === "all") return campaigns;
    return campaigns.filter(
      (campaign) =>
        getCampaignStatus(
          campaign.start_date,
          campaign.end_date
        ).toLowerCase() === statusFilter
    );
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCampaign((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const convertIntoBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const fileReader = new FileReader();
      fileReader.readAsDataURL(file);
      fileReader.onload = () => {
        resolve(fileReader.result);
      };
      fileReader.onerror = (error) => {
        reject(error);
      };
    });
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (file) {
      const base64 = await convertIntoBase64(file);
      setCampaign((prevState) => ({
        ...prevState,
        banner: base64,
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const emailHash = localStorage.getItem("hash");

    const campaignData = {
      title: campaign.campaign_title,
      type: campaign.campaign_type,
      description: campaign.campaign_description,
      start_date: campaign.start_date,
      end_date: campaign.end_date,
      banner: campaign.banner || "default_banner.png",
      admin_email: emailHash,
      address: campaign.campaign_address,
      budget: campaign.estimated_budget,
    };

    try {
      const response = await axiosInstance.post(
        "/admin/savecampaigndata",
        campaignData
      );

      if (response.data.code === 200) {
        setAdminCampaigns((prev) => [
          ...prev,
          { ...campaign, _id: Date.now() },
        ]);
        closeCampaignFormModal();
        console.log("Campaign created successfully");
      } else {
        console.error("Error:", response.data.message);
      }
    } catch (error) {
      console.error("Error submitting campaign data:", error.message);
    }
  };

  const fetchAdminCampDetails = async (campaignId) => {
    setLoading(true);
    try {
      const response = await axiosInstance.post("/admin/getadmincampaignbyid", {
        campaign_id: campaignId,
      });
      setSelectedCampaign(response.data.data);
      setAdminCampaignDetailModalOpen(true);
    } catch (error) {
      console.error("Error fetching campaign details:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchUserCampDetails = async (campaignId) => {
    setLoading(true);
    try {
      const response = await axiosInstance.post("/admin/getusercampaigns", {
        campaign_id: campaignId,
      });
      setSelectedCampaign(response.data.data[0]);
      setUserCampaignDetailModalOpen(true);
    } catch (error) {
      console.error("Error fetching campaign details:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleCancelCampaign = async () => {
    try {
      const response = await axiosInstance.post('/admin/campaigncancel', {
        campaign_id: selectedCampaignForCancellation,
        cancel_reason: cancelReason,
      });

      if (response.data.code === 200) {
        // Handle success (e.g., refresh campaign list, show success message)
        alert(response.data.message);
      } else {
        // Handle error (e.g., show error message)
        alert(response.data.message);
      }
    } catch (error) {
      // Handle error from the API or network
      alert('An error occurred: ' + (error.response?.data?.message || error.message));
    } finally {
      setIsCancelModalOpen(false);
      setCancelReason(""); // Reset the reason input
    }
  };

  const handleSubmitUserCampaign = async (e) => {
    e.preventDefault();
    const emailHash = localStorage.getItem("hash");

    const campaignData = {
      title: campaign.campaign_title,
      type: campaign.campaign_type,
      description: campaign.campaign_description,
      start_date: campaign.start_date,
      end_date: campaign.end_date,
      banner: campaign.banner || "default_banner.png",
      address: campaign.campaign_address,
      budget: campaign.estimated_budget,
      mobilenumber: campaign.mobilenumber, 
    };

    try {
      const response = await axiosInstance.post("/admin/campaignforuser", campaignData);

      if (response.data.code === 200) {
        // Handle success (e.g., refresh user campaign list, show success message)
        alert("User campaign created successfully");
        closeUsersCampaignFormModal();
      } else {
        console.error("Error:", response.data.message);
      }
    } catch (error) {
      console.error("Error submitting user campaign data:", error.message);
    }
  };


  return (
    <div className="camp">
      <h1 className="camp-title">Campaigns</h1>

      <button
        className="toggle-button toggle-admin"
        onClick={() => handleToggleCampaignType("admin")}
      >
        Admin Campaign
      </button>

      <button
        className="toggle-button toggle-user"
        onClick={() => handleToggleCampaignType("user")}
      >
        User Campaign
      </button>

      {activeCampaignType === "admin" && (
        <>
          {isCampaignFormModalOpen && (
            <div className="modal modal-form">
              <div className="modal-content">
                <form className="campaign-form" onSubmit={handleSubmit}>
                  <h2 className="form-title">Create Campaign</h2>
                  {[
                    { name: "campaign_title", type: "text", placeholder: "Campaign Title" },
                    { name: "campaign_type", type: "text", placeholder: "Campaign Type" },
                    { name: "campaign_description", type: "textarea", placeholder: "Description" },
                    { name: "campaign_address", type: "text", placeholder: "Address" },
                    { name: "estimated_budget", type: "number", placeholder: "Estimated Budget" },
                  ].map(({ name, type, placeholder }) => (
                    type === "textarea" ? (
                      <textarea key={name} className={`textarea-field ${name}-input`} name={name} value={campaign[name]} onChange={handleChange} placeholder={placeholder} />
                    ) : (
                      <input key={name} className={`input-field ${name}-input`} type={type} name={name} value={campaign[name]} onChange={handleChange} placeholder={placeholder} />
                    )
                  ))}
                  {["start_date", "end_date"].map(name => (
                    <input key={name} className={`input-field ${name}-input`} type="date" name={name} value={campaign[name]} onChange={handleChange} />
                  ))}
                  <input className="input-field file-input" type="file" name="bannerimage" onChange={handleFileUpload} />
                  <button className="submit-button" type="submit">Submit Campaign</button>
                  <button className="close-button" type="button" onClick={closeCampaignFormModal}>Close</button>
                </form>
              </div>
            </div>
          )}


          {isAdminCampaignDetailModalOpen && selectedCampaign && (
            <div className="modal modal-details">
              <div className="modal-content">
                <div className="modal-container">
                  <div className="modal-text-content">
                    <h2 className="details-title">Campaign Details</h2>

                    <p className="detail-item">
                      <strong>Title:</strong> {selectedCampaign.campaign_title}
                    </p>

                    <p className="detail-item">
                      <strong>Type:</strong> {selectedCampaign.campaign_type}
                    </p>

                    <p className="detail-item">
                      <strong>Description:</strong>{" "}
                      {selectedCampaign.campaign_description}
                    </p>

                    <p className="detail-item">
                      <strong>Start Date:</strong>{" "}
                      {new Date(
                        selectedCampaign.campaign_start_date
                      ).toLocaleDateString()}
                    </p>

                    <p className="detail-item">
                      <strong>End Date:</strong>{" "}
                      {new Date(
                        selectedCampaign.campaign_end_date
                      ).toLocaleDateString()}
                    </p>

                    <p className="detail-item">
                      <strong>Address:</strong>{" "}
                      {selectedCampaign.campaign_address}
                    </p>

                    <p className="detail-item">
                      <strong>Budget:</strong>{" "}
                      {selectedCampaign.estimated_budget}
                    </p>

                    <p className="detail-item">
                      <strong>Collected Amount:</strong>{" "}
                      {selectedCampaign.collected_amount}
                    </p>

                    <button
                      className="close-button"
                      onClick={closeCampaignDetailModal}
                    >
                      Close
                    </button>
                  </div>

                  <div className="modal-banner">
                    <img
                      className="banner-image"
                      src={selectedCampaign.banner}
                      alt="Campaign Banner"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          <section className="admin-campaign-overview">
            <h2 className="overview-title">Admin Campaign Overview</h2>

            <div className="status-buttons">
              <button
                className="status-button upcoming-button"
                onClick={() => setStatusFilter("upcoming")}
              >
                Upcoming
              </button>

              <button
                className="status-button live-button"
                onClick={() => setStatusFilter("live")}
              >
                Live
              </button>

              <button
                className="status-button completed-button"
                onClick={() => setStatusFilter("completed")}
              >
                Completed
              </button>

              <button
                className="status-button all-button"
                onClick={() => setStatusFilter("all")}
              >
                All
              </button>
            </div>

            <div className="create-campaign-button-container">
              <button
                className="create-campaign-button"
                onClick={openCampaignFormModal}
              >
                Create Campaign
              </button>
            </div>

            {loading ? (
              <p className="loading-message">Loading...</p>
            ) : (
              <table className="campaign-table">
                <thead>
                  <tr>
                    <th className="table-header">S.No</th>
                    <th className="table-header">Campaign Title</th>
                    <th className="table-header">Campaign Type</th>
                    <th className="table-header">Estimated Budget</th>
                    <th className="table-header">Collected Amount</th>
                    <th className="table-header">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredCampaigns(adminCampaigns).map((campaign, index) => (
                    <tr key={campaign._id}>
                      <td className="table-data">{index + 1}</td>
                      <td className="table-data">{campaign.campaign_title}</td>
                      <td className="table-data">{campaign.campaign_type}</td>
                      <td className="table-data">
                        {campaign.estimated_budget}
                      </td>
                      <td className="table-data">
                        {campaign.collected_amount}
                      </td>

                      <td className="table-action">
                        <button
                          className="view-button"
                          onClick={() => fetchAdminCampDetails(campaign._id)}
                        >
                          View
                        </button>
                        <button
                          className="cancel-button"
                          onClick={() => {
                            setSelectedCampaignForCancellation(campaign._id);
                            setIsCancelModalOpen(true);
                          }}
                        >
                          Cancel
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </section>
        </>
      )}



      {activeCampaignType === "user" && (
        <section className="user-campaign-overview">

          {isUserCampaignFormModalOpen && (
            <div className="modal modal-form">
              <div className="modal-content">
                <form className="campaign-form" onSubmit={handleSubmitUserCampaign}>
                  <h2 className="form-title">Create User Campaign</h2>
                  {[
                    { name: "campaign_title", type: "text", placeholder: "Campaign Title", required: true },
                    { name: "campaign_type", type: "text", placeholder: "Campaign Type", required: true },
                    { name: "campaign_description", type: "textarea", placeholder: "Description", required: true },
                    { name: "campaign_address", type: "text", placeholder: "Address", required: true },
                    { name: "estimated_budget", type: "number", placeholder: "Estimated Budget", required: true },
                    { name: "mobilenumber", type: "text", placeholder: "User Mobile Number", required: true },
                    { name: "start_date", type: "date", required: true },
                    { name: "end_date", type: "date", required: true },
                    { name: "banner", type: "file", required: true }
                  ].map(({ name, type, placeholder, required }) => (
                    type === "textarea" ? (
                      <textarea
                        key={name}
                        className={`textarea-field ${name}-input`}
                        name={name}
                        value={campaign[name]}
                        onChange={handleChange}
                        placeholder={placeholder}
                        required={required}
                      />
                    ) : type === "file" ? (
                      <input
                        key={name}
                        className={`input-field ${name}-input`}
                        type={type}
                        name={name}
                        onChange={handleFileUpload} // Handle file upload separately
                        required={required}
                      />
                    ) : (
                      <input
                        key={name}
                        className={`input-field ${name}-input`}
                        type={type}
                        name={name}
                        value={campaign[name]}
                        onChange={handleChange}
                        placeholder={placeholder}
                        required={required}
                      />
                    )
                  ))}
                  <button className="submit-button" type="submit">Create Campaign</button>
                  <button className="close-button" type="button" onClick={closeUsersCampaignFormModal}>Close</button>
                </form>
              </div>
            </div>
          )}


          {/* Campaign Detail Modal */}
          {isUserCampaignDetailModalOpen && selectedCampaign && (
            <div className="modal modal-details">
              <div className="modal-content">
                <div className="modal-container">
                  <div className="modal-text-content">
                    <h2 className="details-title">Campaign Details</h2>

                    <p className="detail-item">
                      <strong>Title:</strong> {selectedCampaign.campaign_title}
                    </p>

                    <p className="detail-item">
                      <strong>Type:</strong> {selectedCampaign.campaign_type}
                    </p>

                    <p className="detail-item">
                      <strong>Description:</strong>{" "}
                      {selectedCampaign.campaign_description}
                    </p>

                    <p className="detail-item">
                      <strong>Start Date:</strong>{" "}
                      {new Date(
                        selectedCampaign.campaign_start_date
                      ).toLocaleDateString()}
                    </p>

                    <p className="detail-item">
                      <strong>End Date:</strong>{" "}
                      {new Date(
                        selectedCampaign.campaign_end_date
                      ).toLocaleDateString()}
                    </p>

                    <p className="detail-item">
                      <strong>Address:</strong>{" "}
                      {selectedCampaign.campaign_address}
                    </p>

                    <p className="detail-item">
                      <strong>Budget:</strong>{" "}
                      {selectedCampaign.estimated_budget}
                    </p>

                    <p className="detail-item">
                      <strong>Collected Amount:</strong>{" "}
                      {selectedCampaign.collected_amount}
                    </p>

                    <p className="detail-item">
                      <strong>Status:</strong> {selectedCampaign.status}
                    </p>

                    <button
                      className="close-button"
                      onClick={closeCampaignDetailModal}
                    >
                      Close
                    </button>
                  </div>

                  <div className="modal-banner">
                    <img
                      className="banner-image"
                      src={selectedCampaign.banner}
                      alt="Campaign Banner"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          <h2 className="overview-title">User Campaign Overview</h2>

          <div className="status-buttons">
            <button
              className="status-button upcoming-button"
              onClick={() => setStatusFilter("upcoming")}
            >
              Upcoming
            </button>

            <button
              className="status-button live-button"
              onClick={() => setStatusFilter("live")}
            >
              Live
            </button>

            <button
              className="status-button completed-button"
              onClick={() => setStatusFilter("completed")}
            >
              Completed
            </button>

            <button
              className="status-button all-button"
              onClick={() => setStatusFilter("all")}
            >
              All
            </button>


          </div>
          <div className="create-campaign-button-container">
            <button
              className="create-campaign-button"
              onClick={openUsersCampaignFormModal}
            >
              Create Campaign for user
            </button>
          </div>

          {loading ? (
            <p className="loading-message">Loading...</p>
          ) : (
            <table className="campaign-table">
              <thead>
                <tr>
                  <th className="table-header">S.No</th>
                  <th className="table-header">Campaign Title</th>
                  <th className="table-header">Campaign Type</th>
                  <th className="table-header">Estimated Budget</th>
                  <th className="table-header">Collected Amount</th>
                  {/* <th className="table-header">Status</th> */}
                  <th className="table-header">Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredCampaigns(userCampaigns).map((campaign, index) => (
                  <tr key={campaign._id}>
                    <td className="table-data">{index + 1}</td>
                    <td className="table-data">{campaign.campaign_title}</td>
                    <td className="table-data">{campaign.campaign_type}</td>
                    <td className="table-data">{campaign.estimated_budget}</td>
                    <td className="table-data">{campaign.collected_amount}</td>
                    {/* <td className="table-data">{campaign.status}</td> */}

                    <td className="table-action">
                      <div className="view-cancel-btn">
                        <button
                          className="view-button"
                          onClick={() => fetchUserCampDetails(campaign._id)}
                        >
                          View
                        </button>
                        <button
                          className="cancel-button"
                          onClick={() => {
                            setSelectedCampaignForCancellation(campaign._id, campaign.reason_for_cancellation);
                            setIsCancelModalOpen(true);
                          }}
                        >
                          Cancel
                        </button>
                      </div>

                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      )}

      {isCancelModalOpen && (
        <div className="modal modal-cancel">
          <div className="modal-content">
            <h2 className="modal-title">Cancel Campaign</h2>
            <textarea
              className="textarea-field cancel-reason-input"
              value={cancelReason}
              onChange={(e) => setCancelReason(e.target.value)}
              placeholder="Enter reason for cancellation"
            />
            <button
              className="submit-button"
              onClick={handleCancelCampaign}
            >
              Submit Cancellation
            </button>
            <button
              className="close-button"
              onClick={() => setIsCancelModalOpen(false)}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Campaigns;
