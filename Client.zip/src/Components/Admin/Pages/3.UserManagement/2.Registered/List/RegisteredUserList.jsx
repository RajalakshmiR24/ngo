import React, { useEffect, useState } from 'react';
import axiosInstance from '../../../../../../Utils/axiosInstance';
import CampaignDetails from '../CampaignDetails/CampaignDetails';
import './RegisteredUserList.css';

const RegisteredUserList = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedCampaigns, setSelectedCampaigns] = useState([]);
  const [showDetails, setShowDetails] = useState(false);
  const [loadingCampaigns, setLoadingCampaigns] = useState(false);
  const [noCampaignMessage, setNoCampaignMessage] = useState('');

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axiosInstance.get('/admin/allusers');
        console.log(response);
        setUsers(response.data.data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchUsers();
  }, []);

  const handleAction = async (email) => {
    setLoadingCampaigns(true);
    setNoCampaignMessage('');
    try {
      const response = await axiosInstance.post('/admin/campaignperuser', { email });
      const campaignsData = response.data.data;

      if (campaignsData && campaignsData.length > 0) {
        setSelectedCampaigns(campaignsData);
        setShowDetails(true);
      } else {
        setNoCampaignMessage("No campaigns found for this user.");
        setShowDetails(true);
      }
    } catch (err) {
      console.error("Error fetching campaigns:", err);
      setNoCampaignMessage("Failed to fetch campaigns: " + err.message);
      setShowDetails(true);
    } finally {
      setLoadingCampaigns(false);
    }
  };

  const closeDetails = () => {
    setShowDetails(false);
    setSelectedCampaigns([]);
    setNoCampaignMessage('');
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div>
      {showDetails ? (
        <CampaignDetails
          campaigns={selectedCampaigns}
          noCampaignMessage={noCampaignMessage}
          onClose={closeDetails}
        />
      ) : (
        <div>
          <h2>Registered User List</h2>
          <table>
            <thead>
              <tr>
                <th>S.No</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Mobile Number</th>
                <th>No. of Campaigns</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user, index) => (
                <tr key={user._id}>
                  <td>{index + 1}</td> {/* Serial number */}
                  <td>{user.fullname}</td>
                  <td>{user.email}</td>
                  <td>{user.mobile_number}</td>
                  <td>{user.campaigns ? user.campaigns.length : 0}</td>
                  <td>
                    <button onClick={() => handleAction(user.email_hash)} disabled={loadingCampaigns}>
                      {loadingCampaigns ? 'Loading...' : 'View Details'} {/* Updated button text */}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default RegisteredUserList;
