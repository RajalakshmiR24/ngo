import React, { useEffect, useState } from "react";
import axiosInstance from "../../../../../../Utils/axiosInstance";
// import CampaignDetails from "../CampaignDetails/CampaignDetails";
import UserDetailsModal from "../UserDetails/UserDetailsModal"; 
import "./RegisteredUserList.css";

const RegisteredUserList = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedUser, setSelectedUser] = useState(null); // State to hold the selected user
  const [showUserDetails, setShowUserDetails] = useState(false); // State to control UserDetails modal

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axiosInstance.get("/admin/allusers");
        setUsers(response.data.data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchUsers();
  }, []);

  const handleViewUserDetails = (email_hash) => {
    const user = users.find((user) => user.email_hash === email_hash);
    setSelectedUser(user);
    setShowUserDetails(true);
  };

  const closeDetails = () => {
    setShowUserDetails(false);
    setSelectedUser(null);
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div className="container">
      <div className="user-list-section">
        <h2 className="user-list-title">Registered User List</h2>
        <table className="user-list-table">
          <thead className="table-header">
            <tr className="header-row">
              <th className="header-cell">S.No</th>
              <th className="header-cell">Full Name</th>
              <th className="header-cell">Email</th>
              <th className="header-cell">Mobile Number</th>
              <th className="header-cell">No. of Camp</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody className="table-body">
            {users.map((user, index) => (
              <tr key={user._id} className="body-row">
                <td className="body-cell">{index + 1}</td>
                <td className="body-cell">
                  
                    {user.fullname}
                </td>
                <td className="body-cell">{user.email}</td>
                <td className="body-cell">{user.mobile_number}</td>
                <td className="body-cell">
                    {user.campaigns ? user.campaigns.length : 0}
                </td>
                <td className="body-cell">
                  <button
                    onClick={() => handleViewUserDetails(user.email_hash)}
                    className="view-camp-button"
                  >
                    View
                  </button>
                  </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Render User Details Modal */}
      {showUserDetails && (
        <UserDetailsModal user={selectedUser} onClose={closeDetails} />
      )}
    </div>
  );
};

export default RegisteredUserList;
