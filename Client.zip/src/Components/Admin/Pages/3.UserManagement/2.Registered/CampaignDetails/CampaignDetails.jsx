import React, { useState } from 'react';
import './CampaignDetails.css';

const CampaignDetails = ({ campaigns = [], noCampaignMessage, onClose }) => {
  const [bannerImage, setBannerImage] = useState(null);
  const [loading, setLoading] = useState(false);
  

  const getStatusClass = (status) => {
    switch (status.toLowerCase()) {
      case 'live':
        return 'status-red'; 
      case 'upcoming':
        return 'status-yellow'; 
      case 'completed':
        return 'status-green'; 
      default:
        return ''; 
    }
  };

  return (
    <div className="campaign-details-modal">
      <button className="close-button" onClick={onClose}>X</button>
      <h3>Campaigns for User</h3>
      <div className="campaign-list">
        {noCampaignMessage ? (
          <p className="no-campaign-message">{noCampaignMessage}</p>
        ) : (
          campaigns.length > 0 ? (
            campaigns.map(campaign => (
              <div className="campaign-card" key={campaign.id} onClick={() => handleCardClick(campaign)}>
                {campaign.banner && (
                  <img src={campaign.banner} alt={campaign.campaign_title} className="campaign-image" />
                )}
                <div className="campaign-info">
                  <h4>{campaign.campaign_title}</h4>
                  <p>{campaign.campaign_description}</p>
                  <p><strong>Start Date:</strong> {new Date(campaign.start_date).toLocaleDateString()}</p>
                  <p><strong>End Date:</strong> {new Date(campaign.end_date).toLocaleDateString()}</p>
                  <p><strong>Budget:</strong> {campaign.budget ? campaign.budget : 'Not specified'}</p>
                  <p><strong>Address:</strong> {campaign.campaign_address}</p>
                  <p className={`status ${getStatusClass(campaign.status)}`}>
                    <strong>Status:</strong> {campaign.status}
                  </p>
                </div>
              </div>
            ))
          ) : (
            <p>No campaigns available.</p>
          )
        )}
      </div>

      {loading && <p>Loading image...</p>} {/* Loading indicator */}

      {bannerImage && ( 
        <div className="banner-image-modal">
          <button className="close-image-button" onClick={() => setBannerImage(null)}>X</button>
          <img src={bannerImage} alt="Banner" className="full-banner-image" />
        </div>
      )}
    </div>
  );
};

export default CampaignDetails;
