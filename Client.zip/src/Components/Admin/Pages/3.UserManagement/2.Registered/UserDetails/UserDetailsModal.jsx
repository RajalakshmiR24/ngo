import React from 'react';
import './UserDetailsModal.css'; // Optional: for styling

const UserDetailsModal = ({ user, onClose }) => {
  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <h2>User Details</h2>
        <button onClick={onClose} className="close-button">Close</button>
        
        <p><strong>Full Name:</strong> {user.fullname}</p>
        <p><strong>Email:</strong> {user.email}</p>
        <p><strong>Mobile Number:</strong> {user.mobile_number}</p>
        <p><strong>Status:</strong> {user.status}</p>
        <p><strong>Account Created:</strong> {new Date(user.account_created_date).toLocaleDateString()}</p>
        
        <h3>Campaigns</h3>
        <ul>
          {user.campaigns.length > 0 ? (
            user.campaigns.map(campaign => (
              <li key={campaign.campaign_id}>
                <p><strong>Title:</strong> {campaign.campaign_title}</p>
                <p><strong>Description:</strong> {campaign.campaign_description}</p>
                <p><strong>Start Date:</strong> {new Date(campaign.campaign_start_date).toLocaleDateString()}</p>
                <p><strong>End Date:</strong> {new Date(campaign.campaign_end_date).toLocaleDateString()}</p>
              </li>
            ))
          ) : (
            <p>No campaigns available.</p>
          )}
        </ul>
      </div>
    </div>
  );
};

export default UserDetailsModal;
