import React, { useEffect ,useState } from "react";
import axiosInstance from "../../../../Utils/axiosInstance";
import { useRequests } from '../../../../Context/RequestsContext'; 
import './Request.css';

const Requests = () => {
  const {
    users, setUsers,
    camp, setCamps,
    bills, setBills,
    loading, setLoading,
    error, setError,
    successMessage, setSuccessMessage,
    activeTab, setActiveTab,
    selectedCampaign, setSelectedCampaign,
    selectedUser, setSelectedUser,
    selectedBill, setSelectedBill,
  } = useRequests();
  const [reason, setReason] = useState(''); 


  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axiosInstance.get("/admin/verifyuserdetails");
        setUsers(response.data?.data || []);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchUsers();
  }, []);

  const handleUserAction = (userId) => {
    setSelectedUser(users.find((u) => u.email_hash === userId) || null);
  };

  useEffect(() => {
    const fetchCamps = async () => {
      try {
        const response = await axiosInstance.get("/admin/campaignstatustoverify");
        setCamps(response.data?.data || []);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchCamps();
  }, []);

  const handleCampAction = (campId) => {
    setSelectedCampaign(camp.find((c) => c.campaign_id === campId) || null);
  };

  useEffect(() => {
    const fetchBills = async () => {
      try {
        const response = await axiosInstance.get("/admin/verifybills");
        setBills(response.data?.data || []);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchBills();
  }, []);

  const handleBillsAction = (billId) => {
    setSelectedBill(bills.find((b) => b.billID === billId) || null);
  };


  const closeUserDetailModal = () => {
    setSelectedUser(null);
  };

  const closeCampaignDetailModal = () => {
    setSelectedCampaign(null);
  };

  const closeBillDetailModal = () => {
    setSelectedBill(null);
  };


  const handleUserApproval = async (status) => {
    console.log(selectedUser, '...........................');

    try {
      const response = await axiosInstance.post("/admin/rejectuser", {
        email: selectedUser.email_hash,
        status,
      });

      if (response.data.code === 200) {
        setSelectedUser(response.data.data);
        setSuccessMessage(response.data.message);
        setUsers((prevUsers) =>
          prevUsers.map((user) =>
            user.email === selectedUser.email
              ? { ...user, status: status === "ACTIVE" ? "ACTIVE" : "REJECTED" }
              : user
          )
        );
      } else {
        setError(response.data.message || "Failed to update user status");
      }
    } catch (error) {
      console.error("Error approving/rejecting user:", error);
      setError("Failed to update user status");
    } finally {
      setLoading(false);
      closeUserDetailModal();
    }
  };

  const handleCampaignApproval = async (status) => {
    setLoading(true);
    console.log(selectedCampaign, '...........................');
    
    try {
      const response = await axiosInstance.post("/admin/rejectcampreq", {
        campaign_id: selectedCampaign.campaign_id, 
        status,
      });

      if (response.data.code === 200) {
        setSuccessMessage(response.data.message);
        setCamps((prevCamp) =>
          prevCamp.map((campaign) =>
            campaign.campaign_id === selectedCampaign.campaign_id
              ? {
                  ...campaign,
                  status: status === "APPROVED" ? "APPROVED" : "REJECTED",
                }
              : campaign
          )
        );
      } else {
        setError("Failed to update campaign status");
      }
    } catch (error) {
      console.error("Error approving/rejecting campaign:", error);
      setError("Failed to update campaign status");
    } finally {
      setLoading(false);
      closeCampaignDetailModal();
    }
  };

  const handleBillApproval = async (status, reason) => {
    if (!selectedBill) return;

    setLoading(true);
    try {
        
        const response = await axiosInstance.put("/admin/verifyrejectbills", {
            billID: selectedBill._id,
            status,
            reason: status === "REJECTED" ? reason : undefined, 
        });

        
        if (response.data.code === 200) {
            setSuccessMessage(response.data.message);
            setBills((prevBills) =>
                prevBills.map((bill) =>
                    bill.id === selectedBill.id
                        ? {
                            ...bill,
                            status: status, 
                            reason_for_cancellation: status === "REJECTED" ? reason : undefined, 
                        }
                        : bill
                )
            );
        } else {
            setError("Failed to update bill status");
        }
    } catch (error) {
        console.error("Error approving/rejecting bill:", error);
        setError("Failed to update bill status");
    } finally {
        setLoading(false);
        closeBillDetailModal();
    }
};




  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
<div className="dashboard-container">
  <h2 className="dashboard-title">Management Dashboard</h2>
  {successMessage && (
    <div className="success-message">{successMessage}</div>
  )}
  <div className="tab-buttons">
    <button className="tab-button" onClick={() => setActiveTab("users")}>Users</button>
    <button className="tab-button" onClick={() => setActiveTab("camp")}>Campaigns</button>
    <button className="tab-button" onClick={() => setActiveTab("bills")}>Bills</button>
  </div>

  {activeTab === "users" && (
    <div className="users-section">
      <h2 className="section-title">Users to Verify</h2>
      <table className="table users-table">
        <thead className="table-header">
          <tr>
            <th>S.No</th>
            <th>Name</th>
            <th>Email</th>
            <th>Mobile number</th>
            <th>Created date</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody className="table-body">
          {users.length > 0 ? (
            users.map((user, i) => (
              <tr key={user.email_hash}>
                <td>{i + 1}</td>
                <td>{user.fullname}</td>
                <td>{user.email}</td>
                <td>{user.mobile_number}</td>
                <td>{new Date(user.account_created_date).toLocaleDateString()}</td>
                <td>{user.status}</td>
                <td>
                  <button className="action-button" onClick={() => handleUserAction(user.email_hash)}>
                    View
                  </button>
                  
             </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="7">No user data found</td>
            </tr>
          )}
        </tbody>
      </table>
      <UserDetailModal user={selectedUser} onClose={closeUserDetailModal} verifyreject={handleUserApproval} />

    </div>
  )}

  {activeTab === "camp" && (
    <div className="campaigns-section">
      <h2 className="section-title">Campaigns to Verify</h2>
      <table className="table campaigns-table">
        <thead className="table-header">
          <tr>
            <th>S.No</th>
            <th>Campaign Name</th>
            <th>Campaign Type</th>
            <th>Campaign Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody className="table-body">
          {camp.length > 0 ? (
            camp.map((campaign, i) => (
              <tr key={campaign._id}>
                <td>{i + 1}</td>
                <td>{campaign.campaign_title}</td>
                <td>{campaign.campaign_type}</td>
                <td>{campaign.status}</td>
                <td>
                  <button className="action-button" onClick={() => handleCampAction(campaign.campaign_id)}>
                    View
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="5">No campaign data found</td>
            </tr>
          )}
        </tbody>
      </table>
      <CampDetailModal camp={selectedCampaign} onClose={closeCampaignDetailModal} verifyreject={handleCampaignApproval} />

    </div>
  )}

  {activeTab === "bills" && (
    <div className="bills-section">
      <h2 className="section-title">Bills to Verify</h2>
      <table className="table bills-table">
        <thead className="table-header">
          <tr>
            <th>S.No</th>
            <th>Email</th>
            <th>Campaign Name</th>
            <th>Bill Amount</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody className="table-body">
          {bills.length > 0 ? (
            bills.map((bill, i) => (
              <tr key={bill._id}>
                <td>{i + 1}</td>
                <td>{bill.user ? bill.user[0]?.email : "Unknown email"}</td>
                <td>{bill.campaign ? bill.campaign[0]?.campaign_title : "Unknown campaign"}</td>
                <td>{bill.claiming_amount}</td>
                <td>{bill.status}</td>
                <td>
                  <button className="action-button" onClick={() => handleBillsAction(bill.billID)}>
                    View
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="7">No bills available</td>
            </tr>
          )}
        </tbody>
      </table>
      <BillDetailModal bill={selectedBill} onClose={closeBillDetailModal} verifyreject={handleBillApproval} reason={reason} setReason={setReason} />

    </div>
  )}

  
</div>


  );
};

const UserDetailModal = ({ user, onClose, verifyreject }) => {
  if (!user) return null;

  return (
    <div className="modal user-modal">
      <div className="modal-content">
        <h2>User Details</h2>
        <div
          className="modal-background"
          style={{
            backgroundImage: `url(${user.id_proof})`,
          }}
        />
        <h3 className="modal-subtitle">User Information</h3>
        <p><strong>Full Name:</strong> {user.fullname}</p>
        <p><strong>Email:</strong> {user.email}</p>
        <p><strong>Current Address:</strong> {user.current_address}</p>
        <p><strong>Mobile Number:</strong> {user.mobile_number}</p>
        <p><strong>Account Created:</strong> {new Date(user.account_created_date).toLocaleDateString()}</p>
        <p><strong>Status:</strong> {user.status}</p>
        <button className="modal-button" onClick={() => verifyreject("ACTIVE")}>Verify</button>
        <button className="modal-button" onClick={() => verifyreject("REJECTED")}>Reject</button>
           
        
        <button className="modal-button" onClick={onClose}>Close</button>
      </div>
    </div>
  );
};

const CampDetailModal = ({ camp, onClose, verifyreject }) => {
  if (!camp) return null;

  return (
    <div className="modal campaign-modal">
    <div className="modal-content">
      <div className="modal-container">
        <div className="modal-text-content">
          <h2>Campaign Details</h2>
          <p><strong>Title:</strong> {camp.campaign_title}</p>
          <p><strong>Type:</strong> {camp.campaign_type}</p>
          <p><strong>Description:</strong> {camp.campaign_description}</p>
          <p><strong>Start Date:</strong> {new Date(camp.campaign_start_date).toLocaleDateString()}</p>
          <p><strong>End Date:</strong> {new Date(camp.campaign_end_date).toLocaleDateString()}</p>
          <p><strong>Address:</strong> {camp.campaign_address}</p>
          <p><strong>Budget:</strong> {camp.estimated_budget}</p>
          <p><strong>Collected Amount:</strong> {camp.collected_amount}</p>
          <p><strong>Status:</strong> {camp.status}</p>
          <button className="modal-button" onClick={() => verifyreject("APPROVED")}>Verify</button>
          <button className="modal-button" onClick={() => verifyreject("REJECTED")}>Reject</button>
          <button className="modal-button" onClick={onClose}>Close</button>
        </div>
        <div className="modal-banner">
          <img src={camp.banner} alt="Campaign Banner" />
        </div>
      </div>
    </div>
  </div>
  );
};



const BillDetailModal = ({ bill, onClose, verifyreject }) => {
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [reason, setReason] = useState(''); 

  const handleReject = (reason) => {
    verifyreject("REJECTED", reason); 
    setReason(''); 
  };

  if (!bill) return null;

  return (
    <div className="modal bill-modal">
      <div className="modal-content">
        <div className="modal-container">
          <div className="modal-text-content">
            <h2>Bill Details</h2>
            <img className="bill-image" src={bill.bills} alt="bill" srcset="" />

            <p><strong>Email:</strong> {bill.user[0]?.email || "Unknown email"}</p>
            <p><strong>Campaign:</strong> {bill.campaign[0]?.campaign_title || "Unknown campaign"}</p>
            <p><strong>Claiming Amount:</strong> {bill.claiming_amount}</p>
            <p><strong>Status:</strong> {bill.status}</p>


            {/* Verify button */}
            <button className="modal-button" onClick={() => verifyreject("APPROVED")}>
              Verify
            </button>

            {/* Reject button to open the reject modal */}
            <button className="modal-button" onClick={() => setShowRejectModal(true)}>
              Reject
            </button>

            {/* Close button */}
            <button className="modal-button" onClick={onClose}>
              Close
            </button>
          </div>
        </div>
      </div>

      {/* Reject Modal */}
      <RejectModal
        isOpen={showRejectModal}
        onClose={() => setShowRejectModal(false)}
        onReject={handleReject}
        reason={reason} 
        setReason={setReason} 
      />
    </div>
  );
};

const RejectModal = ({ isOpen, onClose, onReject, reason, setReason }) => {
  const handleReject = () => {
    if (!reason) {
      return; 
    }
    onReject(reason); 
    setReason(''); 
    onClose(); 
  };

  if (!isOpen) return null;

  return (
    <div className="modal">
      <div className="modal-content">
        <h2>Reject Bill</h2>
        <label htmlFor="reason">Reason for Rejection:</label>
        <input
          type="text"
          id="reason"
          value={reason}
          onChange={(e) => setReason(e.target.value)} 
          placeholder="Enter reason for rejection"
        />
        <button onClick={handleReject}>Submit</button>
        <button onClick={onClose}>Cancel</button>
      </div>
    </div>
  );
};







export default Requests;
