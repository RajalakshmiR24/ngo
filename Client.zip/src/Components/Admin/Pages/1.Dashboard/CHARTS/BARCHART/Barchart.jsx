
import React, { useEffect, useState } from 'react';
import './Barchart.css';
import { Bar } from 'react-chartjs-2';
import axiosInstance from '../../../../../../Utils/axiosInstance';
import { Chart as ChartJS, BarElement, CategoryScale, LinearScale, Title, Tooltip, Legend } from 'chart.js';

ChartJS.register(BarElement, CategoryScale, LinearScale, Title, Tooltip, Legend);

const Barchart = () => {
    const [chartData, setChartData] = useState({
        labels: ['Upcoming', 'Ongoing', 'Completed', 'Cancelled'],
        datasets: [
            {
                label: 'Campaign Counts',
                data: [0, 0, 0, 0], 
                backgroundColor: [
                    'rgba(75, 192, 192, 0.6)',
                    'rgba(255, 206, 86, 0.6)',
                    'rgba(54, 162, 235, 0.6)',
                    'rgba(255, 99, 132, 0.6)',
                ],
            },
        ],
    });

    const options = {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'Campaign Counts by Status',
            },
        },
    };

    useEffect(() => {
        const fetchData = async () => {

            try {
                const [upcomingResponse, ongoingResponse, completedResponse, cancellationResponse] = await Promise.all([

                    // axiosInstance.get('/admin/upcoming'), 
                    // axiosInstance.get('/admin/live'),
                    // axiosInstance.get('/admin/complete'),
                    // axiosInstance.get('/admin/cancel'),
                ]);
                
                const salesData = [
                    upcomingResponse.data.data || 0,
                    ongoingResponse.data.data || 0,
                    completedResponse.data.data || 0,
                    cancellationResponse.data.data || 0,
                ];

                setChartData(prevData => ({
                    ...prevData,
                    datasets: [{
                        ...prevData.datasets[0],
                        data: salesData,
                    }],
                }));
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        fetchData();
    }, []);

    return (
        <div style={{ height: "50vh", width: "100%" }} className='bar_chart'>
            <Bar data={chartData} options={options} />
        </div>
    );
};

export default Barchart;
