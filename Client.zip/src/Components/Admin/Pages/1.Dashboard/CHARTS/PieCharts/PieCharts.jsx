import React, { useEffect, useState } from 'react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Pie } from 'react-chartjs-2';
import axiosInstance from '../../../../../../Utils/axiosInstance'; 
import './PieCharts.css'; 

ChartJS.register(ArcElement, Tooltip, Legend);

export const PieChart = () => {
    const [registeredUsers, setRegisteredUsers] = useState(0);
    const [generalUsers, setGeneralUsers] = useState(0);
    const [totalCampaignCount, setTotalCampaignCount] = useState(0); // New state for total campaign count
    const [loading, setLoading] = useState(true);
    const [selectedUserCount, setSelectedUserCount] = useState(null);

    useEffect(() => {
        const fetchUserCounts = async () => {
            setLoading(true);
            try {
                const registeredResponse = await axiosInstance.get('/admin/r_userscount');
                const generalResponse = await axiosInstance.get('/admin/g_users');
                const campaignResponse = await axiosInstance.get('/admin/totalcampaigncount'); // Fetch total campaign count
                
                setRegisteredUsers(registeredResponse.data.data); 
                setGeneralUsers(generalResponse.data.data);
                setTotalCampaignCount(campaignResponse.data.data); // Set total campaign count
            } catch (error) {
                console.error('Error fetching user counts:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchUserCounts();
    }, []);

    const data = {
        labels: ['General Users', 'Registered Users', 'Total Campaigns'], // Updated labels
        datasets: [
            {
                label: 'Users and Campaigns',
                data: [generalUsers, registeredUsers, totalCampaignCount], // Updated data
                backgroundColor: [
                    'rgba(255, 99, 132, 0.7)',
                    'rgba(54, 162, 235, 0.7)',
                    'rgba(255, 206, 86, 0.7)', // Color for total campaigns
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)', // Border color for total campaigns
                ],
                borderWidth: 2,
            },
        ],
    };

    const options = {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
                labels: {
                    font: {
                        size: 14,
                        weight: 'bold',
                    },
                },
            },
            title: {
                display: true,
                text: 'User and Campaign Statistics', // Updated title
                font: {
                    size: 18,
                    weight: 'bold',
                },
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        let label = context.label || ' ';
                        if (context.parsed !== null) {
                            label += `: ${context.raw}`;
                        }
                        return label;
                    }
                },
                backgroundColor: 'rgba(0, 0, 0, 0.7)',
            },
        },
        onClick: (event, elements) => {
            if (elements.length > 0) {
                const elementIndex = elements[0].index;
                const count = data.datasets[0].data[elementIndex];
                const label = data.labels[elementIndex];
                setSelectedUserCount(`${label}: ${count}`);
            }
        },
    };
    
    if (loading) {
        return <div className="loading-indicator">Loading...</div>;
    }

    return (
        <div className='piechart'>
            <Pie data={data} options={options} />
            {selectedUserCount && (
                <div className="user-count-display">
                    <p>{selectedUserCount}</p>
                </div>
            )}
        </div>
    );
};
