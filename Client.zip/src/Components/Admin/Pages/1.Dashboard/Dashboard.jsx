import React from "react";
import "./Dashboard.css";
import Barchart from "./CHARTS/Barchart";
import { PieChart } from "./CHARTS/PieCharts";
import DonutChart from "./CHARTS/DonutChart";

const Dashboard = () => {
  return (
    <div className="chart-container">
            <h1 className="dashboaed-heading">DASHBOARD</h1>

        <div className="linechart">
          <Barchart />
        </div>
     
        <div className="piechart">
          <PieChart />
        </div>
        <div className="barchart">
          <DonutChart/>
        </div>
    </div>
  );
};

export default Dashboard;
