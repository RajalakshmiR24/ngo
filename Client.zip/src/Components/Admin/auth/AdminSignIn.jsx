import React, { useState } from "react";
import axiosInstance from "../../../Utils/axiosInstance";
import { useNavigate } from "react-router-dom";
import Form from "../Common/Form/Form";
import Input from "../Common/Form/Input";
import { validateForm } from "../../../Utils/Validation";
import "./Style.css";

const AdminSignIn = () => {
  const [info, setInfo] = useState({});
  const [errorMessage, setErrorMessage] = useState("");
  const [formErrors, setFormErrors] = useState({});
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setInfo((prevState) => ({ ...prevState, [name]: value }));
    setErrorMessage("");
    setFormErrors((prev) => ({ ...prev, [name]: undefined }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault(); // Prevent default form submission behavior

    const errors = validateForm(info);
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }

    try {
      const res = await axiosInstance.post("/admin/login", info);
      if (res.data.code === 200) {
        localStorage.setItem("token", res.data.accessToken);
        localStorage.setItem("hash", res.data.hash);
        navigate("/admin");
      }
    } catch (error) {
      console.error("Login error:", error);
      setErrorMessage(
        error.response?.data?.message || "An error occurred. Please try again."
      );
    }
  };

  return (
    <div className="app-container">
      <h3 className="Admin_header">Admin Login</h3>
      <Form onSubmit={handleSubmit}>
        {["email", "password"].map((field) => (
          <div className="form-group" key={field}>
            <Input
              type={field}
              name={field}
              placeholder={field.charAt(0).toUpperCase() + field.slice(1)}
              value={info[field] || ""}
              onChange={handleChange}
            />
            {formErrors[field] && (
              <p className="error-message">{formErrors[field]}</p>
            )}
          </div>
        ))}
        <button type="submit">Login</button>
        {errorMessage && <p className="error-message">{errorMessage}</p>}
      </Form>
    </div>
  );
};

export default AdminSignIn;
