import { useState } from "react";
import axiosInstance from "../../Utils/axiosInstance";
import UploadImage from "./UploadImage.jsx";

const CampaignForm = () => {
  const [info, setInfo] = useState({
    user_email:
      "02ee7bdc4ccf5c94808a0118eb531822f13e7e38e3810ab29ebefb2c2feb8e58",
    banner: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setInfo((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const convertIntoBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const fileReader = new FileReader();
      fileReader.readAsDataURL(file);
      fileReader.onload = () => {
        resolve(fileReader.result);
      };
      fileReader.onerror = (error) => {
        reject(error);
      };
    });
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (file) {
      const base64 = await convertIntoBase64(file);
      setInfo((prevState) => ({
        ...prevState,
        banner: base64, // Update the banner state
      }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(info, "infoooooooooooooo");

    axiosInstance
      .post(/user/savecampaigndata, info)
      .then(() => {
        alert("Data successfully inserted");
      })
      .catch((error) => {
        console.log("There was an error inserting the data!", error);
      });
  };

  return (
    <div className="form-container">
      <form onSubmit={handleSubmit} className="login-form">
        <div className="form-group">
          <label>Campaign Title</label>
          <input
            type="text"
            name="title"
            value={info?.title || " "}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label>Campaign Description</label>
          <input
            type="text"
            name="description"
            value={info?.description || " "}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label>Banner Image</label>
          <input type="file" name="bannerimage" onChange={handleFileUpload} />
        </div>
        {/* <div className="form-group">
          <label>Budget</label>
          <input
            type="text"
            name="budget"
            value={info?.budget || " "}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label>Timeline</label>
          <input
            type="text"
            name="timeline"
            value={info?.timeline || " "}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label>Location</label>
          <input
            type="text"
            name="location"
            value={info?.location || " "}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label>Partnerships and Collaborations</label>
          <input
            type="text"
            name="partnerships"
            value={info?.partnerships || " "}
            onChange={handleChange}
          /> */}
        {/* </div> */}
        <input type="submit" value="Submit" />
      </form>
      <UploadImage/>
    </div>
  );
};

export default CampaignForm;