// RequestsContext.js
import React, { createContext, useContext, useState } from 'react';

// Create a Context
const RequestsContext = createContext();

// Create a Provider Component
export const RequestsProvider = ({ children }) => {
  const [users, setUsers] = useState([]);
  const [camp, setCamps] = useState([]);
  const [bills, setBills] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);
  const [activeTab, setActiveTab] = useState("users");
  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const [selectedUser, setSelectedUser] = useState(null);
  const [selectedBill, setSelectedBill] = useState(null);
  const [userCampaignDetailModalOpen, setUserCampaignDetailModalOpen] = useState(false);
  const [userDetailModalOpen, setUserDetailModalOpen] = useState(false);
  const [billDetailModalOpen, setBillDetailModalOpen] = useState(false);

  return (
    <RequestsContext.Provider value={{
      users, setUsers,
      camp, setCamps,
      bills, setBills,
      loading, setLoading,
      error, setError,
      successMessage, setSuccessMessage,
      activeTab, setActiveTab,
      selectedCampaign, setSelectedCampaign,
      selectedUser, setSelectedUser,
      selectedBill, setSelectedBill,
      userCampaignDetailModalOpen, setUserCampaignDetailModalOpen,
      userDetailModalOpen, setUserDetailModalOpen,
      billDetailModalOpen, setBillDetailModalOpen
    }}>
      {children}
    </RequestsContext.Provider>
  );
};

// Custom hook to use the Requests context
export const useRequests = () => {
  return useContext(RequestsContext);
};
