import React from 'react'
import './Dashboard.css'
// import { LineChart } from './CHARTS/LineChart/LineCharts'
import { PieChart } from './CHARTS/PieCharts/PieCharts';
import  BarChart from './CHARTS/BARCHART/Barchart';


const CampaignDashboard = () => {
  return (

    <div className='linechart'>
        {/* <div><LineChart/></div> */}
        <div className="barchart"><BarChart/></div>
        <div className='piechart'><PieChart/></div>
    </div>

  )
}

export default CampaignDashboard


