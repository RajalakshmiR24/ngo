import React, { useEffect, useState } from 'react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Pie } from 'react-chartjs-2';
import axiosInstance from '../../../../../../Utils/axiosInstance'; // Adjust the path as necessary

ChartJS.register(ArcElement, Tooltip, Legend);

export const PieChart = () => {
    const [registeredUsers, setRegisteredUsers] = useState(0);
    const [generalUsers, setGeneralUsers] = useState(0);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchUserCounts = async () => {
            setLoading(true);
            try {
                const registeredResponse = await axiosInstance.get('/admin/registeredusers');
                const generalResponse = await axiosInstance.get('/admin/totalgeneralusers');

                setRegisteredUsers(registeredResponse.data.data); 
                setGeneralUsers(generalResponse.data.data);
            } catch (error) {
                console.error('Error fetching user counts:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchUserCounts();
    }, []);

    const data = {
        labels: ['General Users', 'Registered Users'],
        datasets: [
            {
                label: 'Users',
                data: [generalUsers, registeredUsers],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                ],
                borderWidth: 2,
            },
        ],
    };

    if (loading) {
        return <div>Loading...</div>;
    }

    return (
        <div className='piechart' style={{ height: '300px', width: '300px' }}>
            <h2>Users Distribution</h2>
            <Pie data={data} height={300} width={300} />
        </div>
    );
};
