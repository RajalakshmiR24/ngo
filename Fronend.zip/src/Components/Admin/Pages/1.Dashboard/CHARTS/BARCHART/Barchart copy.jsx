import React, { useEffect, useState } from 'react';
import './Barchart.css';
import { Bar } from 'react-chartjs-2';
import axiosInstance from '../../../../../../Utils/axiosInstance';
import { Chart as ChartJS, BarElement, CategoryScale, LinearScale, Title, Tooltip, Legend } from 'chart.js';

ChartJS.register(BarElement, CategoryScale, LinearScale, Title, Tooltip, Legend);

const Barchart = () => {
    const [chartData, setChartData] = useState({
        labels: ['Upcoming', 'Ongoing', 'Completed', 'Cancelled'],
        datasets: [
            {
                label: 'Campaign Counts',
                data: [0, 0, 0, 0], // Initialize with zero counts
                backgroundColor: [
                    'rgba(75, 192, 192, 0.6)',
                    'rgba(255, 206, 86, 0.6)',
                    'rgba(54, 162, 235, 0.6)',
                    'rgba(255, 99, 132, 0.6)',
                ],
            },
        ],
    });

    const options = {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'Campaign Counts by Status',
            },
        },
    };

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axiosInstance.get('/admin/totalcampaigncount');
                const result = response.data.data;

                if (result.code === 200) {
                    const { statusCount } = result.data.data;
                    const upcomingCount = statusCount.UPCOMING || 0;
                    const ongoingCount = statusCount.LIVE || 0; 
                    const completedCount = statusCount.COMPLETED || 0;
                    const cancelledCount = statusCount.CANCELLED || 0;

                    setChartData(prevData => ({
                        ...prevData,
                        datasets: [{
                            ...prevData.datasets[0],
                            data: [upcomingCount, ongoingCount, completedCount, cancelledCount],
                        }],
                    }));
                } else {
                    console.error('Error: No valid data found in response');
                }
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        fetchData();
    }, []);

    return (
        <div style={{ height: "50vh", width: "100%" }} className='bar_chart'>
            <h2 style={{ textAlign: 'center' }}>Campaign Counts by Status</h2>
            <Bar data={chartData} options={options} />
        </div>
    );
};

export default Barchart;
