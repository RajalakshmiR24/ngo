import React, { useEffect, useState } from 'react';
import axiosInstance from '../../../../Utils/axiosInstance';

const RequestAndCampaign = () => {
  const [users, setUsers] = useState([]);
  const [bills, setBills] = useState([]);
  const [campaignRequests, setCampaignRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [campId, setCampId] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const userResponse = await axiosInstance.get('/admin/verifyuserdetails');
        const billResponse = await axiosInstance.get('/admin/getbills', { campId });
        const campaignResponse = await axiosInstance.get('/admin/campaignstatustoverify');

        if (userResponse.data && Array.isArray(userResponse.data.data)) {
          setUsers(userResponse.data.data);
        } else {
          throw new Error("Invalid user data format");
        }

        if (billResponse.data && Array.isArray(billResponse.data.data)) {
          setBills(billResponse.data.data);
        }

        if (campaignResponse.data && Array.isArray(campaignResponse.data.data)) {
          setCampaignRequests(campaignResponse.data.data);
        }
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [campId]);

  const updateUserStatus = async (userId, currentStatus) => {
    try {
      const response = await axiosInstance.post(`/admin/rejectuser`, {
        userId,
        documentVerified: !currentStatus,
      });
      setUsers(prevUsers => prevUsers.map(user => 
        user.id === userId ? { ...user, documentVerified: response.data.documentVerified } : user
      ));
    } catch (err) {
      setError(err.message);
    }
  };

  const rejectUser = async (userId) => {
    try {
      await axiosInstance.post(`/admin/rejectuser`, { userId });
      setUsers(prevUsers => prevUsers.filter(user => user.id !== userId));
    } catch (err) {
      setError(err.message);
    }
  };

  const rejectCampaign = async (campId) => {
    try {
      await axiosInstance.post('/admin/rejectCampaignRequest', { camp_id: campId });
      setCampaignRequests(prevRequests => prevRequests.filter(req => req.campaign_id !== campId));
    } catch (error) {
      setError(error.message);
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div>
      <h2>Registered Users Bills to Verify</h2>
      <ul>
        {bills.map(bill => (
          <li key={bill.bill_id}>
            {bill.bill_id} - {bill.status}
          </li>
        ))}
      </ul>

      <h2>Users to Verify</h2>
      <table className="table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Document Verified</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {Array.isArray(users) && users.map(user => (
            <tr key={user.id}>
              <td>{user.fullname}</td>
              <td>{user.email}</td>
              <td>{user.documentVerified ? 'Yes' : 'No'}</td>
              <td>
                <button onClick={() => updateUserStatus(user.id, user.documentVerified)}>
                  {user.documentVerified ? 'Revoke' : 'Verify'}
                </button>
                <button onClick={() => rejectUser(user.id)}>Reject</button>
                <button onClick={() => console.log(`Viewing user with ID: ${user.id}`)}>View</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* <h2>Campaign Requests to Verify</h2>
      <ul>
        {campaignRequests.map(request => (
          <li key={request.campaign_id}>
            {request.campaign_title} 
            <button onClick={() => rejectCampaign(request.campaign_id)}>Reject</button>
          </li>
        ))}
      </ul> */}
    </div>
  );
};

export default RequestAndCampaign;
