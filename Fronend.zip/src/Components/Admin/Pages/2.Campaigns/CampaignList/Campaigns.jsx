import React, { useContext, useEffect, useState } from 'react';
import { CampaignContext } from '../../../../../Context/CampaignContext';
import axiosInstance from '../../../../../Utils/axiosInstance';
import './Campaigns.css';

const Campaigns = () => {
  const {
    adminCampaigns,
    userCampaigns,
    loading,
    newCampaign,
    handleChange,
    openModal,
    closeModal,
    handleToggleCampaignType,
    activeCampaignType,
    isModalOpen,
    setAdminCampaigns,
    setUserCampaigns,
    setLoading,
  } = useContext(CampaignContext);

  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedDetails, setSelectedDetails] = useState(null);
  const [isDetailsModalOpen, setDetailsModalOpen] = useState(false);

  useEffect(() => {
    const fetchCampaigns = async () => {
      setLoading(true);
      try {
        const endpoint = activeCampaignType === 'user'
          ? '/admin/allusers'
          : '/admin/admincampaigndetails';

        const response = await axiosInstance.get(endpoint);
        const allCampaigns = response.data.data.flatMap(item => item.campaigndetails);

        if (activeCampaignType === 'user') {
          setUserCampaigns(allCampaigns);
          setAdminCampaigns([]);
        } else {
          setAdminCampaigns(allCampaigns);
          setUserCampaigns([]);
        }
      } catch (error) {
        console.error('Error fetching campaign data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchCampaigns();
  }, [activeCampaignType, setLoading, setUserCampaigns, setAdminCampaigns]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const emailHash = localStorage.getItem('hash');

    if (!emailHash) {
      alert("Email hash not found in local storage.");
      return;
    }

    const campaignData = {
      hash: emailHash,
      info: newCampaign,
    };

    try {
      await axiosInstance.post('/admin/campaigndata', campaignData);
      if (newCampaign.isAdmin) {
        setAdminCampaigns((prev) => [...prev, campaignData.info]);
      } else {
        setUserCampaigns((prev) => [...prev, campaignData.info]);
      }
    } catch (error) {
      console.error('Error creating campaign:', error);
      alert("Failed to create campaign: " + error.response?.data.message || error.message);
    } finally {
      closeModal();
    }
  };

  const getCampaignStatus = (startDate, endDate) => {
    const now = new Date();
    const start = new Date(startDate);
    const end = new Date(endDate);

    if (now < start) return 'Upcoming';
    if (now >= start && now <= end) return 'Live';
    return 'Completed';
  };

  const filteredCampaigns = (campaigns) => {
    if (statusFilter === 'all') return campaigns;
    return campaigns.filter(campaign => getCampaignStatus(campaign.start_date, campaign.end_date).toLowerCase() === statusFilter);
  };

  const fetchDetails = async (campaignId) => {
    const emailHash = localStorage.getItem('hash');
  
    if (!emailHash) {
      alert("Email hash not found in local storage.");
      return;
    }
  
    try {
      const response = await axiosInstance.post('/admin/finduserbyhash', { hash: emailHash });
      const userDetails = response.data.data; // Assuming this is where user details are stored
  console.log(userDetails);
  
      // Find the campaign details based on campaignId
      const campaignDetails = userCampaigns.find(campaign => campaign._id === campaignId);
  
      // Set the selected details to include user details and campaign details
      setSelectedDetails({ userDetails, campaignDetails });
      setDetailsModalOpen(true);
    } catch (error) {
      console.error('Error fetching details:', error);
      alert("Failed to fetch details: " + error.message);
    }
  };
  
  

  return (
    <div>
      <h1>Campaigns</h1>
      <button onClick={() => handleToggleCampaignType('admin')}>Admin Campaign</button>
      <button onClick={() => handleToggleCampaignType('user')}>User Campaign</button>

      {activeCampaignType === 'admin' && (
        <>
          <button onClick={openModal}>Create Admin Campaign</button>
          {isModalOpen && (
            <div className="modal">
              <div className="modal-content">
                <h2>Create New Campaign</h2>
                <form onSubmit={handleSubmit}>
                  {/* form fields */}
                  <button type="submit">Create Campaign</button>
                  <button type="button" onClick={closeModal}>Cancel</button>
                </form>
              </div>
            </div>
          )}

          <section>
            <h2>Admin Campaign Overview</h2>
            <div>
              <button onClick={() => setStatusFilter('upcoming')}>Upcoming</button>
              <button onClick={() => setStatusFilter('live')}>Live</button>
              <button onClick={() => setStatusFilter('completed')}>Completed</button>
              <button onClick={() => setStatusFilter('all')}>All</button>
            </div>
            {loading ? (
              <p>Loading...</p>
            ) : (
              <table>
                <thead>
                  <tr>
                    <th>Campaign Name</th>
                    <th>Type</th>
                    <th>Budget</th>
                    <th>Location</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredCampaigns(adminCampaigns).map((campaign) => (
                    <tr key={campaign._id}>
                      <td>{campaign.campaign_title}</td>
                      <td>{campaign.campaign_type}</td>
                      <td>{campaign.budget || 'N/A'}</td>
                      <td>{campaign.campaign_address || 'N/A'}</td>
                      <td>
                        <button onClick={() => fetchDetails(campaign._id)}>View</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </section>
        </>
      )}

      {activeCampaignType === 'user' && (
        <section>
          <h2>User Campaign Overview</h2>
          <div>
            <button onClick={() => setStatusFilter('upcoming')}>Upcoming</button>
            <button onClick={() => setStatusFilter('live')}>Live</button>
            <button onClick={() => setStatusFilter('completed')}>Completed</button>
            <button onClick={() => setStatusFilter('all')}>All</button>
          </div>
          {loading ? (
            <p>Loading...</p>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Campaign Name</th>
                  <th>Type</th>
                  <th>Budget</th>
                  <th>Location</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredCampaigns(userCampaigns).map((campaign) => (
                  <tr key={campaign._id}>
                    <td>{campaign.campaign_title}</td>
                    <td>{campaign.campaign_type}</td>
                    <td>{campaign.budget || 'N/A'}</td>
                    <td>{campaign.campaign_address || 'N/A'}</td>
                    <td>
                      <button onClick={() => fetchDetails(campaign._id)}>View</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      )}

      {/* Modal for showing user and campaign details */}
      {/* {isDetailsModalOpen && (
        <div className="modal">
          <div className="modal-content">
            <h2>User and Campaign Details</h2>
            {selectedDetails && (
              <>
                <h3>User Details</h3>
                <pre>{JSON.stringify(selectedDetails.data, null, 2)}</pre>
                <h3>Campaign Details</h3>
                <pre>{JSON.stringify(selectedDetails.campaignDetails, null, 2)}</pre>
              </>
            )}
            <button onClick={() => setDetailsModalOpen(false)}>Close</button>
          </div>
        </div>
      )} */}

{isDetailsModalOpen && (
  <div className="modal">
    <div className="modal-content">
      <h2>User and Campaign Details</h2>
      {selectedDetails ? (
        <>
          <h3>User Details</h3>
          {selectedDetails.userDetails ? (
            <ul>
              <li><strong>Full Name:</strong> {selectedDetails.userDetails.fullname}</li>
              <li><strong>Email:</strong> {selectedDetails.userDetails.email}</li>
              <li><strong>Mobile Number:</strong> {selectedDetails.userDetails.mobile_number}</li>
              <li><strong>Status:</strong> {selectedDetails.userDetails.status}</li>
            </ul>
          ) : (
            <p>No user details found.</p>
          )}

          <h3>Campaign Details</h3>
          {selectedDetails.campaignDetails ? (
            <ul>
              <li><strong>Campaign Name:</strong> {selectedDetails.campaignDetails.campaign_title}</li>
              <li><strong>Type:</strong> {selectedDetails.campaignDetails.campaign_type}</li>
              <li><strong>Description:</strong> {selectedDetails.campaignDetails.campaign_description}</li>
              <li><strong>Budget:</strong> {selectedDetails.campaignDetails.budget || 'N/A'}</li>
              <li><strong>Location:</strong> {selectedDetails.campaignDetails.campaign_address || 'N/A'}</li>
              <li><strong>Status:</strong> {getCampaignStatus(selectedDetails.campaignDetails.start_date, selectedDetails.campaignDetails.end_date)}</li>
            </ul>
          ) : (
            <p>No campaign details found.</p>
          )}
        </>
      ) : (
        <p>Loading details...</p>
      )}
      <button onClick={() => setDetailsModalOpen(false)}>Close</button>
    </div>
  </div>
)}


    </div>
  );
};

export default Campaigns;
