import React, { useEffect, useState } from 'react';
import axiosInstance from '../../../../../../Utils/axiosInstance';
import CampaignDetails from '../CampaignDetails/CampaignDetails';
import './RegisteredUserList.css';

const RegisteredUserList = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedCampaigns, setSelectedCampaigns] = useState([]); // Store all campaigns
  const [showDetails, setShowDetails] = useState(false);
  const [loadingCampaigns, setLoadingCampaigns] = useState(false);
  const [noCampaignMessage, setNoCampaignMessage] = useState(''); // State for no campaigns message

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axiosInstance.get('/admin/allusers');
        console.log(response);
        setUsers(response.data.data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchUsers();
  }, []);

  const handleAction = async (hash) => {
    setLoadingCampaigns(true);
    setNoCampaignMessage(''); // Reset message
    try {
      const response = await axiosInstance.post('/admin/campaigndataperuser', { hash });
      const campaignsData = response.data.data;

      if (campaignsData && campaignsData.length > 0) {
        setSelectedCampaigns(campaignsData); // Store all campaigns
        setShowDetails(true);
      } else {
        setNoCampaignMessage("No campaigns found for this user."); // Update state with message
        setShowDetails(true); // Still show details view
      }
    } catch (err) {
      console.error("Error fetching campaigns:", err);
      setNoCampaignMessage("Failed to fetch campaigns: " + err.message); // Update state with error message
      setShowDetails(true); // Show the message in details view
    } finally {
      setLoadingCampaigns(false);
    }
  };

  const closeDetails = () => {
    setShowDetails(false);
    setSelectedCampaigns([]); // Reset campaigns on close
    setNoCampaignMessage(''); // Reset no campaign message on close
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div>
      {showDetails ? (
        <CampaignDetails 
          campaigns={selectedCampaigns} 
          noCampaignMessage={noCampaignMessage} // Pass the message to CampaignDetails
          onClose={closeDetails} 
        />
      ) : (
        <div>
          <h2>Registered User List</h2>
          <table>
            <thead>
              <tr>
                <th>Full Name</th>
                <th>Email</th>
                <th>Mobile Number</th>
                <th>No. of Campaigns</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user._id}>
                  <td>{user.fullname}</td>
                  <td>{user.email}</td>
                  <td>{user.mobile_number}</td>
                  <td>{user.campaigndetails ? user.campaigndetails.length : 0}</td>
                  <td>
                    <button onClick={() => handleAction(user.email_hash)} disabled={loadingCampaigns}>
                      {loadingCampaigns ? 'Loading...' : 'View'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default RegisteredUserList;
