// CampaignBanner.js
import React from 'react';
import './CampaignBanner.css'; // Add some CSS for styling

const CampaignBanner = ({ campaign, onClose }) => {
  return (
    <div className="campaign-details-modal">
      <div className="card">
        <button className="close-button" onClick={onClose}>X</button>
        <h3>{campaign.campaign_title}</h3>
        <p>{campaign.campaign_description}</p>
        <p><strong>Start Date:</strong> {new Date(campaign.start_date).toLocaleDateString()}</p>
        <p><strong>End Date:</strong> {new Date(campaign.end_date).toLocaleDateString()}</p>
        <p><strong>Budget:</strong> {campaign.budget ? campaign.budget : 'Not specified'}</p>
        <p><strong>Address:</strong> {campaign.campaign_address}</p>
      </div>
    </div>
  );
};


export default CampaignBanner;
