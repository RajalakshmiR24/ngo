import React from 'react'

const GeneralUserDetails = () => {
  return (
    <div>
      GeneralUserDetails
      GeneralUserDetails
    </div>
  )
}

export default GeneralUserDetails
