import React from 'react';
import Sidebar from '../Common/Sidebar/Sidebar'; 
import { Outlet } from 'react-router-dom';

const AdminLayout = () => {
  return (

    <div style={{ display: 'flex' }}>
      <Sidebar />
      <div style={{ marginLeft: '250px', padding: '20px', flex: 1 }}>
        <Outlet />
      </div>
    </div>
  );
}

export default AdminLayout;
