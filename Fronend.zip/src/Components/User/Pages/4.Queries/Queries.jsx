import React, { useEffect, useState } from 'react';
import axiosInstance from '../../../../Utils/axiosInstance';

const Inbox = () => {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchMessages = async () => {
      try {
        const response = await axiosInstance.get('/messages'); // Adjust endpoint as needed
        setMessages(response.data);
      } catch (err) {
        setError('Error fetching messages');
      } finally {
        setLoading(false);
      }
    };

    fetchMessages();
  }, []);

  const deleteMessage = async (id) => {
    try {
      await axiosInstance.delete(`/messages/${id}`); // Adjust endpoint as needed
      setMessages(messages.filter(message => message.id !== id)); // Update state
    } catch (err) {
      setError('Error deleting message');
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;

  return (
    <div>
      <h1>Inbox</h1>
      <ul>
        {messages.map(message => (
          <li key={message.id}>
            <div>
              <h2>{message.subject}</h2>
              <p>{message.body}</p>
              <button onClick={() => deleteMessage(message.id)}>Delete</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Inbox;
