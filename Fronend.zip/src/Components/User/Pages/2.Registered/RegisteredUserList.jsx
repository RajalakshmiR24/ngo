
import React from 'react'

const RegisteredUserList = () => {
  return (
    <div>
      RegisteredUserList
      
    </div>
  )
}

export default RegisteredUserList
