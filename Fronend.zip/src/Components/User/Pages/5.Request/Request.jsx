import React, { useEffect, useState } from 'react';
import axiosInstance from '../../../../Utils/axiosInstance';

const AccessManagement = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axiosInstance.get('/users/getallusers'); 
        setUsers(response.data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchUsers();
  }, []);

  const updateUserStatus = async (userId, currentStatus) => {
    try {
      const response = await axiosInstance.put(`/users/${userId}/`, {
        documentVerified: !currentStatus, 
      });
      setUsers(users.map(user => (user.id === userId ? { ...user, documentVerified: response.data.documentVerified } : user)));
    } catch (err) {
      setError(err.message);
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div>
      <h1>Access Management</h1>
      <table className="table">
        <thead>
          <tr>
            <th>User ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Document Verified</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {users.map(user => (
            <tr key={user.id}>
              <td>{user.id}</td>
              <td>{user.name}</td>
              <td>{user.email}</td>
              <td>{user.documentVerified ? 'Yes' : 'No'}</td>
              <td>
                <button onClick={() => updateUserStatus(user.id, user.documentVerified)}>
                  {user.documentVerified ? 'Revoke' : 'Verify'}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AccessManagement;
