import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Sidebar.css';
// import { FaTachometerAlt, FaUsers, FaEnvelope, FaClipboardList, FaUserFriends } from 'react-icons/fa'; // Add icons from react-icons

const Sidebar = () => {


  return (
    <div className="sidebar" aria-label="campaign Panel Navigation">
      <h2>NGO Campaign Panel</h2>
      <ul>
        <li><Link to="/register-user">Dashboard</Link></li>
        <li><Link to="/register-user/new-campaign">Campaign</Link></li>
        <li><Link to="/register-user/transaction-summery">Transaction</Link></li>
        {/* <li><Link to="/register-user/active campaign">Active campaign</Link></li>
        <li><Link to="/register-user/announcement">Announcement</Link></li>
        <li><Link to="/register-user/queries">Queries</Link></li> */}
        <li><Link to="/logout">Logout</Link></li>
      </ul>
    </div>
  );

}

export default Sidebar;
